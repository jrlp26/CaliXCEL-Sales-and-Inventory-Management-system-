<?php
require __DIR__ . '/../../../api/common.php';

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

if ($action === 'lookup' && $method === 'GET') {
    requirePermission($conn, 'customers.lookup');
    sendJson(allRows(
        $conn,
        'SELECT customer_id,customer_name,company_name,contact_number,email,address FROM customers WHERE deleted_at IS NULL ORDER BY customer_name,company_name'
    ));
}

if ($action === 'list' && $method === 'GET') {
    requirePermission($conn, 'customers.lookup');
    sendJson(allRows(
        $conn,
        'SELECT c.*,
            (SELECT COUNT(*) FROM quotations q WHERE q.customer_id=c.customer_id AND q.deleted_at IS NULL) quotation_count,
            (SELECT COUNT(*) FROM projects p WHERE p.customer_id=c.customer_id AND p.deleted_at IS NULL) project_count
         FROM customers c
         WHERE c.deleted_at IS NULL
         ORDER BY c.customer_name,c.company_name'
    ));
}

if ($action === 'get' && $method === 'GET') {
    requirePermission($conn, 'customers.lookup');
    $id = (int) ($_GET['id'] ?? 0);
    $customer = one($conn, 'SELECT * FROM customers WHERE customer_id=? AND deleted_at IS NULL', 'i', [$id]);
    if (!$customer) sendError('Customer not found.', 404);
    sendJson($customer);
}

if ($action === 'history' && $method === 'GET') {
    $user = requirePermission($conn, 'customers.lookup');
    $id = (int)($_GET['id'] ?? 0);
    $customer = one($conn, 'SELECT customer_id,customer_name,company_name FROM customers WHERE customer_id=? AND deleted_at IS NULL', 'i', [$id]);
    if (!$customer) sendError('Customer not found.', 404);
    $permissions = $user['permissions'] ?? [];
    $allowed = static fn(string $permission): bool => $user['role'] === 'ADMIN' || in_array($permission, $permissions, true);
    $history = [
        'customer' => $customer,
        'quotations' => $allowed('quotations.view') ? allRows($conn, 'SELECT quotation_id,quotation_number,quotation_date,status,total_amount FROM quotations WHERE customer_id=? AND deleted_at IS NULL ORDER BY quotation_date DESC,quotation_id DESC', 'i', [$id]) : [],
        'projects' => $allowed('projects.view') ? allRows($conn, 'SELECT p.project_id,p.project_name,p.status,p.date_created,q.quotation_number FROM projects p JOIN quotations q ON q.quotation_id=p.quotation_id WHERE p.customer_id=? AND p.deleted_at IS NULL ORDER BY p.project_id DESC', 'i', [$id]) : [],
        'invoices' => [],
        'payments' => []
    ];
    if ($allowed('billing.view')) {
        $activeBilling = activeRecordClause($conn, 'project_billings', 'b');
        $activePayments = activeRecordClause($conn, 'project_billing_payments');
        $activeProjects = activeRecordClause($conn, 'projects', 'p');
        $history['invoices'] = allRows($conn, "SELECT b.billing_id,b.invoice_number,b.description,b.invoice_date,b.due_date,b.amount,
            COALESCE(paid.collected,0) collected,GREATEST(b.amount-COALESCE(paid.collected,0),0) balance,b.status
            FROM project_billings b JOIN projects p ON p.project_id=b.project_id
            LEFT JOIN (SELECT billing_id,SUM(amount) collected FROM project_billing_payments WHERE $activePayments GROUP BY billing_id) paid
                ON paid.billing_id=b.billing_id
            WHERE p.customer_id=? AND $activeProjects AND $activeBilling ORDER BY COALESCE(b.invoice_date,b.date_created) DESC,b.billing_id DESC", 'i', [$id]);
    }
    if ($allowed('payments.view')) {
        $activePayments = activeRecordClause($conn, 'project_billing_payments', 'pay');
        $activeBilling = activeRecordClause($conn, 'project_billings', 'b');
        $activeProjects = activeRecordClause($conn, 'projects', 'p');
        $history['payments'] = allRows($conn, "SELECT pay.payment_id,pay.billing_id,pay.amount,pay.payment_date,pay.payment_method,
            CONCAT('PAY-',YEAR(pay.payment_date),'-',LPAD(pay.payment_id,6,'0')) payment_number,b.invoice_number
            FROM project_billing_payments pay JOIN project_billings b ON b.billing_id=pay.billing_id
            JOIN projects p ON p.project_id=b.project_id
            WHERE p.customer_id=? AND $activeProjects AND $activeBilling AND $activePayments ORDER BY pay.payment_date DESC,pay.payment_id DESC", 'i', [$id]);
    }
    sendJson($history);
}

if ($action === 'save' && $method === 'POST') {
    $user = requirePermission($conn, 'customers.manage');
    $body = body();
    $id = (int) ($body['customerId'] ?? 0);
    $name = trim((string) ($body['customerName'] ?? ''));
    $company = trim((string) ($body['companyName'] ?? ''));
    $contact = trim((string) ($body['contactNumber'] ?? ''));
    $email = trim((string) ($body['email'] ?? ''));
    $address = trim((string) ($body['address'] ?? ''));
    $notes = trim((string) ($body['notes'] ?? ''));

    if ($name === '') sendFieldError('customerName', 'Customer name is required.');
    if (strlen($name) > 100) sendFieldError('customerName', 'Customer name must be 100 characters or fewer.');
    if (strlen($company) > 150) sendFieldError('companyName', 'Company name must be 150 characters or fewer.');
    if (strlen($contact) > 20) sendFieldError('contactNumber', 'Contact number must be 20 characters or fewer.');
    if (strlen($email) > 100) sendFieldError('customerEmail', 'Email must be 100 characters or fewer.');
    if (strlen($address) > 255) sendFieldError('customerAddress', 'Address must be 255 characters or fewer.');
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) sendFieldError('customerEmail', 'Enter a valid email address.');

    $created = $id <= 0;
    $emailSetting = one($conn, "SELECT setting_value FROM business_settings WHERE setting_key='customer_duplicate_email'");
    $nameSetting = one($conn, "SELECT setting_value FROM business_settings WHERE setting_key='customer_duplicate_name_contact'");
    $checkEmail = !array_key_exists('setting_value', $emailSetting ?? []) || (string)$emailSetting['setting_value'] !== '0';
    $checkNameContact = !array_key_exists('setting_value', $nameSetting ?? []) || (string)$nameSetting['setting_value'] !== '0';
    if (!$checkEmail && !$checkNameContact) {
        $checkEmail = true;
        $checkNameContact = true;
    }
    $duplicateConditions = [];
    $duplicateTypes = 'i';
    $duplicateParams = [$id];
    if ($checkEmail) {
        $duplicateConditions[] = "(?<>'' AND LOWER(email)=LOWER(?))";
        $duplicateTypes .= 'ss';
        array_push($duplicateParams, $email, $email);
    }
    if ($checkNameContact) {
        $duplicateConditions[] = "(?<>'' AND LOWER(customer_name)=LOWER(?) AND contact_number=?)";
        $duplicateTypes .= 'sss';
        array_push($duplicateParams, $contact, $name, $contact);
    }
    $duplicate = one($conn, "SELECT customer_id FROM customers WHERE deleted_at IS NULL AND customer_id<>? AND (" . implode(' OR ', $duplicateConditions) . ") LIMIT 1", $duplicateTypes, $duplicateParams);
    if ($duplicate) sendError('A customer matching the enabled duplicate checks already exists. Open the existing customer record instead.', 409);
    $conn->begin_transaction();
    try {
    if ($id > 0) {
        $exists = one($conn, 'SELECT customer_id FROM customers WHERE customer_id=? AND deleted_at IS NULL', 'i', [$id]);
        if (!$exists) sendError('Customer not found.', 404);
        $statement = $conn->prepare('UPDATE customers SET customer_name=?,company_name=?,contact_number=?,email=?,address=?,notes=? WHERE customer_id=? AND deleted_at IS NULL');
        $statement->bind_param('ssssssi', $name, $company, $contact, $email, $address, $notes, $id);
    } else {
        $statement = $conn->prepare('INSERT INTO customers(customer_name,company_name,contact_number,email,address,notes) VALUES(?,?,?,?,?,?)');
        $statement->bind_param('ssssss', $name, $company, $contact, $email, $address, $notes);
    }

    $statement->execute();
    if ($id <= 0) $id = (int) $statement->insert_id;
    $statement->close();
    auditEvent($conn, $user, $created ? 'created' : 'updated', 'customer', $id, ['customer_name' => $name, 'company_name' => $company]);
    $conn->commit();
    sendJson(one($conn, 'SELECT * FROM customers WHERE customer_id=?', 'i', [$id]), $created ? 201 : 200);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('[CALIX customer save] ' . get_class($e) . ' (' . $e->getCode() . '): ' . $e->getMessage());
        sendError('The customer could not be saved.', 500);
    }
}

if ($action === 'delete' && $method === 'POST') {
    requirePermission($conn, 'settings.manage');
    sendError('Use the Trashbin to authorize customer deletion.', 403);
}

sendError('Customer route not found.', 404);
