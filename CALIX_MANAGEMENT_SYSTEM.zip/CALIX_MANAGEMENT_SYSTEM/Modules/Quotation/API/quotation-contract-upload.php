<?php
require __DIR__ . '/../../../api/common.php';
require_once __DIR__ . '/quotation-project.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Contract upload requires POST.', 405);
}

$user = requirePermission($conn, 'quotations.manage');

$quotationId = (int)($_POST['quotationId'] ?? 0);
$signer = trim((string)($_POST['signedBy'] ?? ''));
$signedDate = trim((string)($_POST['signedDate'] ?? ''));
if ($quotationId <= 0) sendError('Select a quotation for the signed contract.', 422);
if ($signer === '' || mb_strlen($signer) > 120) sendError('Enter the customer signer name (up to 120 characters).', 422);
$date = DateTime::createFromFormat('Y-m-d', $signedDate);
if (!$date || $date->format('Y-m-d') !== $signedDate || $signedDate > date('Y-m-d')) {
    sendError('Enter a valid signing date that is not in the future.', 422);
}

if (empty($_FILES['file']) || !is_array($_FILES['file'])) sendError('Choose the signed contract file.');
if (!dbTableExists($conn, 'project_payment_milestones')) {
    sendError('Project billing milestones are not installed. Back up the database, then apply Database/calix_existing_database_upgrade.sql before activating signed quotations.', 503);
}

$file = $_FILES['file'];
$error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
if ($error !== UPLOAD_ERR_OK) {
    $messages = [
        UPLOAD_ERR_INI_SIZE => 'The signed contract exceeds the server upload limit.',
        UPLOAD_ERR_FORM_SIZE => 'The signed contract is too large.',
        UPLOAD_ERR_PARTIAL => 'The signed contract upload was interrupted.',
        UPLOAD_ERR_NO_FILE => 'Choose the signed contract file.'
    ];
    sendError($messages[$error] ?? 'Signed contract upload failed.');
}
$size = (int)($file['size'] ?? 0);
if ($size <= 0 || $size > 10 * 1024 * 1024) sendError('Signed contract must be 10 MB or smaller.');
$tmp = (string)($file['tmp_name'] ?? '');
if ($tmp === '' || !is_uploaded_file($tmp)) sendError('Uploaded contract could not be verified.');

$mime = '';
if (function_exists('finfo_open')) {
    $info = finfo_open(FILEINFO_MIME_TYPE);
    if ($info) {
        $mime = (string)finfo_file($info, $tmp);
        finfo_close($info);
    }
}
$extensions = ['application/pdf'=>'pdf','image/jpeg'=>'jpg','image/png'=>'png'];
if (!isset($extensions[$mime])) sendError('Only PDF, JPG, or PNG signed contracts are allowed.');
if (str_starts_with($mime, 'image/')) {
    $image = @getimagesize($tmp);
    if (!$image || ($image['mime'] ?? '') !== $mime) sendError('The signed contract image could not be verified.');
}

$uploadDir = __DIR__ . '/../uploads/signed_contracts';
if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true)) sendError('Signed contract folder could not be created.', 500);
try {
    $name = 'contract_' . $quotationId . '_' . bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
} catch (Throwable $e) {
    error_log('Unable to generate a secure signed-contract filename: ' . $e->getMessage());
    sendError('A secure contract filename could not be generated.', 500);
}
$destination = $uploadDir . DIRECTORY_SEPARATOR . $name;
$oldFile = '';
$fileMoved = false;
$conn->begin_transaction();
try {
    $quotation = one(
        $conn,
        "SELECT quotation_id,quotation_number,signed_contract_file FROM quotations
         WHERE quotation_id=? AND status='PENDING' AND deleted_at IS NULL FOR UPDATE",
        'i',
        [$quotationId]
    );
    if (!$quotation) {
        throw new DomainException('Only an active pending quotation can be activated with a signed contract.');
    }
    $existingProject = one($conn, 'SELECT project_id,deleted_at FROM projects WHERE quotation_id=? ORDER BY project_id DESC LIMIT 1 FOR UPDATE', 'i', [$quotationId]);
    if ($existingProject && !empty($existingProject['deleted_at'])) {
        throw new DomainException('A deleted project is already linked to this quotation. Restore it from the Trashbin before activating the signed quotation.');
    }
    if (!move_uploaded_file($tmp, $destination)) {
        throw new RuntimeException('Signed contract could not be saved.');
    }
    $fileMoved = true;
    $oldFile = (string)($quotation['signed_contract_file'] ?? '');

    $stmt = $conn->prepare(
        "UPDATE quotations SET signed_contract_file=?,signed_by=?,signed_date=?,status='APPROVED'
         WHERE quotation_id=? AND status='PENDING' AND deleted_at IS NULL"
    );
    $stmt->bind_param('sssi', $name, $signer, $signedDate, $quotationId);
    $stmt->execute();
    $updated = $stmt->affected_rows;
    $stmt->close();
    if ($updated !== 1) {
        throw new RuntimeException('Quotation changed before the signed contract could activate its project.');
    }

    auditEvent(
        $conn,
        $user,
        'approved',
        'quotation',
        $quotationId,
        ['quotation_number' => $quotation['quotation_number'], 'signed_by' => $signer, 'signed_date' => $signedDate],
        'PENDING',
        'APPROVED'
    );
    $project = ensureProjectForApprovedQuotation($conn, $quotationId, $user);
    if (!empty($project['projectDeleted'])) {
        throw new DomainException('A deleted project is already linked to this quotation. Restore it from the Trashbin before activating the signed quotation.');
    }
    $conn->commit();
} catch (Throwable $e) {
    $conn->rollback();
    if ($fileMoved && is_file($destination) && !unlink($destination)) {
        error_log('Unable to remove an uncommitted signed contract upload for quotation ' . $quotationId . '.');
    }
    if ($e instanceof mysqli_sql_exception) {
        error_log('Unable to activate signed quotation: ' . $e->getMessage());
    }
    if ($e instanceof DomainException) {
        sendError($e->getMessage(), 409);
    }
    error_log('Signed quotation activation failed: ' . $e->getMessage());
    sendError('The signed contract could not activate the quotation and project. No database changes were saved.', 500);
}

if ($oldFile !== '' && preg_match('/^contract_' . $quotationId . '_[a-f0-9]{32}\.(pdf|jpg|png)$/', $oldFile)) {
    $oldPath = $uploadDir . DIRECTORY_SEPARATOR . $oldFile;
    if (is_file($oldPath) && !unlink($oldPath)) error_log('Unable to remove the replaced signed contract for quotation ' . $quotationId . '.');
}
sendJson([
    'quotationId' => $quotationId,
    'signedBy' => $signer,
    'signedDate' => $signedDate,
    'quotationStatus' => 'APPROVED',
    'projectCreated' => $project['created'],
    'projectId' => $project['projectId']
], 201);
