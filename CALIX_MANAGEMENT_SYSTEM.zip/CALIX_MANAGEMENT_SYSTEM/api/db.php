<?php
ini_set('display_errors', '0');
ini_set('log_errors', '1');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Keep local XAMPP zero-configuration defaults while allowing deployment credentials.
$host = getenv('CALIX_DB_HOST') ?: '127.0.0.1';
$user = getenv('CALIX_DB_USER') ?: 'root';
$password = getenv('CALIX_DB_PASSWORD');
$password = $password === false ? '' : $password;
$database = getenv('CALIX_DB_NAME') ?: 'calix_db';

try {
    $conn = new mysqli($host, $user, $password, $database);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $exception) {
    error_log('[CALIX database] Connection failed (' . $exception->getCode() . '): ' . $exception->getMessage());
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'error' => 'The CALIX database is temporarily unavailable. Please retry in a moment or contact your administrator.',
        'code' => 'database_unavailable'
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!isset($conn) || !$conn instanceof mysqli) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'error' => 'The database connection could not be initialized. Please contact your administrator.',
        'code' => 'internal_error'
    ]);
    exit;
}
