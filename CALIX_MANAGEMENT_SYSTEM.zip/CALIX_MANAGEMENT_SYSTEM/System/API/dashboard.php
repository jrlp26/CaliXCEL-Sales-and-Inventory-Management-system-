<?php
require __DIR__ . '/../../api/common.php';
$user = requirePermission($conn, 'dashboard.view');
$action = $_GET['action'] ?? 'summary';
$method = $_SERVER['REQUEST_METHOD'];

function tableExists(mysqli $c, string $table): bool {
    $r = one($c, 'SELECT COUNT(*) n FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?', 's', [$table]);
    return (int)($r['n'] ?? 0) > 0;
}
function columnExists(mysqli $c, string $table, string $column): bool {
    $r = one($c, 'SELECT COUNT(*) n FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?', 'ss', [$table,$column]);
    return (int)($r['n'] ?? 0) > 0;
}
function scalar(mysqli $c, string $sql): float {
    $r = one($c, $sql);
    return (float)($r ? array_values($r)[0] : 0);
}
function dashboardQuickActionRoutes(array $user): array {
    $permissions = $user['permissions'] ?? [];
    $can = static fn(string $permission): bool => ($user['role'] ?? '') === 'ADMIN' || in_array($permission, $permissions, true);
    $routes = [
        'customers' => ['label' => 'Customers', 'description' => 'Customer records', 'href' => 'Modules/Customers/HTML/Customers.html', 'permission' => 'customers.lookup'],
        'quotations' => ['label' => 'Quotations & Projects', 'description' => 'Quotes and active projects', 'href' => 'Modules/Quotation/HTML/Projects.html', 'permission' => 'quotations.view'],
        'inventory' => ['label' => 'Inventory', 'description' => 'Materials and stock levels', 'href' => 'Modules/Inventory/HTML/ViewInventory.html', 'permission' => 'inventory.view'],
        'sales' => ['label' => 'Sales', 'description' => 'Sales records', 'href' => 'Modules/Sales/HTML/ViewSales.html', 'permission' => 'sales.view'],
        'billing' => ['label' => 'Billing', 'description' => 'Invoices and outstanding balances', 'href' => 'Modules/Finance/HTML/Billing.html', 'permission' => 'billing.view'],
        'payments' => ['label' => 'Payments', 'description' => 'Payment records', 'href' => 'Modules/Finance/HTML/Payments.html', 'permission' => 'payments.view'],
        'reports' => ['label' => 'Reports', 'description' => 'Operational reports', 'href' => 'Modules/Reports/HTML/Reports.html', 'permission' => 'reports.operational'],
        'settings' => ['label' => 'Settings', 'description' => 'Users, roles, and administration', 'href' => 'Modules/Settings/HTML/Settings.html', 'permission' => 'settings.manage'],
        'team_notes' => ['label' => 'Team Notes & Reminders', 'description' => 'Personal notes and team reminders', 'href' => 'System/HTML/Dashboard.html#tasksWorkspace', 'permission' => 'tasks.view']
    ];
    return array_filter($routes, static fn(array $route): bool => $can($route['permission']));
}
function dashboardSummary(mysqli $c, array $user): array {
    $perms = userPermissions($c, $user['role']);
    $can = fn(string $p): bool => $user['role']==='ADMIN' || in_array($p,$perms,true);
    $out = ['cards'=>[], 'quotationStatus'=>[], 'projectStatus'=>[], 'attention'=>[], 'recentActivity'=>[]];

    if ($can('quotations.view') && tableExists($c,'quotations')) {
        $activeQuotations = activeRecordClause($c, 'quotations');
        $out['cards']['quotations'] = [
            'primary'=>(int)scalar($c,"SELECT COUNT(*) n FROM quotations WHERE $activeQuotations AND status='PENDING'"),
            'total'=>(int)scalar($c,"SELECT COUNT(*) n FROM quotations WHERE $activeQuotations")
        ];
        foreach (['DRAFT','PENDING','APPROVED','REJECTED'] as $s) {
            $out['quotationStatus'][$s]=(int)scalar($c,"SELECT COUNT(*) n FROM quotations WHERE $activeQuotations AND status='".$c->real_escape_string($s)."'");
        }
        $pending = $out['quotationStatus']['PENDING'] ?? 0;
        if ($pending>0) $out['attention'][]=['type'=>'quotation','count'=>$pending,'title'=>'Quotations for review','detail'=>'Review and decide pending quotations','href'=>'Modules/Quotation/HTML/Projects.html?status=PENDING'];
        if (columnExists($c,'quotations','valid_until')) {
            $expiring=(int)scalar($c,"SELECT COUNT(*) n FROM quotations WHERE $activeQuotations AND status='PENDING' AND valid_until IS NOT NULL AND valid_until BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 7 DAY)");
            if($expiring>0)$out['attention'][]=['type'=>'expiry','count'=>$expiring,'title'=>'Quotations nearing expiration','detail'=>'Valid for 7 days or less','href'=>'Modules/Quotation/HTML/Projects.html?status=PENDING'];
        }
    }

    if ($can('projects.view') && tableExists($c,'projects')) {
        $activeProjects = activeRecordClause($c, 'projects');
        $out['cards']['projects']=[
            'primary'=>(int)scalar($c,"SELECT COUNT(*) n FROM projects WHERE $activeProjects AND status NOT IN ('COMPLETED','CLOSED','CANCELLED')"),
            'total'=>(int)scalar($c,"SELECT COUNT(*) n FROM projects WHERE $activeProjects")
        ];
        foreach(['APPROVED','SCHEDULED','IN_PROGRESS','FOR_INSTALLATION','COMPLETED','CLOSED','CANCELLED'] as $s) {
            $out['projectStatus'][$s]=(int)scalar($c,"SELECT COUNT(*) n FROM projects WHERE $activeProjects AND status='".$c->real_escape_string($s)."'");
        }
        $needs=(int)($out['projectStatus']['APPROVED']??0);
        if($needs>0)$out['attention'][]=['type'=>'project','count'=>$needs,'title'=>'Approved projects need scheduling','detail'=>'Set a start date and schedule the work','href'=>'Modules/Quotation/HTML/Projects.html?project_status=APPROVED'];
    }

    if ($can('inventory.view') && tableExists($c,'inventory')) {
        $activeInventory = activeRecordClause($c, 'inventory');
        $out['cards']['inventory']=[
            'primary'=>(int)scalar($c,"SELECT COUNT(*) n FROM inventory WHERE $activeInventory AND quantity>0 AND quantity<=reorder_level"),
            'total'=>(int)scalar($c,"SELECT COUNT(*) n FROM inventory WHERE $activeInventory")
        ];
        $low=$out['cards']['inventory']['primary'];
        if($low>0)$out['attention'][]=['type'=>'inventory','count'=>$low,'title'=>'Inventory items are low in stock','detail'=>'Review stock levels before materials run out','href'=>'Modules/Inventory/HTML/ViewInventory.html?status=Low%20Stock'];
    }

    if ($can('billing.view') && tableExists($c,'project_billings') && tableExists($c,'project_billing_payments')) {
        $activeBillings = activeRecordClause($c, 'project_billings', 'b');
        $activeProjects = activeRecordClause($c, 'projects', 'p');
        $paymentActiveClause = activeRecordClause($c, 'project_billing_payments');
        $dueDateExpression = columnExists($c, 'project_billings', 'due_date') ? 'b.due_date<CURDATE()' : '0=1';
        $billing = one($c, "SELECT
            COALESCE(SUM(CASE WHEN b.status<>'PLANNED' THEN b.amount ELSE 0 END),0) billed,
            COALESCE(SUM(CASE WHEN b.status<>'PLANNED' THEN COALESCE(pay.collected,0) ELSE 0 END),0) collected,
            COALESCE(SUM(CASE WHEN b.status<>'PLANNED' THEN GREATEST(b.amount-COALESCE(pay.collected,0),0) ELSE 0 END),0) outstanding,
            COALESCE(SUM(CASE WHEN b.status<>'PLANNED' AND $dueDateExpression AND b.amount>COALESCE(pay.collected,0) THEN 1 ELSE 0 END),0) overdue
            FROM project_billings b
            JOIN projects p ON p.project_id=b.project_id
            LEFT JOIN (SELECT billing_id,SUM(amount) collected FROM project_billing_payments WHERE $paymentActiveClause GROUP BY billing_id) pay
                ON pay.billing_id=b.billing_id
            WHERE $activeBillings AND $activeProjects");
        $out['cards']['billing']=['primary'=>(float)($billing['outstanding']??0),'billed'=>(float)($billing['billed']??0),'collected'=>(float)($billing['collected']??0),'overdue'=>(int)($billing['overdue']??0)];
        if ((int)($billing['overdue']??0)>0) {
            $out['attention'][]=['type'=>'expiry','count'=>(int)$billing['overdue'],'title'=>'Invoices are overdue','detail'=>'Review receivables and follow up with customers','href'=>'Modules/Finance/HTML/Billing.html?status=OVERDUE'];
        }
    }

    $activity=[];
    if($can('quotations.view') && tableExists($c,'quotations')){
        $activeQuotations = activeRecordClause($c, 'quotations', 'q');
        $dateCol = columnExists($c,'quotations','date_created') ? 'date_created' : (columnExists($c,'quotations','quotation_date') ? 'quotation_date' : 'quotation_id');
        $userSelect = "'—' actor";
        $join = '';
        foreach (['created_by','user_id','created_by_user'] as $uc) {
            if (columnExists($c,'quotations',$uc)) { $join=" LEFT JOIN users u ON u.user_id=q.$uc "; $userSelect="COALESCE(u.username,'—') actor"; break; }
        }
        $rows=allRows($c,"SELECT q.quotation_id,q.quotation_number,q.status,q.$dateCol d,$userSelect FROM quotations q $join WHERE $activeQuotations ORDER BY q.quotation_id DESC LIMIT 4");
        foreach($rows as $r){
            $status=strtoupper((string)$r['status'])==='PENDING'?'For review':ucfirst(strtolower((string)$r['status']));
            $activity[]=['kind'=>'quotation','text'=>'Quotation '.$r['quotation_number'].' · '.$status,'date'=>$r['d'],'user'=>$r['actor'],'href'=>'Modules/Quotation/HTML/Projects.html?quotation='.(int)$r['quotation_id']];
        }
    }
    if($can('inventory.view') && tableExists($c,'inventory_transactions')){
        $dateCol=columnExists($c,'inventory_transactions','transaction_date')?'transaction_date':(columnExists($c,'inventory_transactions','date_created')?'date_created':'');
        if($dateCol){
            $hasUser=columnExists($c,'inventory_transactions','user_id');
            $joinUser=$hasUser?' LEFT JOIN users u ON u.user_id=t.user_id ':'';
            $userSelect=$hasUser?"COALESCE(u.username,'—') actor":"'—' actor";
            foreach(allRows($c,"SELECT t.$dateCol d,t.transaction_type,i.material_id,i.material_name,$userSelect FROM inventory_transactions t JOIN inventory i ON i.material_id=t.material_id $joinUser ORDER BY t.$dateCol DESC LIMIT 4") as $r){
                $activity[]=['kind'=>'inventory','text'=>$r['material_name'].' · Stock '.strtolower(str_replace('_',' ',$r['transaction_type'])),'date'=>$r['d'],'user'=>$r['actor'],'href'=>'Modules/Inventory/HTML/ViewInventory.html?item='.(int)$r['material_id']];
            }
        }
        if($can('sales.view') && tableExists($c,'sales')){
            foreach(allRows($c,"SELECT s.sale_date,c.customer_name,p.project_name,q.quotation_number
                FROM sales s JOIN customers c ON c.customer_id=s.customer_id
                LEFT JOIN projects p ON p.project_id=s.project_id LEFT JOIN quotations q ON q.quotation_id=s.quotation_id
                WHERE ".activeRecordClause($c, 'sales', 's')." ORDER BY s.sale_date DESC,s.sales_id DESC LIMIT 4") as $r){
                $activity[]=['kind'=>'sales','text'=>'Contract '.$r['quotation_number'].' · '.$r['customer_name'].' · '.($r['project_name']??'Sales record'),'date'=>$r['sale_date'],'user'=>'—','href'=>'Modules/Sales/HTML/ViewSales.html'];
            }
        }
    }
    if (tableExists($c, 'system_audit_log')) {
        $permissionByEntity = [
            'quotation' => 'quotations.view',
            'project' => 'projects.view',
            'inventory' => 'inventory.view',
            'invoice' => 'billing.view',
            'payment' => 'payments.view',
            'sale' => 'sales.view',
            'customer' => 'customers.lookup',
            'user' => 'users.manage',
            'role' => 'users.manage',
            'business_setting' => 'settings.manage'
        ];
        $routes = [
            'quotation' => 'Modules/Quotation/HTML/Projects.html',
            'project' => 'Modules/Quotation/HTML/Projects.html',
            'inventory' => 'Modules/Inventory/HTML/ViewInventory.html',
            'invoice' => 'Modules/Finance/HTML/Billing.html',
            'payment' => 'Modules/Finance/HTML/Payments.html',
            'sale' => 'Modules/Sales/HTML/ViewSales.html',
            'customer' => 'Modules/Customers/HTML/Customers.html',
            'user' => 'Modules/Settings/HTML/Settings.html',
            'role' => 'Modules/Settings/HTML/Settings.html',
            'business_setting' => 'Modules/Settings/HTML/Settings.html'
        ];
        $auditActivity = [];
        foreach (allRows($c, 'SELECT username,action_key,entity_type,entity_id,details_json,created_at FROM system_audit_log ORDER BY audit_id DESC LIMIT 20') as $event) {
            $entity = (string)$event['entity_type'];
            if (!isset($permissionByEntity[$entity]) || !$can($permissionByEntity[$entity])) continue;
            $details = json_decode((string)($event['details_json'] ?? ''), true) ?: [];
            $label = (string)($details['quotation_number'] ?? $details['invoice_number'] ?? $details['payment_number'] ?? $details['project_name'] ?? $details['customer_name'] ?? $details['item_code'] ?? $details['username'] ?? $details['role_key'] ?? $details['key'] ?? $details['record_label'] ?? ucfirst(str_replace('_', ' ', $entity)) . ' #' . (int)$event['entity_id']);
            $actionLabels = [
                'created' => 'created',
                'updated' => 'updated',
                'deleted' => 'deleted',
                'restored' => 'restored',
                'issued' => 'issued',
                'approved' => 'approved',
                'rejected' => 'rejected',
                'submitted_for_review' => 'submitted for review',
                'payment_recorded' => 'recorded payment for',
                'stock_in' => 'recorded stock in for',
                'stock_out' => 'recorded stock out for',
                'created_from_quotation' => 'created project from',
                'created_from_project' => 'created sales record for'
            ];
            $kind = $entity === 'sale' ? 'sales' : ($entity === 'invoice' || $entity === 'payment' ? 'finance' : $entity);
            $href = $routes[$entity];
            if ($entity === 'quotation') $href .= '?quotation=' . (int)$event['entity_id'];
            if ($entity === 'inventory') $href .= '?item=' . (int)$event['entity_id'];
            if ($entity === 'invoice') $href .= '?invoice=' . (int)$event['entity_id'];
            if ($entity === 'payment') $href .= '?payment=' . (int)$event['entity_id'];
            if ($entity === 'customer') $href .= '?customer=' . (int)$event['entity_id'];
            $text = ($actionLabels[(string)$event['action_key']] ?? str_replace('_', ' ', (string)$event['action_key'])) . ' ' . $label;
            if (isset($details['amount']) && in_array($entity, ['invoice', 'payment'], true)) $text .= ' · ₱' . number_format((float)$details['amount'], 2);
            $auditActivity[] = [
                'kind' => $kind,
                'text' => $text,
                'date' => $event['created_at'],
                'user' => $event['username'],
                'href' => $href
            ];
        }
        if ($auditActivity) $activity = $auditActivity;
    }
    usort($activity,fn($a,$b)=>strcmp((string)$b['date'],(string)$a['date']));
    $out['recentActivity']=array_slice($activity,0,5);
    return $out;
}

if (in_array($action, ['quick-actions', 'save-quick-actions'], true)) {
    if (!tableExists($conn, 'dashboard_quick_actions') || !tableExists($conn, 'dashboard_quick_action_settings')) {
        sendError('Quick Actions need the current database upgrade. Back up the database, then import Database/calix_existing_database_upgrade.sql.', 503);
    }
    $uid = (int)$user['user_id'];
    $routes = dashboardQuickActionRoutes($user);

    if ($action === 'quick-actions' && $method === 'GET') {
        $conn->begin_transaction();
        try {
            $initialize = $conn->prepare('INSERT IGNORE INTO dashboard_quick_action_settings(user_id,initialized) VALUES(?,0)');
            $initialize->bind_param('i', $uid);
            $initialize->execute();
            $initialize->close();
            $settings = one($conn, 'SELECT initialized FROM dashboard_quick_action_settings WHERE user_id=? FOR UPDATE', 'i', [$uid]);
            if ((int)$settings['initialized'] === 0) {
                foreach (['customers', 'reports', 'settings'] as $index => $key) {
                    if (!isset($routes[$key])) continue;
                    $route = $routes[$key];
                    $insert = $conn->prepare('INSERT IGNORE INTO dashboard_quick_actions(user_id,action_key,action_label,sort_order) VALUES(?,?,?,?)');
                    $label = $route['label'];
                    $order = $index + 1;
                    $insert->bind_param('issi', $uid, $key, $label, $order);
                    $insert->execute();
                    $insert->close();
                }
                $mark = $conn->prepare('UPDATE dashboard_quick_action_settings SET initialized=1 WHERE user_id=?');
                $mark->bind_param('i', $uid);
                $mark->execute();
                $mark->close();
            }
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            throw $e;
        }
        $actions = [];
        foreach (allRows($conn, 'SELECT action_id,action_key,action_label FROM dashboard_quick_actions WHERE user_id=? ORDER BY sort_order,action_id', 'i', [$uid]) as $saved) {
            if (!isset($routes[$saved['action_key']])) continue;
            $actions[] = [
                'id' => (int)$saved['action_id'],
                'key' => $saved['action_key'],
                'label' => $saved['action_label'],
                'description' => $routes[$saved['action_key']]['description'],
                'href' => $routes[$saved['action_key']]['href']
            ];
        }
        sendJson(['actions' => $actions, 'options' => array_map(
            static fn(string $key, array $route): array => ['key' => $key, 'label' => $route['label']],
            array_keys($routes),
            array_values($routes)
        )]);
    }

    if ($action === 'save-quick-actions' && $method === 'POST') {
        $body = body();
        $items = $body['actions'] ?? null;
        if (!is_array($items) || count($items) > 8) sendError('Choose up to 8 Quick Actions.', 422);
        $seen = [];
        foreach ($items as $item) {
            if (!is_array($item)) sendError('A Quick Action entry is invalid.', 422);
            $key = (string)($item['key'] ?? '');
            $label = trim((string)($item['label'] ?? ''));
            if (!isset($routes[$key])) sendError('Choose a destination available to your account.', 422);
            if ($label === '' || mb_strlen($label) > 40) sendFieldError('label', 'Button names must be 1–40 characters long.');
            if (isset($seen[$key])) sendError('Each Quick Action destination can only be used once.', 422);
            $seen[$key] = true;
        }
        $conn->begin_transaction();
        try {
            $delete = $conn->prepare('DELETE FROM dashboard_quick_actions WHERE user_id=?');
            $delete->bind_param('i', $uid);
            $delete->execute();
            $delete->close();
            $insert = $conn->prepare('INSERT INTO dashboard_quick_actions(user_id,action_key,action_label,sort_order) VALUES(?,?,?,?)');
            foreach (array_values($items) as $index => $item) {
                $key = (string)$item['key'];
                $label = trim((string)$item['label']);
                $sortOrder = $index + 1;
                $insert->bind_param('issi', $uid, $key, $label, $sortOrder);
                $insert->execute();
            }
            $insert->close();
            $initialized = $conn->prepare('INSERT INTO dashboard_quick_action_settings(user_id,initialized) VALUES(?,1) ON DUPLICATE KEY UPDATE initialized=1');
            $initialized->bind_param('i', $uid);
            $initialized->execute();
            $initialized->close();
            auditEvent($conn, $user, 'updated', 'dashboard_quick_actions', $uid, ['count' => count($items)]);
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            throw $e;
        }
        sendJson(['saved' => true]);
    }
}

if ($action==='summary' && $method==='GET') {
    try {
        sendJson(dashboardSummary($conn, $user));
    } catch (mysqli_sql_exception $e) {
        error_log('Dashboard summary query failed: ' . $e->getMessage());
        sendError('Dashboard summary could not be loaded.', 500);
    }
}

if (in_array($action,['todos','todo-create','todo-update','todo-toggle','todo-delete'],true)) {
    $taskUser = requirePermission($conn, $action === 'todos' ? 'tasks.view' : 'tasks.manage');
    if (!tableExists($conn, 'todo_notes') || !tableExists($conn, 'todo_statuses')) {
        sendError('Dashboard tasks need the current database upgrade. Back up the database, then import Database/calix_existing_database_upgrade.sql.', 503);
    }
    $uid = (int)$taskUser['user_id'];
    $canEditTask = static function (array $task) use ($taskUser, $uid): bool {
        return $taskUser['role'] === 'ADMIN' || (int)$task['user_id'] === $uid || (int)($task['assigned_to'] ?? 0) === $uid;
    };
}
if ($action==='todos' && $method==='GET') {
    sendJson(allRows($conn,
        "SELECT t.todo_id,t.user_id,t.assigned_to,t.title todo_text,t.is_completed,t.due_date,s.status_name,s.color status_color
         FROM todo_notes t JOIN todo_statuses s ON s.status_id=t.status_id
         WHERE t.deleted_at IS NULL AND t.record_type='TASK' AND (t.user_id=? OR t.assigned_to=?)
         ORDER BY s.is_completed ASC,t.due_date IS NULL,t.due_date,t.updated_at DESC LIMIT 8",
        'ii',[$uid,$uid]));
}
if ($action==='todo-create' && $method==='POST') {
    $b=body(); $t=trim((string)($b['text']??''));
    if($t==='')sendError('Enter a task title.');
    if(mb_strlen($t)>180)sendError('Keep the task title under 180 characters.');
    $status=one($conn,'SELECT status_id FROM todo_statuses WHERE is_active=1 AND is_completed=0 ORDER BY sort_order,status_id LIMIT 1');
    if(!$status)sendError('An open task status is required. Ask an administrator to configure Tasks & Notes.',503);
    $type='TASK';$visibility='PERSONAL';$priority='NORMAL';$isCompleted=0;
    $s=$conn->prepare('INSERT INTO todo_notes(user_id,title,note_text,record_type,visibility,status_id,priority,is_completed) VALUES(?,?,\'\',?,?,?, ?,?)');
    $s->bind_param('isssisi',$uid,$t,$type,$visibility,$status['status_id'],$priority,$isCompleted);$s->execute();$id=$s->insert_id;$s->close();
    auditEvent($conn,$taskUser,'created','todo_note',(int)$id,['title'=>$t,'record_type'=>'TASK']);
    sendJson(['todoId'=>$id],201);
}
if ($action==='todo-update' && $method==='POST') {
    $b=body(); $id=(int)($b['id']??0); $t=trim((string)($b['text']??''));
    if($id<=0)sendError('Invalid task.',422);
    if($t==='')sendError('Enter a task title.');
    if(mb_strlen($t)>180)sendError('Keep the task title under 180 characters.');
    $task=one($conn,"SELECT todo_id,user_id,assigned_to FROM todo_notes WHERE todo_id=? AND record_type='TASK' AND deleted_at IS NULL",'i',[$id]);
    if(!$task||!$canEditTask($task))sendError('Task not found or unavailable for editing.',404);
    $s=$conn->prepare("UPDATE todo_notes SET title=?,updated_at=CURRENT_TIMESTAMP WHERE todo_id=? AND record_type='TASK' AND deleted_at IS NULL");
    $s->bind_param('si',$t,$id);$s->execute();$s->close();
    auditEvent($conn,$taskUser,'updated','todo_note',$id,['title'=>$t]);
    sendJson(['updated'=>true]);
}
if ($action==='todo-toggle' && $method==='POST') {
    $b=body();$id=(int)($b['id']??0);
    if($id<=0)sendError('Invalid task.',422);
    $task=one($conn,"SELECT todo_id,user_id,assigned_to,is_completed FROM todo_notes WHERE todo_id=? AND record_type='TASK' AND deleted_at IS NULL",'i',[$id]);
    if(!$task||!$canEditTask($task))sendError('Task not found or unavailable for editing.',404);
    $targetCompleted=(int)$task['is_completed']===1?0:1;
    $status=one($conn,'SELECT status_id FROM todo_statuses WHERE is_active=1 AND is_completed=? ORDER BY sort_order,status_id LIMIT 1','i',[$targetCompleted]);
    if(!$status)sendError('A matching task status is required. Ask an administrator to configure Tasks & Notes.',503);
    $s=$conn->prepare('UPDATE todo_notes SET status_id=?,is_completed=?,updated_at=CURRENT_TIMESTAMP WHERE todo_id=? AND deleted_at IS NULL');
    $s->bind_param('iii',$status['status_id'],$targetCompleted,$id);$s->execute();$s->close();
    sendJson(['updated'=>true]);
}
if ($action==='todo-delete' && $method==='POST') {
    $b=body();$id=(int)($b['id']??0);
    if($id<=0)sendError('Invalid task.',422);
    $conn->begin_transaction();
    try {
        $task=one($conn,"SELECT * FROM todo_notes WHERE todo_id=? AND record_type='TASK' AND deleted_at IS NULL FOR UPDATE",'i',[$id]);
        if(!$task||!$canEditTask($task)) {
            $conn->rollback();
            sendError('Task not found or unavailable for deletion.',404);
        }
        if(!tableExists($conn,'delete_history')) {
            $conn->rollback();
            sendError('Recoverable task deletion needs the current Trashbin database upgrade.',503);
        }
        $snapshot=json_encode($task,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if($snapshot===false)throw new RuntimeException('Task snapshot could not be encoded.');
        $module='todo_notes';$label=(string)$task['title'];
        $history=$conn->prepare('INSERT INTO delete_history(module,record_id,record_label,snapshot_json,deleted_by) VALUES(?,?,?,?,?)');
        $history->bind_param('sissi',$module,$id,$label,$snapshot,$uid);$history->execute();$history->close();
        $s=$conn->prepare('UPDATE todo_notes SET deleted_at=CURRENT_TIMESTAMP,deleted_by=? WHERE todo_id=? AND deleted_at IS NULL');
        $s->bind_param('ii',$uid,$id);$s->execute();
        if($s->affected_rows<1)throw new RuntimeException('The task was already deleted.');
        $s->close();
        auditEvent($conn,$taskUser,'deleted','todo_note',$id,['title'=>$label],'ACTIVE','DELETED');
        $conn->commit();
    } catch(Throwable $e) {
        $conn->rollback();
        throw $e;
    }
    sendJson(['deleted'=>true,'recoverable'=>true]);
}
sendError('Dashboard route not found.',404);
