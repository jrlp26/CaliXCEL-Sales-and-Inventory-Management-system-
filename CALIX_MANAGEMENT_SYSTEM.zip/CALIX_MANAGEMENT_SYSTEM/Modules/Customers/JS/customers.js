(async () => {
    const $ = (id) => document.getElementById(id);
    const rows = $('customerRows');
    const search = $('customerSearch');
    const sort = $('customerSort');
    const dialog = $('customerDialog');
    const historyDialog = $('customerHistoryDialog');
    const form = $('customerForm');
    const addButton = $('addCustomerButton');
    const notice = $('customerNotice');
    const pageSize = 8;
    let customers = [];
    let currentPage = 1;
    let saving = false;

    let account = null;
    try { account = JSON.parse(sessionStorage.getItem('calixAccount') || 'null'); } catch (_) {}
    const permissions = new Set(account?.permissions || []);
    const canManage = account?.role === 'ADMIN' || permissions.has('customers.manage');
    const canUseQuotation = account?.role === 'ADMIN' || permissions.has('quotations.manage');

    if (!rows || !search) return;

    function setNotice(message = '', type = '') {
        if (!notice) return;
        notice.textContent = message;
        notice.className = `notice${type ? ' ' + type : ''}`;
        notice.hidden = !message;
    }

    function searchable(customer) {
        return [customer.customer_id, customer.customer_name, customer.company_name, customer.contact_number, customer.email, customer.address]
            .filter(Boolean).join(' ').toLowerCase();
    }

    function render(resetPage = false) {
        const query = search.value.trim().toLowerCase();
        const filtered = customers.filter((customer) => !query || searchable(customer).includes(query));
        const sortMode = sort?.value || 'name-asc';
        filtered.sort((a, b) => {
            if (sortMode === 'newest') return Number(b.customer_id) - Number(a.customer_id);
            const result = String(a.customer_name || '').localeCompare(String(b.customer_name || ''), undefined, {sensitivity: 'base'});
            return sortMode === 'name-desc' ? -result : result;
        });
        $('customerCount').textContent = `${filtered.length} customer${filtered.length === 1 ? '' : 's'}`;
        const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
        if (resetPage) currentPage = 1;
        currentPage = Math.min(currentPage, totalPages);
        const start = (currentPage - 1) * pageSize;
        const visible = filtered.slice(start, start + pageSize);
        rows.innerHTML = visible.map((customer) => {
            const edit = canManage ? `<button class="text-button" type="button" data-edit="${customer.customer_id}">Edit</button>` : '';
            const useInQuotation = canUseQuotation ? `<a class="text-button" href="../../Quotation/HTML/CreateQuotation.html?customer=${encodeURIComponent(customer.customer_id)}">Use in Quotation</a>` : '';
            return `<tr>
                <td class="customer-id">${Number(customer.customer_id)}</td>
                <td class="customer-name-cell"><strong>${CalixUI.escape(customer.customer_name)}</strong>${customer.company_name ? `<small>${CalixUI.escape(customer.company_name)}</small>` : ''}</td>
                <td class="customer-number">${CalixUI.escape(customer.contact_number || '—')}</td>
                <td class="customer-email">${customer.email ? `<a href="mailto:${CalixUI.escape(customer.email)}">${CalixUI.escape(customer.email)}</a>` : '—'}</td>
                <td class="customer-address">${CalixUI.escape(customer.address || '—')}</td>
                <td class="customer-project-count">${Number(customer.project_count || 0)}</td>
                <td><div class="customer-actions"><button class="text-button" type="button" data-history="${customer.customer_id}">History</button>${edit}${useInQuotation}${CalixRecordDeletion.button('customers', customer.customer_id, customer.customer_name)}</div></td>
            </tr>`;
        }).join('') || `<tr><td colspan="7" class="empty-state">${query ? 'No customers match your search.' : 'No customer records yet.'}</td></tr>`;
        $('customerPageSummary').textContent = filtered.length
            ? `Showing ${start + 1}–${Math.min(start + pageSize, filtered.length)} of ${filtered.length} customers`
            : 'Showing 0 customers';
        $('customerPageNumber').textContent = `Page ${currentPage} of ${totalPages}`;
        $('previousCustomerPage').disabled = currentPage <= 1;
        $('nextCustomerPage').disabled = currentPage >= totalPages;
    }

    async function load() {
        try {
            setNotice('');
            customers = await CalixAPI.get('customers.php?action=list');
            render(true);
        } catch (error) {
            rows.innerHTML = `<tr><td colspan="7" class="empty-state">${CalixUI.escape(error?.message || 'Customers could not be loaded.')}</td></tr>`;
        }
    }

    function openForm(customer = null) {
        if (!dialog || !form || !canManage) return;
        form.reset();
        CalixUI.clearFieldErrors(form);
        $('customerError').textContent = '';
        $('customerId').value = customer?.customer_id || '';
        $('customerName').value = customer?.customer_name || '';
        $('companyName').value = customer?.company_name || '';
        $('contactNumber').value = customer?.contact_number || '';
        $('customerEmail').value = customer?.email || '';
        $('customerAddress').value = customer?.address || '';
        $('customerNotes').value = customer?.notes || '';
        $('customerDialogTitle').textContent = customer ? 'Edit Customer' : 'Add Customer';
        dialog.showModal();
        setTimeout(() => $('customerName')?.focus(), 0);
    }

    addButton?.addEventListener('click', () => openForm());
    form?.addEventListener('input', () => {
        CalixUI.clearFieldErrors(form);
        $('customerError').textContent = '';
    });
    dialog?.querySelectorAll('[data-customer-close]').forEach((button) => button.addEventListener('click', () => dialog.close()));
    search.addEventListener('input', () => render(true));
    sort?.addEventListener('change', () => render(true));
    $('previousCustomerPage').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage -= 1;
            render();
        }
    });
    $('nextCustomerPage').addEventListener('click', () => {
        currentPage += 1;
        render();
    });
    window.addEventListener('calix:search', (event) => {
        search.value = event.detail?.query || '';
        render(true);
    });

    rows.addEventListener('click', (event) => {
        const historyId = event.target.closest('[data-history]')?.dataset.history;
        if (historyId) {
            openHistory(historyId);
            return;
        }
        const id = event.target.closest('[data-edit]')?.dataset.edit;
        if (!id) return;
        const customer = customers.find((item) => String(item.customer_id) === String(id));
        if (customer) openForm(customer);
    });
    CalixRecordDeletion.bind(rows, load);

    async function openHistory(id) {
        $('customerHistoryTitle').textContent = 'Customer History';
        $('customerHistoryContent').innerHTML = '<p class="empty-state">Loading customer history…</p>';
        historyDialog.showModal();
        try {
            const history = await CalixAPI.get(`customers.php?action=history&id=${encodeURIComponent(id)}`);
            const customer = history.customer || {};
            $('customerHistoryTitle').textContent = customer.company_name
                ? `${customer.customer_name} · ${customer.company_name}`
                : customer.customer_name || 'Customer History';
            const section = (title, items, renderItem) => `<section class="customer-history-section"><h3>${title}</h3>${items.length
                ? `<ul class="customer-history-list">${items.map(renderItem).join('')}</ul>`
                : '<p class="muted">No records available.</p>'}</section>`;
            const quotationRows = (history.quotations || []).map(item =>
                `<li><strong>${CalixUI.escape(item.quotation_number)}</strong> · ${CalixUI.escape(item.quotation_date || '—')} · ${CalixUI.status(item.status)}<small>${CalixUI.money(item.total_amount)}</small></li>`);
            const projectRows = (history.projects || []).map(item =>
                `<li><strong>${CalixUI.escape(item.project_name)}</strong> · ${CalixUI.status(item.status)}<small>Quotation ${CalixUI.escape(item.quotation_number)}</small></li>`);
            const invoiceRows = (history.invoices || []).map(item =>
                `<li><strong>${CalixUI.escape(item.invoice_number || 'Draft invoice')}</strong> · ${CalixUI.escape(item.description)}<small>Total ${CalixUI.money(item.amount)} · Paid ${CalixUI.money(item.collected)} · Balance ${CalixUI.money(item.balance)}</small></li>`);
            const paymentRows = (history.payments || []).map(item =>
                `<li><strong>${CalixUI.escape(item.payment_number)}</strong> · ${CalixUI.escape(item.payment_date)} · ${CalixUI.money(item.amount)}<small>${CalixUI.escape(item.invoice_number || 'Invoice')}</small></li>`);
            $('customerHistoryContent').innerHTML =
                section('Quotations', quotationRows, item => item)
                + section('Projects', projectRows, item => item)
                + section('Invoices', invoiceRows, item => item)
                + section('Payments', paymentRows, item => item);
        } catch (error) {
            $('customerHistoryContent').innerHTML = `<p class="error-message" role="alert">${CalixUI.escape(error.message || 'Customer history could not be loaded.')}</p>`;
        }
    }

    historyDialog?.querySelectorAll('[data-history-close]').forEach(button => button.addEventListener('click', () => historyDialog.close()));

    form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (saving || !canManage) return;
        CalixUI.clearFieldErrors(form);
        $('customerError').textContent = '';
        if (!form.reportValidity()) return;
        const saveButton = form.querySelector('button[type="submit"]');
        const payload = {
            customerId: Number($('customerId').value || 0),
            customerName: $('customerName').value.trim(),
            companyName: $('companyName').value.trim(),
            contactNumber: $('contactNumber').value.trim(),
            email: $('customerEmail').value.trim(),
            address: $('customerAddress').value.trim(),
            notes: $('customerNotes').value.trim()
        };
        try {
            saving = true;
            saveButton.disabled = true;
            saveButton.textContent = 'Saving…';
            await CalixAPI.post('customers.php?action=save', payload);
            dialog.close();
            await load();
            setNotice(payload.customerId ? 'Customer updated.' : 'Customer added.', 'success');
        } catch (error) {
            CalixUI.showFormError(form, error, $('customerError'));
        } finally {
            saving = false;
            saveButton.disabled = false;
            saveButton.textContent = 'Save Customer';
        }
    });

    await load();
})();
