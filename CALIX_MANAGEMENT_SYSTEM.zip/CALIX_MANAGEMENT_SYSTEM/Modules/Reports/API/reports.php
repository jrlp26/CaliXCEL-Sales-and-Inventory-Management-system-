<?php
require __DIR__ . '/../../../api/common.php';

$user = requirePermission($conn, 'reports.operational');
$perms = userPermissions($conn, $user['role']);
$canFinancial = $user['role'] === 'ADMIN' || in_array('reports.financial', $perms, true);
$action = $_GET['action'] ?? 'overview';
$method = $_SERVER['REQUEST_METHOD'];

function validDateOrEmpty(string $value, string $label): string {
    $value = trim($value);
    if ($value === '') return '';
    $d = DateTime::createFromFormat('Y-m-d', $value);
    if (!$d || $d->format('Y-m-d') !== $value) sendError("Enter a valid $label date.", 422);
    return $value;
}
function whereDate(string $column, string $from, string $to): array {
    $parts = [];
    if ($from !== '') $parts[] = "$column >= '" . addslashes($from) . " 00:00:00'";
    if ($to !== '') $parts[] = "$column <= '" . addslashes($to) . " 23:59:59'";
    return $parts;
}
function reportScalar(mysqli $conn, string $sql): float {
    $row = one($conn, $sql);
    return (float)($row ? array_values($row)[0] : 0);
}

if ($action === 'configuration' && $method === 'GET') {
    $setting = one($conn, "SELECT setting_value FROM business_settings WHERE setting_key='report_default_range_months'");
    $months = is_numeric($setting['setting_value'] ?? null) ? (int)$setting['setting_value'] : 12;
    if (!in_array($months, [0, 1, 3, 6, 12, 24], true)) $months = 12;
    sendJson(['defaultRangeMonths' => $months]);
}

if ($action === 'overview' && $method === 'GET') {
    $from = validDateOrEmpty((string)($_GET['from'] ?? ''), 'start');
    $to = validDateOrEmpty((string)($_GET['to'] ?? ''), 'end');
    if ($from !== '' && $to !== '' && $from > $to) sendError('Start date cannot be after end date.', 422);

    $qDate = whereDate('quotation_date', $from, $to);
    $qWhere = "deleted_at IS NULL" . ($qDate ? ' AND ' . implode(' AND ', $qDate) : '');
    $pDate = whereDate('date_created', $from, $to);
    $pWhere = "deleted_at IS NULL" . ($pDate ? ' AND ' . implode(' AND ', $pDate) : '');
    $sDate = whereDate('sale_date', $from, $to);
    $sWhere = "deleted_at IS NULL" . ($sDate ? ' AND ' . implode(' AND ', $sDate) : '');

    $quotationStatus = [];
    foreach (['DRAFT','PENDING','APPROVED','REJECTED'] as $status) {
        $quotationStatus[$status] = (int)reportScalar($conn, "SELECT COUNT(*) n FROM quotations WHERE $qWhere AND status='$status'");
    }
    $projectStatus = [];
    foreach (['APPROVED','SCHEDULED','IN_PROGRESS','FOR_INSTALLATION','COMPLETED','CLOSED','CANCELLED'] as $status) {
        $projectStatus[$status] = (int)reportScalar($conn, "SELECT COUNT(*) n FROM projects WHERE $pWhere AND status='$status'");
    }

    $inventory = [
        'totalItems' => (int)reportScalar($conn, "SELECT COUNT(*) n FROM inventory WHERE deleted_at IS NULL"),
        'lowStock' => (int)reportScalar($conn, "SELECT COUNT(*) n FROM inventory WHERE deleted_at IS NULL AND quantity>0 AND quantity<=reorder_level"),
        'outOfStock' => (int)reportScalar($conn, "SELECT COUNT(*) n FROM inventory WHERE deleted_at IS NULL AND quantity<=0")
    ];
    $lowStock = allRows($conn, "SELECT material_id,item_code,material_name,category,quantity,unit,reorder_level FROM inventory WHERE deleted_at IS NULL AND quantity>0 AND quantity<=reorder_level ORDER BY quantity ASC,material_name LIMIT 20");
    $inventoryDate = whereDate('t.transaction_date', $from, $to);
    $inventoryFilter = $inventoryDate ? implode(' AND ', $inventoryDate) : '1=1';
    $inventoryMovements = allRows($conn, "SELECT t.transaction_id,t.transaction_date,t.transaction_type,t.quantity,t.remarks,
        i.item_code,i.material_name,i.unit,p.project_name,c.customer_name,COALESCE(u.username,'—') received_by
        FROM inventory_transactions t
        JOIN inventory i ON i.material_id=t.material_id
        LEFT JOIN projects p ON p.project_id=t.project_id
        LEFT JOIN customers c ON c.customer_id=p.customer_id
        LEFT JOIN users u ON u.user_id=t.user_id
        WHERE $inventoryFilter ORDER BY t.transaction_date DESC,t.transaction_id DESC LIMIT 100");
    $projectMaterialUsage = allRows($conn, "SELECT p.project_name,c.customer_name,i.item_code,i.material_name,i.unit,
        SUM(t.quantity) quantity,COUNT(*) transactions
        FROM inventory_transactions t
        JOIN inventory i ON i.material_id=t.material_id
        JOIN projects p ON p.project_id=t.project_id
        JOIN customers c ON c.customer_id=p.customer_id
        WHERE t.transaction_type='OUT' AND p.deleted_at IS NULL AND $inventoryFilter
        GROUP BY p.project_id,p.project_name,c.customer_name,i.material_id,i.item_code,i.material_name,i.unit
        ORDER BY p.project_name,i.material_name LIMIT 100");

    $financial = null;
    $billing = null;
    $invoiceRows = [];
    $salesRows = [];
    $salesTrend = [];
    $paymentRows = [];
    if ($canFinancial) {
        $financial = one($conn, "SELECT COUNT(*) salesCount,COALESCE(SUM(total_amount),0) contractTotal FROM sales WHERE $sWhere");
        $salesRows = allRows($conn, "SELECT s.sales_id,s.sale_date,c.customer_name,p.project_name,p.status project_status,q.quotation_number,s.total_amount
            FROM sales s JOIN customers c ON c.customer_id=s.customer_id
            LEFT JOIN projects p ON p.project_id=s.project_id LEFT JOIN quotations q ON q.quotation_id=s.quotation_id
            WHERE s.$sWhere ORDER BY s.sale_date DESC,s.sales_id DESC LIMIT 100");
        $trendWhere = "s.deleted_at IS NULL";
        if ($sDate) $trendWhere .= ' AND ' . implode(' AND ', array_map(fn($x) => 's.' . $x, $sDate));
        $salesTrend = allRows($conn, "SELECT DATE_FORMAT(s.sale_date,'%Y-%m') month_key,DATE_FORMAT(s.sale_date,'%b %Y') month_label,COALESCE(SUM(s.total_amount),0) total FROM sales s WHERE $trendWhere GROUP BY DATE_FORMAT(s.sale_date,'%Y-%m'),DATE_FORMAT(s.sale_date,'%b %Y') ORDER BY month_key ASC");

        $invoiceWhere = whereDate('COALESCE(b.invoice_date,b.date_created)', $from, $to);
        $activeBilling = activeRecordClause($conn, 'project_billings', 'b');
        $activePayments = activeRecordClause($conn, 'project_billing_payments');
        $activeProjects = activeRecordClause($conn, 'projects', 'p');
        $activeCustomers = activeRecordClause($conn, 'customers', 'c');
        $activeQuotations = activeRecordClause($conn, 'quotations', 'q');
        $invoiceFilter = "$activeBilling AND $activeProjects AND $activeCustomers AND $activeQuotations AND q.status='APPROVED'";
        if ($invoiceWhere) $invoiceFilter .= ' AND ' . implode(' AND ', $invoiceWhere);
        $billing = one($conn, "SELECT
            COALESCE(SUM(CASE WHEN b.status<>'PLANNED' THEN b.amount ELSE 0 END),0) billed,
            COALESCE(SUM(CASE WHEN b.status<>'PLANNED' THEN COALESCE(pay.collected,0) ELSE 0 END),0) collected,
            COALESCE(SUM(CASE WHEN b.status<>'PLANNED' THEN GREATEST(b.amount-COALESCE(pay.collected,0),0) ELSE 0 END),0) outstanding,
            COALESCE(SUM(CASE WHEN b.status<>'PLANNED' AND b.due_date<CURDATE() AND b.amount>COALESCE(pay.collected,0) THEN 1 ELSE 0 END),0) overdueCount,
            COALESCE(SUM(CASE WHEN b.status<>'PLANNED' AND b.due_date<CURDATE() THEN GREATEST(b.amount-COALESCE(pay.collected,0),0) ELSE 0 END),0) overdue
            FROM project_billings b
            JOIN projects p ON p.project_id=b.project_id JOIN customers c ON c.customer_id=p.customer_id
            JOIN quotations q ON q.quotation_id=p.quotation_id
            LEFT JOIN (SELECT billing_id,SUM(amount) collected FROM project_billing_payments WHERE $activePayments GROUP BY billing_id) pay ON pay.billing_id=b.billing_id
            WHERE $invoiceFilter");
        $invoiceRows = allRows($conn, "SELECT b.billing_id,b.invoice_number,b.description,b.invoice_date,b.due_date,b.amount,
            COALESCE(pay.collected,0) collected,GREATEST(b.amount-COALESCE(pay.collected,0),0) balance,
            c.customer_name,p.project_name,q.quotation_number,
            CASE WHEN b.status='PLANNED' THEN 'DRAFT'
                 WHEN b.amount<=COALESCE(pay.collected,0)+0.005 THEN 'PAID'
                 WHEN b.due_date<CURDATE() THEN 'OVERDUE'
                 WHEN COALESCE(pay.collected,0)>0 THEN 'PARTIAL' ELSE 'UNPAID' END payment_status
            FROM project_billings b
            JOIN projects p ON p.project_id=b.project_id JOIN customers c ON c.customer_id=p.customer_id
            JOIN quotations q ON q.quotation_id=p.quotation_id
            LEFT JOIN (SELECT billing_id,SUM(amount) collected FROM project_billing_payments WHERE $activePayments GROUP BY billing_id) pay ON pay.billing_id=b.billing_id
            WHERE $invoiceFilter ORDER BY COALESCE(b.invoice_date,b.date_created) DESC,b.billing_id DESC LIMIT 100");
        $paymentDate = whereDate('pay.payment_date', $from, $to);
        $paymentFilter = $paymentDate ? implode(' AND ', $paymentDate) : '1=1';
        $activePayments = activeRecordClause($conn, 'project_billing_payments', 'pay');
        $activeBilling = activeRecordClause($conn, 'project_billings', 'b');
        $activeProjects = activeRecordClause($conn, 'projects', 'p');
        $activeCustomers = activeRecordClause($conn, 'customers', 'c');
        $paymentRows = allRows($conn, "SELECT pay.payment_id,pay.payment_date,pay.amount,pay.payment_method,pay.reference_no,
            CONCAT('PAY-',YEAR(pay.payment_date),'-',LPAD(pay.payment_id,6,'0')) payment_number,
            b.invoice_number,c.customer_name,p.project_name,COALESCE(u.username,'—') received_by
            FROM project_billing_payments pay
            JOIN project_billings b ON b.billing_id=pay.billing_id
            JOIN projects p ON p.project_id=b.project_id
            JOIN customers c ON c.customer_id=p.customer_id
            LEFT JOIN users u ON u.user_id=pay.received_by
            WHERE $activePayments AND $activeBilling AND $activeProjects AND $activeCustomers AND $paymentFilter
            ORDER BY pay.payment_date DESC,pay.payment_id DESC LIMIT 100");
    }

    sendJson([
        'from'=>$from,'to'=>$to,'canFinancial'=>$canFinancial,
        'quotationStatus'=>$quotationStatus,'projectStatus'=>$projectStatus,
        'inventory'=>$inventory,'lowStock'=>$lowStock,'inventoryMovements'=>$inventoryMovements,'projectMaterialUsage'=>$projectMaterialUsage,
        'financial'=>$financial,'billing'=>$billing,'invoices'=>$invoiceRows,'payments'=>$paymentRows,'sales'=>$salesRows,'salesTrend'=>$salesTrend
    ]);
}

sendError('Reports API route not found.', 404);
