(async function () {
    const $ = id => document.getElementById(id);
    const esc = CalixUI.escape;
    const account = (() => { try { return JSON.parse(sessionStorage.getItem('calixAccount') || 'null'); } catch (_) { return null; } })();
    const canViewFinancials = account?.role === 'ADMIN'
        || (account?.permissions || []).includes('reports.financial')
        || (account?.permissions || []).includes('sales.manage');
    let sales = [];
    if (!canViewFinancials) document.body.classList.add('sales-financial-restricted');

    function render() {
        const term = $('salesSearch').value.trim().toLowerCase();
        const visible = sales.filter(row => [row.customer_name,row.company_name,row.project_name,row.quotation_number]
            .filter(Boolean).join(' ').toLowerCase().includes(term));
        $('salesResultCount').textContent = `${visible.length} contract${visible.length === 1 ? '' : 's'}`;
        $('salesRows').innerHTML = visible.map(row => `<tr>
            <td>${CalixUI.date(row.sale_date)}</td>
            <td><strong>${esc(row.customer_name)}</strong><small class="record-subline">${esc(row.project_name || row.company_name || 'Legacy sales record')}</small></td>
            <td>${esc(row.quotation_number || '—')}</td>
            ${canViewFinancials ? `<td>${CalixUI.money(row.total_amount)}</td>` : ''}
            <td>${row.project_status ? CalixUI.status(row.project_status) : '<span class="muted">Legacy record</span>'}</td>
            <td>${CalixRecordDeletion.button('sales', row.sales_id, `Sale #${row.sales_id}`)}</td>
        </tr>`).join('') || `<tr><td colspan="${canViewFinancials ? 6 : 5}" class="empty-state">No sales contracts match this search.</td></tr>`;
    }

    async function load() {
        try {
            const [rows, summary] = await Promise.all([
                CalixAPI.get('sales.php?action=list'),
                CalixAPI.get('sales.php?action=summary')
            ]);
            sales = rows || [];
            $('salesCount').textContent = Number(summary.records || 0).toLocaleString('en-PH');
            if (canViewFinancials) {
                $('monthSales').textContent = CalixUI.money(summary.month_contract_value);
                $('totalContractValue').textContent = CalixUI.money(summary.contract_value);
            }
            render();
        } catch (error) {
            $('salesRows').innerHTML = `<tr><td colspan="${canViewFinancials ? 6 : 5}" class="empty-state">${esc(error.message || 'Sales could not be loaded.')}</td></tr>`;
        }
    }

    $('salesSearch').addEventListener('input', render);
    CalixRecordDeletion.bind($('salesRows'), load);
    window.addEventListener('calix:search', event => {
        $('salesSearch').value = event.detail?.query || '';
        render();
    });
    await load();
})();
