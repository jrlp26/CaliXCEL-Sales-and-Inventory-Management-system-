const form = document.querySelector('.login-form');
const userInput = document.getElementById('user');
const passwordInput = document.getElementById('password');
const loginError = document.getElementById('loginError');
const passwordToggle = document.getElementById('passwordToggle');
const submitButton = form.querySelector('button[type="submit"]');
const logoutError = sessionStorage.getItem('calixLogoutError');
const authNotice = sessionStorage.getItem('calixAuthNotice');
if (logoutError) {
    loginError.textContent = logoutError;
    sessionStorage.removeItem('calixLogoutError');
} else if (authNotice) {
    loginError.textContent = authNotice;
    sessionStorage.removeItem('calixAuthNotice');
}

[userInput, passwordInput].forEach(function (input) {
    input.addEventListener('input', function () {
        loginError.textContent = '';
        userInput.classList.remove('invalid');
        passwordInput.classList.remove('invalid');
    });
});

form.addEventListener('submit', async function (event) {
    event.preventDefault();
    loginError.textContent = '';
    userInput.classList.remove('invalid'); passwordInput.classList.remove('invalid');
    submitButton.disabled = true; submitButton.textContent = 'Signing in...';
    try {
        if (!userInput.value.trim() || !passwordInput.value) {
            loginError.textContent = 'Enter your username and password.';
            userInput.classList.toggle('invalid', !userInput.value.trim());
            passwordInput.classList.toggle('invalid', !passwordInput.value);
            return;
        }
        const account = await CalixAPI.post('auth.php?action=login', {username:userInput.value.trim(), password:passwordInput.value});
        sessionStorage.setItem('calixAccount', JSON.stringify(account));
        window.location.href = 'Dashboard.html';
    } catch (error) {
        loginError.textContent = error.message;
        userInput.classList.add('invalid'); passwordInput.classList.add('invalid');
    } finally {
        submitButton.disabled = false; submitButton.textContent = 'Sign in';
    }
});

passwordToggle.addEventListener('click', function () {
    const showing = passwordInput.type === 'text';
    passwordInput.type = showing ? 'password' : 'text';
    passwordToggle.setAttribute('aria-pressed', showing ? 'false' : 'true');
    passwordToggle.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
});
