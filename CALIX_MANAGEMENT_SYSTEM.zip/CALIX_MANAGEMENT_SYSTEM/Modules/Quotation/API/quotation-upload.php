<?php
require __DIR__ . '/../../../api/common.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Upload route requires POST.', 405);
}

requirePermission($conn, 'quotations.manage');

if (empty($_FILES['file']) || !is_array($_FILES['file'])) {
    sendError('Choose an image to upload.');
}

$file = $_FILES['file'];
$error = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
if ($error !== UPLOAD_ERR_OK) {
    $messages = [
        UPLOAD_ERR_INI_SIZE => 'The image exceeds the server upload limit.',
        UPLOAD_ERR_FORM_SIZE => 'The image is too large.',
        UPLOAD_ERR_PARTIAL => 'The image upload was interrupted.',
        UPLOAD_ERR_NO_FILE => 'Choose an image to upload.'
    ];
    sendError($messages[$error] ?? 'Image upload failed.');
}

$size = (int) ($file['size'] ?? 0);
if ($size <= 0 || $size > 5 * 1024 * 1024) {
    sendError('Image must be 5 MB or smaller.');
}

$tmp = (string) ($file['tmp_name'] ?? '');
if ($tmp === '' || !is_uploaded_file($tmp)) {
    sendError('Uploaded image could not be verified.');
}

$image = @getimagesize($tmp);
if ($image === false || empty($image['mime'])) {
    sendError('The uploaded file is not a valid image.');
}

$mime = '';
if (function_exists('finfo_open')) {
    $info = finfo_open(FILEINFO_MIME_TYPE);
    if ($info) {
        $mime = (string) finfo_file($info, $tmp);
        finfo_close($info);
    }
}
if ($mime === '') {
    $mime = (string)$image['mime'];
}
if ($mime !== $image['mime']) {
    sendError('The uploaded image content could not be verified.');
}

$extensions = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/webp' => 'webp'
];
if (!isset($extensions[$mime])) {
    sendError('Only JPG, PNG, or WEBP images are allowed.');
}

$uploadDir = dirname(__DIR__) . '/uploads/quotation_drawings';
if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true)) {
    sendError('Quotation drawing folder could not be created.', 500);
}

try {
    $token = bin2hex(random_bytes(6));
} catch (Throwable $e) {
    error_log('Unable to generate a secure quotation drawing filename: ' . $e->getMessage());
    sendError('A secure image filename could not be generated.', 500);
}
$name = 'drawing_' . date('Ymd_His') . '_' . $token . '.' . $extensions[$mime];
$destination = $uploadDir . '/' . $name;

if (!move_uploaded_file($tmp, $destination)) {
    sendError('Image could not be saved.', 500);
}

sendJson(['path' => '../uploads/quotation_drawings/' . $name], 201);
