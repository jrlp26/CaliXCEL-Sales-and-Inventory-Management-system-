<?php
require __DIR__ . '/../../../api/common.php';

function itemRow(array $row): array {
    return [
        'id' => (string)$row['material_id'],
        'itemCode' => $row['item_code'],
        'itemName' => $row['material_name'],
        'category' => $row['category'] ?: 'Other',
        'unit' => $row['unit'],
        'quantity' => (float)$row['quantity'],
        'reorderLevel' => (float)$row['reorder_level'],
        'unitCost' => (float)$row['unit_cost'],
        'sellingPrice' => (float)$row['selling_price'],
        'supplier' => $row['supplier'] ?? '',
        'location' => $row['storage_location'] ?? '',
        'description' => $row['description'] ?? '',
        'createdAt' => $row['date_added'],
        'updatedAt' => $row['updated_at']
    ];
}


function validateInventoryText(string $itemCode, string $itemName, string $category, string $unit, string $supplier, string $location, string $description): void {
    if (strlen($itemCode) > 30) sendError('Item code must be 30 characters or fewer.', 422);
    if (strlen($itemName) > 100) sendError('Item name must be 100 characters or fewer.', 422);
    if (strlen($category) > 50) sendError('Category must be 50 characters or fewer.', 422);
    if (strlen($unit) > 20) sendError('Unit must be 20 characters or fewer.', 422);
    if (strlen($supplier) > 150) sendError('Supplier must be 150 characters or fewer.', 422);
    if (strlen($location) > 100) sendError('Storage location must be 100 characters or fewer.', 422);
    if (strlen($description) > 500) sendError('Description must be 500 characters or fewer.', 422);
}

function inventoryNumber($value, string $label, float $maximum): float {
    if (!is_numeric($value) || !is_finite((float)$value)) {
        sendError("Enter a valid $label.", 422);
    }
    $number = (float)$value;
    if ($number < 0) sendError("$label cannot be negative.", 422);
    if ($number > $maximum) sendError("$label exceeds the supported maximum.", 422);
    if (abs($number - round($number, 2)) > 0.00000001) {
        sendError("$label can have no more than two decimal places.", 422);
    }
    return $number;
}

function getItem(mysqli $conn, int $id): array {
    $stmt = $conn->prepare('SELECT * FROM inventory WHERE material_id = ? AND deleted_at IS NULL');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();

    if (!$row) {
        sendError('Inventory item not found.', 404);
    }
    return itemRow($row);
}

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

if ($action === 'defaults' && $method === 'GET') {
    requirePermission($conn, 'inventory.manage');
    $setting = one($conn, "SELECT setting_value FROM business_settings WHERE setting_key='inventory_default_reorder_level'");
    sendJson(['reorderLevel' => is_numeric($setting['setting_value'] ?? null) ? (float)$setting['setting_value'] : 5]);
}

if ($action === 'project-options' && $method === 'GET') {
    requirePermission($conn, 'inventory.manage');
    sendJson(allRows($conn, "SELECT p.project_id,p.project_name,c.customer_name
        FROM projects p
        JOIN customers c ON c.customer_id=p.customer_id
        JOIN quotations q ON q.quotation_id=p.quotation_id
        WHERE p.deleted_at IS NULL AND c.deleted_at IS NULL AND q.deleted_at IS NULL AND q.status='APPROVED'
        ORDER BY p.project_name,c.customer_name"));
}

if ($action === 'history' && $method === 'GET') {
    requirePermission($conn, 'inventory.view');
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) sendError('Invalid inventory item ID.', 422);
    $dateColumn = dbColumnExists($conn, 'inventory_transactions', 'transaction_date')
        ? 'transaction_date'
        : (dbColumnExists($conn, 'inventory_transactions', 'date_created') ? 'date_created' : '');
    if ($dateColumn === '') sendError('Inventory movement history is unavailable in this database schema.', 503);
    sendJson(allRows($conn, "SELECT t.transaction_type,t.quantity,t.remarks,t.$dateColumn movement_date,
        COALESCE(u.username,'—') username,p.project_name
        FROM inventory_transactions t
        LEFT JOIN users u ON u.user_id=t.user_id
        LEFT JOIN projects p ON p.project_id=t.project_id
        WHERE t.material_id=?
        ORDER BY t.$dateColumn DESC LIMIT 100",'i',[$id]));
}

if ($action === 'list' && $method === 'GET') {
    requirePermission($conn, 'inventory.view');
    $result = $conn->query('SELECT * FROM inventory WHERE deleted_at IS NULL ORDER BY material_id DESC');
    $items = [];
    while ($row = $result->fetch_assoc()) {
        $items[] = itemRow($row);
    }
    sendJson($items);
}

if ($action === 'get' && $method === 'GET') {
    requirePermission($conn, 'inventory.view');
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) sendError('Invalid inventory item ID.');
    sendJson(getItem($conn, $id));
}

if ($action === 'create' && $method === 'POST') {
    $currentUser = requirePermission($conn, 'inventory.manage');
    $body = body();

    $itemCode = strtoupper(trim((string)($body['itemCode'] ?? '')));
    $itemName = trim((string)($body['itemName'] ?? ''));
    $category = trim((string)($body['category'] ?? 'Other'));
    $unit = trim((string)($body['unit'] ?? 'Piece'));
    $quantity = inventoryNumber($body['quantity'] ?? 0, 'Quantity', 99999999.99);
    $defaultReorder = one($conn, "SELECT setting_value FROM business_settings WHERE setting_key='inventory_default_reorder_level'");
    $defaultReorderLevel = is_numeric($defaultReorder['setting_value'] ?? null) ? $defaultReorder['setting_value'] : 5;
    $reorderLevel = inventoryNumber($body['reorderLevel'] ?? $defaultReorderLevel, 'Reorder level', 99999999.99);
    $unitCost = inventoryNumber($body['unitCost'] ?? 0, 'Unit cost', 9999999999.99);
    $sellingPrice = inventoryNumber($body['sellingPrice'] ?? 0, 'Selling price', 9999999999.99);
    $supplier = trim((string)($body['supplier'] ?? ''));
    $location = trim((string)($body['location'] ?? ''));
    $description = trim((string)($body['description'] ?? ''));

    if ($itemCode === '' || $itemName === '' || $unit === '') {
        sendError('Item code, item name, and unit are required.', 422);
    }
    validateInventoryText($itemCode, $itemName, $category, $unit, $supplier, $location, $description);
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare('INSERT INTO inventory (item_code, material_name, category, quantity, unit, reorder_level, unit_cost, selling_price, supplier, storage_location, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->bind_param('sssdsdddsss', $itemCode, $itemName, $category, $quantity, $unit, $reorderLevel, $unitCost, $sellingPrice, $supplier, $location, $description);
        $stmt->execute();
        $id = $stmt->insert_id;
        $stmt->close();

        if ($quantity > 0) {
            $type = 'IN';
            $remarks = 'Opening stock';
            $userId = (int)$currentUser['user_id'];
            $movement = $conn->prepare('INSERT INTO inventory_transactions (material_id, user_id, transaction_type, quantity, remarks) VALUES (?, ?, ?, ?, ?)');
            $movement->bind_param('iisds', $id, $userId, $type, $quantity, $remarks);
            $movement->execute();
            $movement->close();
        }

        auditEvent($conn, $currentUser, 'created', 'inventory', (int)$id, ['item_code' => $itemCode, 'opening_quantity' => $quantity]);
        $conn->commit();
        sendJson(getItem($conn, $id), 201);
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        error_log('Inventory creation failed: ' . $e->getMessage());
        if ((int)$e->getCode() === 1062) {
            sendError('That item code is already in use.', 409);
        }
        sendError('The inventory item could not be saved.', 500);
    }
}

if ($action === 'update' && ($method === 'PATCH' || $method === 'POST')) {
    $currentUser = requirePermission($conn, 'inventory.manage');
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) sendError('Invalid inventory item ID.');
    $current = getItem($conn, $id);
    $body = body();

    $itemCode = strtoupper(trim((string)($body['itemCode'] ?? $current['itemCode'])));
    $itemName = trim((string)($body['itemName'] ?? $current['itemName']));
    $category = trim((string)($body['category'] ?? $current['category']));
    $unit = trim((string)($body['unit'] ?? $current['unit']));
    $reorderLevel = inventoryNumber($body['reorderLevel'] ?? $current['reorderLevel'], 'Reorder level', 99999999.99);
    $unitCost = inventoryNumber($body['unitCost'] ?? $current['unitCost'], 'Unit cost', 9999999999.99);
    $sellingPrice = inventoryNumber($body['sellingPrice'] ?? $current['sellingPrice'], 'Selling price', 9999999999.99);
    $supplier = trim((string)($body['supplier'] ?? $current['supplier']));
    $location = trim((string)($body['location'] ?? $current['location']));
    $description = trim((string)($body['description'] ?? $current['description']));

    if ($itemCode === '' || $itemName === '' || $unit === '') sendError('Item code, item name, and unit are required.', 422);
    validateInventoryText($itemCode, $itemName, $category, $unit, $supplier, $location, $description);
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare('UPDATE inventory SET item_code=?, material_name=?, category=?, unit=?, reorder_level=?, unit_cost=?, selling_price=?, supplier=?, storage_location=?, description=? WHERE material_id=? AND deleted_at IS NULL');
        $stmt->bind_param('ssssdddsssi', $itemCode, $itemName, $category, $unit, $reorderLevel, $unitCost, $sellingPrice, $supplier, $location, $description, $id);
        $stmt->execute();
        $stmt->close();
        auditEvent($conn, $currentUser, 'updated', 'inventory', $id, ['item_code' => $itemCode, 'material_name' => $itemName]);
        $conn->commit();
        sendJson(getItem($conn, $id));
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        error_log('Inventory update failed: ' . $e->getMessage());
        if ((int)$e->getCode() === 1062) sendError('That item code is already in use.', 409);
        sendError('The inventory item could not be updated.', 500);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Inventory update failed: ' . $e->getMessage());
        sendError('The inventory item could not be updated.', 500);
    }
}

if ($action === 'movement' && $method === 'POST') {
    $currentUser = requirePermission($conn, 'inventory.manage');
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) sendError('Invalid inventory item ID.');
    $body = body();
    $movementType = (string)($body['movementType'] ?? '');
    $quantity = inventoryNumber($body['quantity'] ?? null, 'Quantity', 99999999.99);
    $reason = trim((string)($body['reason'] ?? ''));
    $projectId = (int)($body['projectId'] ?? 0);

    if (!in_array($movementType, ['stock_in', 'stock_out'], true)) sendError('Select a valid stock movement.', 422);
    if ($quantity <= 0) sendError('Enter a quantity greater than zero.', 422);
    if ($reason === '') sendError('Enter a reason or reference for the stock movement.', 422);
    if (strlen($reason) > 255) sendError('Movement reason must be 255 characters or fewer.', 422);
    if ($movementType === 'stock_in' && $projectId > 0) sendError('A destination project can only be linked to stock-out movements.', 422);
    if ($movementType === 'stock_out' && $projectId > 0) {
        $project = one($conn, "SELECT p.project_id FROM projects p
            JOIN quotations q ON q.quotation_id=p.quotation_id
            WHERE p.project_id=? AND p.deleted_at IS NULL AND q.deleted_at IS NULL AND q.status='APPROVED'", 'i', [$projectId]);
        if (!$project) sendError('Select an active project linked to an approved quotation.', 422);
    }

    $conn->begin_transaction();
    try {
        $lock = $conn->prepare('SELECT quantity FROM inventory WHERE material_id=? AND deleted_at IS NULL FOR UPDATE');
        $lock->bind_param('i', $id);
        $lock->execute();
        $row = $lock->get_result()->fetch_assoc();
        $lock->close();
        if (!$row) throw new RuntimeException('not_found');

        $currentQuantity = (float)$row['quantity'];
        $newQuantity = $movementType === 'stock_in' ? $currentQuantity + $quantity : $currentQuantity - $quantity;
        $newQuantity = round($newQuantity, 2);
        if ($newQuantity > 99999999.99) {
            $conn->rollback();
            sendError('The resulting stock quantity exceeds the supported maximum.', 422);
        }
        if ($newQuantity < 0) {
            $conn->rollback();
            sendError('Stock out cannot be greater than the available quantity.');
        }

        $update = $conn->prepare('UPDATE inventory SET quantity=? WHERE material_id=? AND deleted_at IS NULL');
        $update->bind_param('di', $newQuantity, $id);
        $update->execute();
        $update->close();

        $dbType = $movementType === 'stock_in' ? 'IN' : 'OUT';
        $userId = (int)$currentUser['user_id'];
        $projectParam = $projectId > 0 ? $projectId : null;
        $movement = $conn->prepare('INSERT INTO inventory_transactions (material_id, user_id, transaction_type, quantity, project_id, remarks) VALUES (?, ?, ?, ?, ?, ?)');
        $movement->bind_param('iisdis', $id, $userId, $dbType, $quantity, $projectParam, $reason);
        $movement->execute();
        $transactionId = (int)$movement->insert_id;
        $movement->close();

        auditEvent($conn, $currentUser, $movementType, 'inventory', $id, [
            'transaction_id' => $transactionId,
            'quantity' => $quantity,
            'balance_before' => $currentQuantity,
            'balance_after' => $newQuantity,
            'project_id' => $projectParam,
            'reason' => $reason
        ]);
        $conn->commit();
        sendJson(getItem($conn, $id));
    } catch (RuntimeException $e) {
        $conn->rollback();
        if ($e->getMessage() === 'not_found') sendError('Inventory item not found.', 404);
        error_log('Inventory stock adjustment failed: ' . $e->getMessage());
        sendError('Stock could not be adjusted.', 500);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Inventory stock adjustment failed: ' . $e->getMessage());
        sendError('Stock could not be adjusted.', 500);
    }
}

sendError('Inventory API route not found.', 404);
