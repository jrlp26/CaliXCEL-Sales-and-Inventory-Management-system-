<?php
require_once __DIR__ . '/db.php';

set_exception_handler(static function (Throwable $exception): void {
    error_log('[CALIX API] Unhandled ' . get_class($exception) . ' (' . $exception->getCode() . '): ' . $exception->getMessage());
    if (headers_sent()) return;
    $status = 500;
    $message = 'CALIX could not complete this request because of a server error. Please retry; if it continues, contact your administrator.';
    $code = 'internal_error';
    if ($exception instanceof mysqli_sql_exception) {
        switch ((int)$exception->getCode()) {
            case 1062:
                $status = 409;
                $message = 'A record with this unique value already exists. Check the reference or name and try again.';
                $code = 'duplicate_record';
                break;
            case 1451:
            case 1452:
                $status = 409;
                $message = 'This record is linked to other information and cannot be changed or removed yet. Review its related records and try again.';
                $code = 'related_records';
                break;
            case 1048:
            case 1364:
                $status = 422;
                $message = 'A required value is missing. Complete the required fields and try again.';
                $code = 'required_value';
                break;
            case 1406:
                $status = 422;
                $message = 'One or more values are too long. Shorten the highlighted information and try again.';
                $code = 'value_too_long';
                break;
            case 1146:
                $status = 503;
                $message = 'This workflow needs the current CALIX database schema. Back up the database, then apply Database/calix_existing_database_upgrade.sql.';
                $code = 'schema_upgrade_required';
                break;
        }
    }
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'error' => $message,
        'code' => $code
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
});

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}
header('Content-Type: application/json; charset=utf-8');

function sendJson($data, int $status = 200): void {
    http_response_code($status);
    echo json_encode(['success'=>true,'data'=>$data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function apiErrorCode(int $status): string {
    switch ($status) {
        case 401: return 'unauthorized';
        case 403: return 'forbidden';
        case 404: return 'not_found';
        case 409: return 'conflict';
        case 422: return 'validation_error';
        case 503: return 'service_unavailable';
        default: return $status >= 500 ? 'server_error' : 'request_error';
    }
}
function requireSameOriginMutation(): void {
    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if (!in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) return;

    $originValue = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
    if ($originValue === '') $originValue = (string)($_SERVER['HTTP_REFERER'] ?? '');
    $origin = parse_url($originValue);
    $requestHost = parse_url('//' . (string)($_SERVER['HTTP_HOST'] ?? ''));
    if (!$origin || !$requestHost || empty($origin['scheme']) || empty($origin['host']) || empty($requestHost['host'])) {
        sendError('This request could not be verified as coming from CALIX. Reload the page and try again.', 403);
    }

    $originScheme = strtolower((string)$origin['scheme']);
    $requestScheme = !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off' ? 'https' : 'http';
    $originPort = (int)($origin['port'] ?? ($originScheme === 'https' ? 443 : 80));
    $requestPort = (int)($requestHost['port'] ?? ($requestScheme === 'https' ? 443 : 80));
    if (!in_array($originScheme, ['http', 'https'], true)
        || $originScheme !== $requestScheme
        || strtolower((string)$origin['host']) !== strtolower((string)$requestHost['host'])
        || $originPort !== $requestPort) {
        sendError('This request could not be verified as coming from CALIX. Reload the page and try again.', 403);
    }
}
function sendError(string $message, int $status = 400, array $details = []): void {
    http_response_code($status);
    $payload = ['success'=>false,'error'=>$message,'code'=>apiErrorCode($status)];
    if ($details) $payload['details'] = $details;
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
requireSameOriginMutation();
function sendFieldError(string $field, string $message): void {
    sendError($message, 422, ['fields' => [$field => $message]]);
}
function body(): array {
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') return [];
    $data = json_decode($raw, true);
    if (!is_array($data)) sendError('Invalid JSON request.', 400);
    return $data;
}
function allRows(mysqli $conn, string $sql, string $types = '', array $params = []): array {
    if ($types === '') {
        $result = $conn->query($sql); $rows=[];
        while ($row=$result->fetch_assoc()) $rows[]=$row;
        return $rows;
    }
    $stmt=$conn->prepare($sql);
    if (!$stmt) throw new RuntimeException('Unable to prepare database request.');
    $stmt->bind_param($types, ...$params); $stmt->execute(); $result=$stmt->get_result(); $rows=[];
    while ($row=$result->fetch_assoc()) $rows[]=$row;
    $stmt->close(); return $rows;
}
function one(mysqli $conn, string $sql, string $types = '', array $params = []): ?array {
    $rows=allRows($conn,$sql,$types,$params); return $rows[0]??null;
}
function dbTableExists(mysqli $conn, string $table): bool {
    static $cache = [];
    $key = spl_object_id($conn) . ':' . $table;
    if (!array_key_exists($key, $cache)) {
        $row=one($conn,'SELECT COUNT(*) c FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?','s',[$table]);
        $cache[$key] = (int)($row['c']??0)>0;
    }
    return $cache[$key];
}
function dbColumnExists(mysqli $conn, string $table, string $column): bool {
    static $cache = [];
    $key = spl_object_id($conn) . ':' . $table . ':' . $column;
    if (!array_key_exists($key, $cache)) {
        $row=one($conn,'SELECT COUNT(*) c FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?','ss',[$table,$column]);
        $cache[$key] = (int)($row['c']??0)>0;
    }
    return $cache[$key];
}
function activeRecordClause(mysqli $conn, string $table, string $alias = ''): string {
    return dbColumnExists($conn, $table, 'deleted_at')
        ? ($alias !== '' ? $alias . '.' : '') . 'deleted_at IS NULL'
        : '1=1';
}
function currentUser(mysqli $conn): array {
    $uid=(int)($_SESSION['calix_user_id']??0);
    if ($uid<=0) sendError('Your session has expired. Please sign in again.',401);
    $deletedClause=dbColumnExists($conn,'users','deleted_at')?' AND deleted_at IS NULL':'';
    $user=one($conn,'SELECT user_id,username,role,COALESCE(is_active,1) is_active FROM users WHERE user_id=?'.$deletedClause,'i',[$uid]);
    if (!$user || !(int)$user['is_active']) {
        session_unset(); session_destroy();
        sendError('Your account is inactive or no longer available.',401);
    }
    return $user;
}
function userPermissions(mysqli $conn, string $role): array {
    if ($role==='ADMIN') return array_column(allRows($conn,'SELECT permission_key FROM permissions ORDER BY permission_key'),'permission_key');
    $allowed=dbColumnExists($conn,'role_permissions','allowed')?' AND COALESCE(allowed,1)=1':'';
    return array_column(allRows($conn,'SELECT permission_key FROM role_permissions WHERE role_key=?'.$allowed.' ORDER BY permission_key','s',[$role]),'permission_key');
}
function ensureProjectSalesRecord(mysqli $conn, int $projectId, array $actor): void {
    $project=one($conn,"SELECT p.project_id,p.customer_id,p.quotation_id,p.contract_amount
        FROM projects p JOIN quotations q ON q.quotation_id=p.quotation_id
        WHERE p.project_id=? AND p.deleted_at IS NULL AND q.deleted_at IS NULL AND q.status='APPROVED'
        FOR UPDATE",'i',[$projectId]);
    if (!$project) throw new RuntimeException('Approved project was not available for Sales setup.');
    if (one($conn,'SELECT sales_id FROM sales WHERE project_id=? AND deleted_at IS NULL LIMIT 1','i',[$projectId])) return;

    $customerId=(int)$project['customer_id'];
    $quotationId=(int)$project['quotation_id'];
    $total=(float)$project['contract_amount'];
    $unpaid='UNPAID';
    try {
        $stmt=$conn->prepare("INSERT INTO sales(customer_id,project_id,quotation_id,total_amount,amount_paid,billing_paid_total,payment_status,sale_date)
            VALUES(?,?,?, ?,0,0,?,CURRENT_TIMESTAMP)");
        $stmt->bind_param('iiids',$customerId,$projectId,$quotationId,$total,$unpaid);
        $stmt->execute();
        $salesId=(int)$stmt->insert_id;
        $stmt->close();
        auditEvent($conn,$actor,'created_from_project','sale',$salesId,['project_id'=>$projectId,'quotation_id'=>$quotationId],null,'UNPAID');
    } catch (mysqli_sql_exception $e) {
        if ((int)$e->getCode()===1062 && one($conn,'SELECT sales_id FROM sales WHERE project_id=? AND deleted_at IS NULL LIMIT 1','i',[$projectId])) return;
        throw $e;
    }
}
function ensureProjectPaymentMilestones(mysqli $conn, int $projectId, float $contractAmount): void {
    $contractAmount=round($contractAmount,2);
    if ($projectId<=0 || $contractAmount<=0) throw new RuntimeException('A positive project contract is required to create payment milestones.');
    $milestones=[
        ['DOWN_PAYMENT','Down Payment',50.00,round($contractAmount*0.50,2)],
        ['DELIVERY','Materials Delivery',30.00,round($contractAmount*0.30,2)]
    ];
    $milestones[]=['FINAL_BALANCE','Final Balance',20.00,round($contractAmount-$milestones[0][3]-$milestones[1][3],2)];
    $stmt=$conn->prepare('INSERT INTO project_payment_milestones(project_id,milestone_key,label,percentage,amount) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE milestone_id=milestone_id');
    foreach ($milestones as [$key,$label,$percentage,$amount]) {
        $stmt->bind_param('issdd',$projectId,$key,$label,$percentage,$amount);
        $stmt->execute();
    }
    $stmt->close();
}
function projectMilestoneStatus(mysqli $conn, int $projectId, string $milestoneKey): ?array {
    $activeSales = activeRecordClause($conn, 'sales');
    $activeBillings = activeRecordClause($conn, 'project_billings', 'b');
    $activePayments = activeRecordClause($conn, 'project_billing_payments', 'pay');
    $milestone=one($conn,"SELECT m.milestone_id,m.project_id,m.milestone_key,m.label,m.percentage,m.amount,
            m.billing_id,COALESCE(s.opening_paid,0) opening_paid,
            COALESCE(paid.total_collected,0) billed_collected,
            COALESCE((SELECT SUM(prior.amount) FROM project_payment_milestones prior
                WHERE prior.project_id=m.project_id
                AND FIELD(prior.milestone_key,'DOWN_PAYMENT','DELIVERY','FINAL_BALANCE')
                    < FIELD(m.milestone_key,'DOWN_PAYMENT','DELIVERY','FINAL_BALANCE')),0) preceding_amount
        FROM project_payment_milestones m
        LEFT JOIN (SELECT project_id,MAX(GREATEST(amount_paid-billing_paid_total,0)) opening_paid
            FROM sales WHERE $activeSales GROUP BY project_id) s ON s.project_id=m.project_id
        LEFT JOIN (SELECT b.project_id,SUM(pay.amount) total_collected
            FROM project_billings b JOIN project_billing_payments pay ON pay.billing_id=b.billing_id
            WHERE $activeBillings AND $activePayments
            GROUP BY b.project_id) paid ON paid.project_id=m.project_id
        WHERE m.project_id=? AND m.milestone_key=?",'is',[$projectId,$milestoneKey]);
    if (!$milestone) return null;
    $milestone['total_collected']=(float)$milestone['opening_paid']+(float)$milestone['billed_collected'];
    $milestone['collected']=min((float)$milestone['amount'],max(0,$milestone['total_collected']-(float)$milestone['preceding_amount']));
    $milestone['paid']=$milestone['total_collected']+0.005 >= (float)$milestone['preceding_amount']+(float)$milestone['amount'];
    $milestone['remaining']=max(0,(float)$milestone['preceding_amount']+(float)$milestone['amount']-$milestone['total_collected']);
    return $milestone;
}
function projectDownPaymentSatisfied(mysqli $conn, int $projectId): bool {
    $status=projectMilestoneStatus($conn,$projectId,'DOWN_PAYMENT');
    return $status !== null && (bool)$status['paid'];
}
function requirePermission(mysqli $conn, string $permission): array {
    $user=currentUser($conn); $permissions=userPermissions($conn,$user['role']);
    if ($user['role']!=='ADMIN' && !in_array($permission,$permissions,true)) sendError('You do not have permission to perform this action.',403);
    $user['permissions']=$permissions; return $user;
}
function auditEvent(mysqli $conn, array $user, string $action, string $entityType, int $entityId, array $details = [], ?string $previousStatus = null, ?string $newStatus = null): void {
    $detailsJson=$details ? json_encode($details,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : null;
    if ($detailsJson===false) throw new RuntimeException('Audit details could not be encoded.');
    $userId=(int)$user['user_id'];
    $username=(string)($user['username']??'Unknown user');
    $stmt=$conn->prepare('INSERT INTO system_audit_log(user_id,username,action_key,entity_type,entity_id,previous_status,new_status,details_json) VALUES(?,?,?,?,?,?,?,?)');
    $stmt->bind_param('isssisss',$userId,$username,$action,$entityType,$entityId,$previousStatus,$newStatus,$detailsJson);
    $stmt->execute();
    $stmt->close();
}
function softDelete(mysqli $conn, string $table, string $idColumn, int $id, array $user): void {
    $allowed=['quotations','projects','customers','sales','inventory'];
    if (!in_array($table,$allowed,true)) sendError('Unsupported delete operation.',400);
    $stmt=$conn->prepare("UPDATE `$table` SET deleted_at=CURRENT_TIMESTAMP,deleted_by=? WHERE `$idColumn`=? AND deleted_at IS NULL");
    $uid=(int)$user['user_id']; $stmt->bind_param('ii',$uid,$id); $stmt->execute();
    if ($stmt->affected_rows<1) {$stmt->close();sendError('Record not found or already deleted.',404);} $stmt->close();
    auditEvent($conn,$user,'deleted',$table,$id);
}
