<?php require __DIR__ . '/../../../api/common.php';
require_once __DIR__ . '/quotation-project.php';
$a = $_GET['action'] ?? 'list';
$m = $_SERVER['REQUEST_METHOD'];
function resolveQuotationCustomer(mysqli $c, array $b, int $fallback = 0): int
{
    $cid = (int) ($b['customerId'] ?? $fallback);
    if ($cid <= 0) {
        sendError('Select an existing customer or add a new customer before saving the quotation.');
    }
    $customer = one($c, 'SELECT customer_id FROM customers WHERE customer_id=? AND deleted_at IS NULL', 'i', [$cid]);
    if (!$customer) {
        sendError('The selected customer is no longer available. Refresh the customer list and try again.', 404);
    }
    return (int) $customer['customer_id'];
}
function qrow(mysqli $c, int $id): array
{
    $q = one($c, 'SELECT q.*,c.customer_name,c.company_name,c.contact_number,c.email,c.address customer_address FROM quotations q JOIN customers c ON c.customer_id=q.customer_id WHERE q.quotation_id=? AND q.deleted_at IS NULL', 'i', [$id]);
    if (!$q)
        sendError('Quotation not found.', 404);
    $q['items'] = allRows($c, 'SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY item_id', 'i', [$id]);
    return $q;
}
function quotationDrawingFiles(array $items): array
{
    $files = [];
    foreach ($items as $item) {
        $drawings = $item['drawing_images'] ?? [];
        if (is_string($drawings)) {
            $decoded = json_decode($drawings, true);
            $drawings = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($drawings))
            $drawings = [];
        $legacy = (string) ($item['drawing_image'] ?? '');
        if ($legacy !== '')
            $drawings[] = $legacy;

        foreach ($drawings as $drawing) {
            if (preg_match('#^\\.\\./uploads/quotation_drawings/(drawing_[0-9]{8}_[0-9]{6}_[a-f0-9]{12}\\.(?:jpg|png|webp))$#i', (string) $drawing, $match)) {
                $files[$match[1]] = true;
            }
        }
    }
    return array_keys($files);
}
function removeUnreferencedQuotationDrawings(mysqli $conn, array $files): void
{
    $directory = __DIR__ . '/../uploads/quotation_drawings/';
    foreach ($files as $file) {
        $storedPath = '../uploads/quotation_drawings/' . $file;
        $pattern = '%"' . strtr($storedPath, ['!' => '!!', '%' => '!%', '_' => '!_']) . '"%';
        $reference = one(
            $conn,
            "SELECT item_id FROM quotation_items WHERE drawing_image=? OR drawing_images LIKE ? ESCAPE '!' LIMIT 1",
            'ss',
            [$storedPath, $pattern]
        );
        if ($reference)
            continue;

        $path = $directory . $file;
        if (is_file($path) && !unlink($path)) {
            error_log('Unable to remove an unreferenced quotation drawing: ' . $file);
        }
    }
}
function validateQuotationDate(string $value, string $label): string
{
    $value = trim($value);
    if ($value === '')
        return '';
    $date = DateTime::createFromFormat('Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value)
        sendError("Enter a valid $label date.", 422);
    return $value;
}
function nextQuotationNumber(mysqli $conn, string $year): string
{
    $prefix = $year . '-';
    $maxSequence = 0;
    foreach (allRows($conn, 'SELECT quotation_number FROM quotations WHERE quotation_number LIKE ?', 's', [$prefix . '%']) as $row) {
        if (preg_match('/^' . preg_quote($year, '/') . '-([0-9]{3,})$/D', (string) $row['quotation_number'], $match)) {
            $maxSequence = max($maxSequence, (int) $match[1]);
        }
    }
    $sequence = $maxSequence + 1;
    do {
        $candidate = $prefix . str_pad((string) $sequence, 3, '0', STR_PAD_LEFT);
        $exists = one($conn, 'SELECT quotation_id FROM quotations WHERE quotation_number=? LIMIT 1', 's', [$candidate]);
        if ($exists)
            $sequence++;
    } while ($exists);
    return $candidate;
}
function validateNewQuotationNumber(string $number, string $quotationDate): void
{
    $year = $quotationDate !== '' ? substr($quotationDate, 0, 4) : date('Y');
    if (!preg_match('/^' . preg_quote($year, '/') . '-[0-9]{3,}$/D', $number)) {
        sendError("New quotation numbers must use the $year-NNN format.", 422);
    }
}
function validateProjectDurationDays($value, ?int $fallback = null): ?int
{
    if ($value === null)
        return $fallback;
    if ($value === '')
        return null;
    $days = filter_var($value, FILTER_VALIDATE_INT);
    if ($days === false || $days < 1 || $days > 3650) {
        sendError('Estimated project duration must be between 1 and 3650 whole days.', 422);
    }
    return $days;
}
function validateQuotationHeader(string $number, string $projectName, string $projectAddress, string $vatType, float $discount): void
{
    if ($number === '')
        sendError('Quotation number is required.', 422);
    if (strlen($number) > 30)
        sendError('Quotation number must be 30 characters or fewer.', 422);
    if (strlen($projectName) > 150)
        sendError('Project name must be 150 characters or fewer.', 422);
    if (strlen($projectAddress) > 255)
        sendError('Project location must be 255 characters or fewer.', 422);
    if (!in_array($vatType, ['VAT EXCLUSIVE', 'VAT INCLUSIVE', 'NON-VAT'], true))
        sendError('Select a valid VAT treatment.', 422);
    if ($discount < 0 || $discount > 100)
        sendError('Discount must be between 0 and 100 percent.', 422);
}
function qsettings(mysqli $c): array
{
    $out = [];
    foreach (allRows($c, "SELECT setting_key,setting_value FROM business_settings WHERE setting_key IN ('business_name','contact_number','email','address','quotation_prefix','default_validity_days','default_project_duration_days','default_vat_rate','default_payment_terms','default_vat_type','default_fabrication_terms','default_acceptance_statement','authorized_representative','authorized_representative_position','authorized_representative_signature')") as $r)
        $out[$r['setting_key']] = $r['setting_value'];
    return $out;
}
function quotationTotals(float $subtotal, float $discountPercent, string $vatType, float $vatRate): array
{
    if (!is_finite($subtotal) || !is_finite($discountPercent) || !is_finite($vatRate)) {
        sendError('Quotation prices must be valid finite numbers.', 422);
    }
    if ($discountPercent < 0 || $discountPercent > 100 || $vatRate < 0 || $vatRate > 100) {
        sendError('Quotation discount or VAT rate is outside the supported range.', 422);
    }
    $subtotal = round($subtotal, 2);
    $discountAmount = round($subtotal * $discountPercent / 100, 2);
    $taxableAmount = round($subtotal - $discountAmount, 2);
    $vatAmount = 0.0;
    if ($vatType === 'VAT EXCLUSIVE') {
        $vatAmount = round($taxableAmount * $vatRate / 100, 2);
    } elseif ($vatType === 'VAT INCLUSIVE') {
        $vatAmount = round($taxableAmount * $vatRate / (100 + $vatRate), 2);
    }
    $total = round($taxableAmount + ($vatType === 'VAT EXCLUSIVE' ? $vatAmount : 0), 2);
    if (!is_finite($vatAmount) || !is_finite($total) || $vatAmount > 9999999999.99 || $total > 9999999999.99) {
        sendError('The quotation tax or grand total exceeds the supported maximum.', 422);
    }
    return [
        'subtotal' => $subtotal,
        'discount' => $discountAmount,
        'vat' => $vatAmount,
        'total' => $total
    ];
}
function configuredQuotationVatRate(array $settings): float
{
    $value = $settings['default_vat_rate'] ?? 12;
    if (!is_numeric($value) || !is_finite((float) $value) || (float) $value < 0 || (float) $value > 100) {
        sendError('The configured default VAT rate is invalid. Correct business_settings.default_vat_rate before saving quotations.', 500);
    }
    return (float) $value;
}
if ($a === 'defaults' && $m === 'GET') {
    requirePermission($conn, 'quotations.manage');
    sendJson(qsettings($conn));
}
if ($a === 'print-data' && $m === 'GET') {
    requirePermission($conn, 'quotations.view');
    sendJson(['quotation' => qrow($conn, (int) ($_GET['id'] ?? 0)), 'business' => qsettings($conn)]);
}
if ($a === 'next-number' && $m === 'GET') {
    requirePermission($conn, 'quotations.manage');
    $year = trim((string) ($_GET['year'] ?? date('Y')));
    if (!preg_match('/^[0-9]{4}$/D', $year) || (int) $year < 1000) {
        sendError('A valid four-digit quotation year is required.', 422);
    }
    sendJson(['quotationNumber' => nextQuotationNumber($conn, $year)]);
}
if ($a === 'list' && $m === 'GET') {
    requirePermission($conn, 'quotations.view');
    sendJson(allRows($conn, 'SELECT q.*,c.customer_name,c.company_name FROM quotations q JOIN customers c ON c.customer_id=q.customer_id WHERE q.deleted_at IS NULL ORDER BY q.quotation_id DESC'));
}
if ($a === 'get' && $m === 'GET') {
    requirePermission($conn, 'quotations.view');
    sendJson(qrow($conn, (int) ($_GET['id'] ?? 0)));
}
function cleanQuoteItems(array $items): array
{
    $sub = 0;
    $clean = [];
    $seenItems = [];
    foreach ($items as $it) {
        $code = trim((string) ($it['itemCode'] ?? $it['item_code'] ?? ''));
        $loc = trim((string) ($it['location'] ?? ''));
        $dim = trim((string) ($it['dimensions'] ?? ''));
        $d = trim((string) ($it['description'] ?? ''));
        $spec = trim((string) ($it['specification'] ?? ''));
        $drawings = $it['drawingImages'] ?? $it['drawing_images'] ?? [];
        if (is_string($drawings)) {
            try {
                $decoded = json_decode($drawings, true);
                $drawings = is_array($decoded) ? $decoded : [];
            } catch (Throwable $e) {
                $drawings = [];
            }
        }
        if (!is_array($drawings))
            $drawings = [];
        $legacy = trim((string) ($it['drawingImage'] ?? $it['drawing_image'] ?? ''));
        if (!$drawings && $legacy !== '')
            $drawings = [$legacy];
        $safe = [];
        foreach (array_slice($drawings, 0, 4) as $drawing) {
            $drawing = trim((string) $drawing);
            if ($drawing !== '' && preg_match('#^\.\./uploads/quotation_drawings/[A-Za-z0-9_.-]+$#', $drawing))
                $safe[] = $drawing;
        }
        $drawing = $safe[0] ?? '';
        $drawingJson = $safe ? json_encode($safe, JSON_UNESCAPED_SLASHES) : null;
        $quantityValue = $it['quantity'] ?? null;
        $priceValue = $it['unitPrice'] ?? $it['unit_price'] ?? null;
        if (!is_numeric($quantityValue) || !is_numeric($priceValue)) {
            sendError('Enter a valid quantity and unit price for every quotation item.', 422);
        }
        $q = (float) $quantityValue;
        $u = trim((string) ($it['unit'] ?? 'set'));
        if ($u === '')
            $u = 'set';
        $p = (float) $priceValue;
        if ($d === '' || !is_finite($q) || !is_finite($p) || $q <= 0 || $p < 0)
            sendError('Complete every quotation line item with valid values.', 422);
        if (strlen($code) > 30)
            sendError('Item code must be 30 characters or fewer.', 422);
        if (strlen($loc) > 160)
            sendError('Item location must be 160 characters or fewer.', 422);
        if (strlen($dim) > 120)
            sendError('Item dimensions must be 120 characters or fewer.', 422);
        if (strlen($d) > 255)
            sendError('Item description must be 255 characters or fewer.', 422);
        if (strlen($u) > 30)
            sendError('Item unit must be 30 characters or fewer.', 422);
        $identityParts = [$code, $d, $dim, $loc, $spec];
        $identityParts = array_map(
            static fn(string $value): string => mb_strtolower((string) preg_replace('/\s+/u', ' ', trim($value)), 'UTF-8'),
            $identityParts
        );
        $identity = json_encode($identityParts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($identity === false)
            sendError('Quotation item details could not be validated.', 422);
        if (isset($seenItems[$identity])) {
            sendError('Duplicate quotation items were found on lines ' . $seenItems[$identity] . ' and ' . (count($clean) + 1) . '. Change the item details or remove the duplicate.', 422);
        }
        $seenItems[$identity] = count($clean) + 1;
        $amt = round($q * $p, 2);
        if (!is_finite($amt) || $amt > 9999999999.99) {
            sendError('A quotation line amount exceeds the supported maximum.', 422);
        }
        $sub += $amt;
        if (!is_finite($sub) || $sub > 9999999999.99) {
            sendError('The quotation subtotal exceeds the supported maximum.', 422);
        }
        $clean[] = [$code, $loc, $dim, $d, $spec, $drawing, $drawingJson, $q, $u, $p, $amt];
    }
    return [round($sub, 2), $clean];
}
if ($a === 'create' && $m === 'POST') {
    $user = requirePermission($conn, 'quotations.manage');
    $b = body();
    $cid = resolveQuotationCustomer($conn, $b, 0);
    $num = trim((string) ($b['quotationNumber'] ?? ''));
    $date = trim((string) ($b['quotationDate'] ?? ''));
    $valid = trim((string) ($b['validUntil'] ?? ''));
    $durationDays = validateProjectDurationDays($b['estimatedDurationDays'] ?? null);
    $discountValue = $b['discountPercent'] ?? 0;
    if (!is_numeric($discountValue))
        sendError('Enter a valid discount percentage.', 422);
    $disc = (float) $discountValue;
    $pn = trim((string) ($b['projectName'] ?? ''));
    $pa = trim((string) ($b['projectAddress'] ?? ''));
    $terms = trim((string) ($b['paymentTerms'] ?? ''));
    $vat = trim((string) ($b['vatType'] ?? 'VAT EXCLUSIVE'));
    $fab = trim((string) ($b['fabricationTerms'] ?? ''));
    $accept = trim((string) ($b['acceptanceStatement'] ?? ''));
    $reps = trim((string) ($b['authorizedRepresentatives'] ?? ''));
    $notes = trim((string) ($b['notes'] ?? ''));
    $items = $b['items'] ?? [];
    validateQuotationHeader($num, $pn, $pa, $vat, $disc);
    $date = validateQuotationDate($date, 'quotation');
    $valid = validateQuotationDate($valid, 'valid until');
    validateNewQuotationNumber($num, $date);
    if ($date !== '' && $valid !== '' && $valid < $date)
        sendError('Valid until date cannot be before the quotation date.', 422);
    if (!is_array($items) || count($items) < 1)
        sendError('Add at least one quotation line item.', 422);
    [$sub, $clean] = cleanQuoteItems($items);
    if (one($conn, 'SELECT quotation_id FROM quotations WHERE quotation_number=? LIMIT 1', 's', [$num]))
        sendError('Quotation number already exists.', 409);
    $settings = qsettings($conn);
    $vatRate = configuredQuotationVatRate($settings);
    $amounts = quotationTotals($sub, $disc, $vat, $vatRate);
    $conn->begin_transaction();
    try {
        $s = $conn->prepare("INSERT INTO quotations(quotation_number,customer_id,quotation_date,valid_until,subtotal_amount,discount_amount,vat_amount,vat_rate,total_amount,discount_percent,project_name,project_address,payment_terms,vat_type,fabrication_terms,acceptance_statement,authorized_representatives,notes,estimated_duration_days,status) VALUES(?,?,COALESCE(NULLIF(?,''),CURRENT_TIMESTAMP),NULLIF(?,''),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'DRAFT')");
        $s->bind_param('sissddddddssssssssi', $num, $cid, $date, $valid, $amounts['subtotal'], $amounts['discount'], $amounts['vat'], $vatRate, $amounts['total'], $disc, $pn, $pa, $terms, $vat, $fab, $accept, $reps, $notes, $durationDays);
        $s->execute();
        $id = $s->insert_id;
        $s->close();
        foreach ($clean as [$code, $loc, $dim, $d, $spec, $drawing, $drawingJson, $q, $u, $p, $amt]) {
            $s = $conn->prepare('INSERT INTO quotation_items(quotation_id,item_code,location,dimensions,description,specification,drawing_image,drawing_images,quantity,unit,unit_price,amount) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');
            $s->bind_param('isssssssdsdd', $id, $code, $loc, $dim, $d, $spec, $drawing, $drawingJson, $q, $u, $p, $amt);
            $s->execute();
            $s->close();
        }
        auditEvent($conn, $user, 'created', 'quotation', (int) $id, ['quotation_number' => $num, 'amount' => $amounts['total']], null, 'DRAFT');
        $conn->commit();
        sendJson(qrow($conn, $id), 201);
    } catch (Throwable $e) {
        $conn->rollback();
        $duplicate = (int) $e->getCode() === 1062;
        if (!$duplicate)
            error_log('Quotation creation failed: ' . $e->getMessage());
        sendError($duplicate ? 'Quotation number already exists.' : 'Quotation could not be saved. No partial changes were saved.', $duplicate ? 409 : 500);
    }
}
if ($a === 'update' && $m === 'POST') {
    $user = requirePermission($conn, 'quotations.manage');
    $b = body();
    $id = (int) ($b['quotationId'] ?? 0);
    $cur = qrow($conn, $id);
    if (!in_array(strtoupper((string) ($cur['status'] ?? '')), ['DRAFT', 'PENDING'], true)) {
        sendError('Only draft or for-review quotations can be edited.', 409);
    }
    $cid = resolveQuotationCustomer($conn, $b, (int) $cur['customer_id']);
    $num = trim((string) ($b['quotationNumber'] ?? $cur['quotation_number']));
    $date = trim((string) ($b['quotationDate'] ?? $cur['quotation_date']));
    $valid = trim((string) ($b['validUntil'] ?? $cur['valid_until']));
    $durationDays = validateProjectDurationDays($b['estimatedDurationDays'] ?? null, $cur['estimated_duration_days'] !== null ? (int) $cur['estimated_duration_days'] : null);
    $discountValue = $b['discountPercent'] ?? $cur['discount_percent'];
    if (!is_numeric($discountValue))
        sendError('Enter a valid discount percentage.', 422);
    $disc = (float) $discountValue;
    $pn = trim((string) ($b['projectName'] ?? $cur['project_name']));
    $pa = trim((string) ($b['projectAddress'] ?? $cur['project_address']));
    $terms = trim((string) ($b['paymentTerms'] ?? $cur['payment_terms']));
    $vat = trim((string) ($b['vatType'] ?? $cur['vat_type']));
    $fab = trim((string) ($b['fabricationTerms'] ?? $cur['fabrication_terms']));
    $accept = trim((string) ($b['acceptanceStatement'] ?? $cur['acceptance_statement']));
    $reps = trim((string) ($b['authorizedRepresentatives'] ?? $cur['authorized_representatives']));
    $notes = trim((string) ($b['notes'] ?? $cur['notes']));
    $items = $b['items'] ?? $cur['items'];
    $oldDrawingFiles = quotationDrawingFiles($cur['items']);
    validateQuotationHeader($num, $pn, $pa, $vat, $disc);
    $date = validateQuotationDate($date, 'quotation');
    $valid = validateQuotationDate($valid, 'valid until');
    if ($date !== '' && $valid !== '' && $valid < $date)
        sendError('Valid until date cannot be before the quotation date.', 422);
    if (!is_array($items) || count($items) < 1)
        sendError('Add at least one quotation line item.', 422);
    [$sub, $clean] = cleanQuoteItems($items);
    if (one($conn, 'SELECT quotation_id FROM quotations WHERE quotation_number=? AND quotation_id<>? LIMIT 1', 'si', [$num, $id]))
        sendError('Quotation number already exists.', 409);
    $vatRate = $cur['vat_rate'] !== null
        ? (float) $cur['vat_rate']
        : configuredQuotationVatRate(qsettings($conn));
    $amounts = quotationTotals($sub, $disc, $vat, $vatRate);
    $conn->begin_transaction();
    try {
        $st = $conn->prepare("UPDATE quotations SET quotation_number=?,customer_id=?,quotation_date=COALESCE(NULLIF(?,''),quotation_date),valid_until=NULLIF(?,''),subtotal_amount=?,discount_amount=?,vat_amount=?,vat_rate=?,total_amount=?,discount_percent=?,project_name=?,project_address=?,payment_terms=?,vat_type=?,fabrication_terms=?,acceptance_statement=?,authorized_representatives=?,notes=?,estimated_duration_days=? WHERE quotation_id=? AND deleted_at IS NULL");
        $st->bind_param('sissddddddssssssssii', $num, $cid, $date, $valid, $amounts['subtotal'], $amounts['discount'], $amounts['vat'], $vatRate, $amounts['total'], $disc, $pn, $pa, $terms, $vat, $fab, $accept, $reps, $notes, $durationDays, $id);
        $st->execute();
        $st->close();
        $d = $conn->prepare('DELETE FROM quotation_items WHERE quotation_id=?');
        $d->bind_param('i', $id);
        $d->execute();
        $d->close();
        foreach ($clean as [$code, $loc, $dim, $des, $spec, $drawing, $drawingJson, $qty, $unit, $price, $amt]) {
            $st = $conn->prepare('INSERT INTO quotation_items(quotation_id,item_code,location,dimensions,description,specification,drawing_image,drawing_images,quantity,unit,unit_price,amount) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');
            $st->bind_param('isssssssdsdd', $id, $code, $loc, $dim, $des, $spec, $drawing, $drawingJson, $qty, $unit, $price, $amt);
            $st->execute();
            $st->close();
        }
        auditEvent($conn, $user, 'updated', 'quotation', $id, ['quotation_number' => $num, 'amount' => $amounts['total']], (string) $cur['status'], (string) $cur['status']);
        $conn->commit();
        removeUnreferencedQuotationDrawings($conn, $oldDrawingFiles);
        sendJson(qrow($conn, $id));
    } catch (Throwable $e) {
        $conn->rollback();
        $duplicate = (int) $e->getCode() === 1062;
        if (!$duplicate)
            error_log('Quotation update failed: ' . $e->getMessage());
        sendError($duplicate ? 'Quotation number already exists.' : 'Quotation could not be updated.', $duplicate ? 409 : 500);
    }
}
if ($a === 'status' && $m === 'POST') {
    $user = requirePermission($conn, 'quotations.manage');
    $b = body();
    $id = (int) ($b['quotationId'] ?? 0);
    $st = strtoupper((string) ($b['status'] ?? ''));
    if (!in_array($st, ['PENDING', 'APPROVED', 'REJECTED'], true))
        sendError('Invalid quotation status.');
    $current = qrow($conn, $id);
    $currentStatus = strtoupper((string) ($current['status'] ?? ''));
    if (
        ($currentStatus === 'DRAFT' && $st !== 'PENDING')
        || ($currentStatus === 'PENDING' && !in_array($st, ['APPROVED', 'REJECTED', 'PENDING'], true))
        || !in_array($currentStatus, ['DRAFT', 'PENDING'], true)
    ) {
        sendError('The quotation must be submitted for review before it can be approved or rejected.', 409);
    }
    if ($currentStatus === 'DRAFT' && $st === 'PENDING') {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("UPDATE quotations SET status='PENDING' WHERE quotation_id=? AND status='DRAFT' AND deleted_at IS NULL");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $changed = $stmt->affected_rows;
            $stmt->close();
            if ($changed < 1) {
                $conn->rollback();
                sendError('The draft could not be submitted for review. Refresh and try again.', 409);
            }
            auditEvent($conn, $user, 'submitted_for_review', 'quotation', $id, ['quotation_number' => $current['quotation_number']], 'DRAFT', 'PENDING');
            $conn->commit();
            sendJson(qrow($conn, $id));
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('Quotation review submission failed: ' . $e->getMessage());
            sendError('The quotation could not be submitted for review.', 500);
        }
    }
    if ($currentStatus === 'PENDING' && !in_array($st, ['APPROVED', 'REJECTED'], true)) {
        sendError('Invalid quotation status transition.', 409);
    }
    if ($st === 'APPROVED' && !dbTableExists($conn, 'project_payment_milestones')) {
        sendError('Project billing milestones are not installed. Back up the database, then apply Database/calix_existing_database_upgrade.sql before approving quotations.', 503);
    }
    $conn->begin_transaction();
    try {
        $locked = one($conn, 'SELECT status,signed_contract_file,signed_by,signed_date FROM quotations WHERE quotation_id=? AND deleted_at IS NULL FOR UPDATE', 'i', [$id]);
        if (!$locked) {
            $conn->rollback();
            sendError('Quotation not found.', 404);
        }
        $lockedStatus = strtoupper((string) $locked['status']);
        if ($lockedStatus !== 'PENDING') {
            $conn->rollback();
            sendError('Only quotations under review can be approved or rejected.', 409);
        }
        if ($st === 'APPROVED') {
            $contractFile = (string) ($locked['signed_contract_file'] ?? '');
            $expectedFile = '/^contract_' . $id . '_[a-f0-9]{32}\.(pdf|jpg|png)$/';
            $contractPath = __DIR__ . '/../uploads/signed_contracts/' . $contractFile;
            if (
                trim((string) ($locked['signed_by'] ?? '')) === '' || empty($locked['signed_date'])
                || !preg_match($expectedFile, $contractFile) || !is_file($contractPath)
            ) {
                $conn->rollback();
                sendError('Attach the customer-signed contract and record the signer and signing date before approval.', 422);
            }
        }
        $s = $conn->prepare('UPDATE quotations SET status=? WHERE quotation_id=? AND deleted_at IS NULL');
        $s->bind_param('si', $st, $id);
        $s->execute();
        $s->close();
        $project = ['created' => false, 'projectId' => null];
        auditEvent($conn, $user, strtolower($st), 'quotation', $id, ['quotation_number' => $current['quotation_number']], 'PENDING', $st);
        if ($st === 'APPROVED')
            $project = ensureProjectForApprovedQuotation($conn, $id, $user);
        $conn->commit();
        $out = qrow($conn, $id);
        $out['projectCreated'] = $project['created'];
        $out['projectId'] = $project['projectId'];
        $out['projectDeleted'] = $project['projectDeleted'] ?? false;
        sendJson($out);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Quotation status update failed: ' . $e->getMessage());
        sendError('Quotation status could not be updated. No partial project changes were saved.', 500);
    }
}
if ($a === 'delete' && $m === 'POST') {
    requirePermission($conn, 'settings.manage');
    sendError('Use the Trashbin to authorize deletion.', 403);
}
sendError('Quotation route not found.', 404); ?>