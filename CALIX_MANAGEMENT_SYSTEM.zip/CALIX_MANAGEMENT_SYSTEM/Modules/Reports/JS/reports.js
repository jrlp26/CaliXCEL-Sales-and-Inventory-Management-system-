(async () => {
    const $ = id => document.getElementById(id);
    const esc = CalixUI.escape;
    const money = value => CalixUI.money(Number(value || 0));

    function showError(message = '') {
        const box = $('reportError'); box.textContent = message; box.hidden = !message;
    }
    function statusRows(target, data, labels) {
        const total = Object.keys(labels).reduce((sum,key) => sum + Number(data[key] || 0), 0);
        target.innerHTML = Object.entries(labels).map(([key,label]) => {
            const count = Number(data[key] || 0), pct = total ? Math.round(count / total * 100) : 0;
            return `<div class="report-status-row"><span>${esc(label)}</span><strong>${count}</strong><div class="report-status-track"><i style="width:${pct}%"></i></div><small>${pct}%</small></div>`;
        }).join('');
    }
    function renderTrend(rows) {
        const target = $('salesTrend');
        if (!rows?.length) { target.innerHTML = '<p class="empty-state">No sales data for this period.</p>'; return; }
        const max = Math.max(...rows.map(r => Number(r.total || 0)), 1);
        target.innerHTML = rows.map(r => `<div class="trend-row"><span>${esc(r.month_label)}</span><div class="trend-track"><i style="width:${Math.max(3,Number(r.total||0)/max*100)}%"></i></div><strong>${money(r.total)}</strong><small>contract value</small></div>`).join('');
    }
    function labelReportTables() {
        document.querySelectorAll('.report-workspace .data-table').forEach(table => {
            const labels = Array.from(table.tHead?.rows[0]?.cells || [], cell => cell.textContent.trim());
            Array.from(table.tBodies).forEach(body => {
                Array.from(body.rows).forEach(row => {
                    Array.from(row.cells).forEach((cell, index) => {
                        cell.dataset.label = cell.colSpan === 1 ? labels[index] || '' : '';
                    });
                });
            });
        });
    }
    function render(data) {
        const q = data.quotationStatus || {}, p = data.projectStatus || {}, inv = data.inventory || {};
        $('reportQuoteTotal').textContent = Object.values(q).reduce((a,b)=>a+Number(b||0),0);
        $('reportQuoteDetail').textContent = `${Number(q.APPROVED || 0)} approved · ${Number(q.PENDING || 0)} for review`;
        $('reportProjectTotal').textContent = Object.values(p).reduce((a,b)=>a+Number(b||0),0);
        $('reportProjectDetail').textContent = `${Number(p.IN_PROGRESS || 0)} in progress · ${Number(p.COMPLETED || 0)} completed`;
        $('reportInventoryTotal').textContent = Number(inv.totalItems || 0);
        $('reportInventoryDetail').textContent = `${Number(inv.lowStock || 0)} low · ${Number(inv.outOfStock || 0)} out of stock`;
        statusRows($('quotationReportStatus'), q, {DRAFT:'Draft',PENDING:'For Review',APPROVED:'Approved',REJECTED:'Rejected'});
        statusRows($('projectReportStatus'), p, {APPROVED:'Approved',SCHEDULED:'Scheduled',IN_PROGRESS:'In Progress',FOR_INSTALLATION:'For Installation',COMPLETED:'Completed',CLOSED:'Closed',CANCELLED:'Cancelled'});
        $('lowStockRows').innerHTML = (data.lowStock || []).map(row => `<tr><td>${esc(row.item_code)}</td><td><strong>${esc(row.material_name)}</strong></td><td>${esc(row.category || '—')}</td><td>${Number(row.quantity).toLocaleString('en-PH')} ${esc(row.unit)}</td><td>${Number(row.reorder_level).toLocaleString('en-PH')} ${esc(row.unit)}</td></tr>`).join('') || '<tr><td colspan="5" class="empty-state">No inventory alerts.</td></tr>';
        $('projectMaterialRows').innerHTML = (data.projectMaterialUsage || []).map(row => `<tr><td><strong>${esc(row.project_name)}</strong><small class="record-subline">${esc(row.customer_name)}</small></td><td>${esc(row.item_code)} · ${esc(row.material_name)}</td><td>${Number(row.quantity).toLocaleString('en-PH')} ${esc(row.unit)}</td><td>${Number(row.transactions).toLocaleString('en-PH')}</td></tr>`).join('') || '<tr><td colspan="4" class="empty-state">No project-linked material issues for this period.</td></tr>';
        $('inventoryMovementRows').innerHTML = (data.inventoryMovements || []).map(row => `<tr><td>${CalixUI.date(row.transaction_date)}</td><td>${esc(row.transaction_type)}</td><td><strong>${esc(row.item_code)}</strong><small class="record-subline">${esc(row.material_name)}</small></td><td>${Number(row.quantity).toLocaleString('en-PH')} ${esc(row.unit)}</td><td>${esc(row.project_name || row.remarks || '—')}</td><td>${esc(row.received_by || '—')}</td></tr>`).join('') || '<tr><td colspan="6" class="empty-state">No inventory movements for this period.</td></tr>';

        const financialSection = $('financialReportSection'), billingSection = $('billingReportSection'), paymentSection = $('paymentReportSection'), financialCard = $('financialSummaryCard');
        if (!data.canFinancial) {
            financialSection.hidden = true;
            financialCard.hidden = true;
            billingSection.hidden = true;
            paymentSection.hidden = true;
            document.querySelectorAll('[data-financial-print-option]').forEach(option => { option.hidden = true; });
        }
        else {
            financialSection.hidden = false;
            financialCard.hidden = false;
            billingSection.hidden = false;
            paymentSection.hidden = false;
            document.querySelectorAll('[data-financial-print-option]').forEach(option => { option.hidden = false; });
            $('reportBilled').textContent = money(data.billing?.billed);
            $('reportReceivables').textContent = `${money(data.billing?.outstanding)} outstanding · ${Number(data.billing?.overdueCount || 0)} overdue`;
            $('billingReportSummary').textContent = `${money(data.billing?.collected)} collected · ${money(data.billing?.overdue)} overdue`;
            renderTrend(data.salesTrend || []);
            $('reportSalesRows').innerHTML = (data.sales || []).map(row => `<tr><td>${CalixUI.date(String(row.sale_date).slice(0,10))}</td><td><strong>${esc(row.customer_name)}</strong><small class="record-subline">${esc(row.project_name || 'Legacy sales record')}</small></td><td>${esc(row.quotation_number || '—')}</td><td>${money(row.total_amount)}</td><td>${CalixUI.status(row.project_status || 'LEGACY')}</td></tr>`).join('') || '<tr><td colspan="5" class="empty-state">No sales contracts for this period.</td></tr>';
            $('reportInvoiceRows').innerHTML = (data.invoices || []).map(row => `<tr><td><strong>${esc(row.invoice_number || 'Draft')}</strong><small class="record-subline">${esc(row.description)}</small></td><td><strong>${esc(row.customer_name)}</strong><small class="record-subline">${esc(row.project_name || '')} · ${esc(row.quotation_number)}</small></td><td>${CalixUI.date(row.invoice_date)}</td><td>${money(row.amount)}</td><td>${money(row.collected)}</td><td>${money(row.balance)}</td><td>${CalixUI.status(row.payment_status)}</td></tr>`).join('') || '<tr><td colspan="7" class="empty-state">No invoices for this period.</td></tr>';
            $('reportPaymentRows').innerHTML = (data.payments || []).map(row => `<tr><td><strong>${esc(row.payment_number)}</strong></td><td>${CalixUI.date(row.payment_date)}</td><td>${esc(row.invoice_number || '—')}</td><td><strong>${esc(row.customer_name)}</strong><small class="record-subline">${esc(row.project_name || '—')}</small></td><td>${money(row.amount)}</td><td>${esc(row.payment_method || '—')}<small class="record-subline">${esc(row.reference_no || 'No external reference')}</small></td><td>${esc(row.received_by || '—')}</td></tr>`).join('') || '<tr><td colspan="7" class="empty-state">No payments for this period.</td></tr>';
        }
        const rangeText = data.from || data.to ? `${data.from || 'Beginning'} to ${data.to || 'Today'}` : 'All available records';
        $('reportRangeLabel').textContent = rangeText;
        $('reportPrintRange').textContent = `Reporting period: ${rangeText}`;
        labelReportTables();
        updatePrintSelectAll();
    }
    async function load() {
        try {
            showError('');
            const params = new URLSearchParams();
            if ($('reportFrom').value) params.set('from',$('reportFrom').value);
            if ($('reportTo').value) params.set('to',$('reportTo').value);
            const data = await CalixAPI.get('reports.php?action=overview' + (params.toString() ? '&' + params.toString() : ''));
            render(data);
        } catch (error) { showError(error.message || 'Reports could not be loaded.'); }
    }
    function dateMonthsAgo(months) {
        const end = new Date();
        const day = end.getDate();
        const start = new Date(end.getFullYear(), end.getMonth() - Number(months), 1);
        const lastDay = new Date(start.getFullYear(), start.getMonth() + 1, 0).getDate();
        start.setDate(Math.min(day, lastDay));
        const pad = value => String(value).padStart(2, '0');
        return `${start.getFullYear()}-${pad(start.getMonth() + 1)}-${pad(start.getDate())}`;
    }
    function localDate() {
        const now = new Date();
        const pad = value => String(value).padStart(2, '0');
        return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
    }
    const printOptions = Array.from(document.querySelectorAll('[data-print-option]'));
    const reportSections = Array.from(document.querySelectorAll('[data-print-section]'));
    const printSelectAll = $('printSelectAll');
    const printSelectionError = $('printSelectionError');
    function updatePrintSelectAll() {
        const availableOptions = printOptions.filter(option => !option.closest('label').hidden);
        const checkedCount = availableOptions.filter(option => option.checked).length;
        printSelectAll.checked = checkedCount > 0 && checkedCount === availableOptions.length;
        printSelectAll.indeterminate = checkedCount > 0 && checkedCount < availableOptions.length;
        printSelectionError.hidden = true;
    }
    printSelectAll.addEventListener('change', () => {
        printOptions.forEach(option => {
            if (!option.closest('label').hidden) option.checked = printSelectAll.checked;
        });
        updatePrintSelectAll();
    });
    printOptions.forEach(option => option.addEventListener('change', updatePrintSelectAll));
    function applyPrintSelection() {
        const selected = new Set(printOptions.filter(option => option.checked && !option.closest('label').hidden).map(option => option.dataset.printOption));
        reportSections.forEach(section => {
            const shouldHide = !selected.has(section.dataset.printSection)
            section.classList.toggle('report-print-excluded', shouldHide);
        });
    }
    function clearPrintSelection() {
        reportSections.forEach(section => section.classList.remove('report-print-excluded'));
    }
    $('printReport').addEventListener('click', () => {
        const hasSelection = printOptions.some(option => option.checked && !option.closest('label').hidden);
        if (!hasSelection) {
            printSelectionError.hidden = false;
            printOptions.find(option => !option.closest('label').hidden)?.focus();
            return;
        }
        printSelectionError.hidden = true;
        applyPrintSelection();
        window.print();
    });
    window.addEventListener('beforeprint', applyPrintSelection);
    window.addEventListener('afterprint', clearPrintSelection);
    $('applyReportFilter').addEventListener('click', load);
    $('clearReportFilter').addEventListener('click', () => { $('reportFrom').value=''; $('reportTo').value=''; load(); });
    try {
        const configuration = await CalixAPI.get('reports.php?action=configuration');
        const months = Number(configuration.defaultRangeMonths || 0);
        if (months > 0) {
            $('reportFrom').value = dateMonthsAgo(months);
            $('reportTo').value = localDate();
        }
    } catch (error) {
        showError(error.message || 'Report defaults could not be loaded.');
    }
    await load();
})();
