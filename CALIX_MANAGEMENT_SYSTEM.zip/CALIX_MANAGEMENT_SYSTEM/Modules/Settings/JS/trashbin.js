(function () {
    const $ = id => document.getElementById(id);
    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const isAdmin = (() => {
        try { return JSON.parse(sessionStorage.getItem('calixAccount') || 'null')?.role === 'ADMIN'; }
        catch (_) { return false; }
    })();
    const moduleNames = {quotations:'Quotations',projects:'Projects',inventory:'Inventory',customers:'Customers',sales:'Sales',billing:'Invoices',payments:'Payments',todo_notes:'Tasks & Notes',users:'Users'};
    let state = {history:[],deletable:[],currentUserId:0,permanentDeleteAvailable:false};
    const pageSize = 8;
    const pages = {deletion:1,history:1};

    async function request(action, options = {}) {
        try {
            return await CalixAPI.request('settings.php?action=' + encodeURIComponent(action), {...options,redirectOnUnauthorized:false});
        } catch (error) {
            if (error.status === 401 && error.message !== 'Incorrect administrator password.') {
                sessionStorage.removeItem('calixAccount');
                location.replace(new URL('../../../System/HTML/LoginPage.html', location.href).href);
            }
            throw error;
        }
    }

    function showNotice(message, isError = false) {
        const notice = $('trashbinNotice');
        notice.textContent = message;
        notice.classList.toggle('error', isError);
    }

    function renderActiveRecords() {
        const query = $('deletionSearch').value.trim().toLowerCase();
        const module = $('deletionModule').value;
        const filtered = (state.deletable || []).filter(row =>
            (!module || row.module === module) &&
            !(row.module === 'users' && Number(row.record_id) === Number(state.currentUserId)) &&
            (!query || [row.record_label,row.details,row.module].join(' ').toLowerCase().includes(query))
        );
        const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
        pages.deletion = Math.min(pages.deletion, totalPages);
        const start = (pages.deletion - 1) * pageSize;
        const rows = filtered.slice(start, start + pageSize);
        $('deletionBody').innerHTML = rows.map(row => `<tr>
            <td>${esc(moduleNames[row.module] || row.module)}</td>
            <td><strong>${esc(row.record_label)}</strong></td>
            <td>${esc(row.details || '')}</td>
            <td><button class="small-button danger" type="button" data-delete-record="${row.record_id}" data-module="${esc(row.module)}" data-label="${esc(row.record_label)}">${row.module === 'users' ? 'Delete account' : 'Delete'}</button></td>
        </tr>`).join('') || '<tr><td colspan="4" class="empty-state">No active records match these filters.</td></tr>';
        $('deletionEmpty').hidden = rows.length > 0;
        $('deletionPageSummary').textContent = filtered.length
            ? `Showing ${start + 1}–${Math.min(start + pageSize, filtered.length)} of ${filtered.length} active records`
            : 'Showing 0 active records';
        $('deletionPageNumber').textContent = `Page ${pages.deletion} of ${totalPages}`;
        $('previousDeletionPage').disabled = pages.deletion <= 1;
        $('nextDeletionPage').disabled = pages.deletion >= totalPages;
    }

    function renderHistory() {
        const query = $('historySearch').value.trim().toLowerCase();
        const filtered = (state.history || []).filter(row =>
            !query || [row.module,row.record_label,row.deleted_by_name,row.restored_by_name,row.permanently_deleted_by_name]
                .join(' ').toLowerCase().includes(query)
        );
        const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
        pages.history = Math.min(pages.history, totalPages);
        const start = (pages.history - 1) * pageSize;
        const rows = filtered.slice(start, start + pageSize);
        $('historyBody').innerHTML = rows.map(row => {
            const restored = !!row.restored_at;
            const purged = !!row.permanently_deleted_at;
            const recoverable = ['quotations','projects','inventory','customers','sales','billing','payments','todo_notes','users'].includes(row.module);
            const status = purged
                ? `<span class="status-pill purged">Permanently deleted</span><small class="purged-by">By ${esc(row.permanently_deleted_by_name || row.permanently_deleted_by || 'Administrator')}</small>`
                : restored ? '<span class="status-pill active">Restored</span>' : '<span class="status-pill inactive">Deleted</span>';
            const actions = !restored && !purged && recoverable
                ? `<div class="row-actions"><button class="small-button" type="button" data-restore-history="${row.history_id}" data-label="${esc(row.record_label)}">Restore</button>${state.permanentDeleteAvailable ? `<button class="small-button danger" type="button" data-permanent-delete-history="${row.history_id}" data-label="${esc(row.record_label)}">Delete permanently</button>` : ''}</div>`
                : '—';
            return `<tr>
                <td>${esc(row.deleted_at)}</td><td>${esc(moduleNames[row.module] || row.module)}</td>
                <td>${esc(row.record_label)}</td><td>${esc(row.deleted_by_name || row.deleted_by)}</td>
                <td>${status}</td><td>${actions}</td>
            </tr>`;
        }).join('') || '<tr><td colspan="6" class="empty-state">No deletion history matches this search.</td></tr>';
        $('historyEmpty').hidden = rows.length > 0;
        $('historyPageSummary').textContent = filtered.length
            ? `Showing ${start + 1}–${Math.min(start + pageSize, filtered.length)} of ${filtered.length} deleted records`
            : 'Showing 0 deleted records';
        $('historyPageNumber').textContent = `Page ${pages.history} of ${totalPages}`;
        $('previousHistoryPage').disabled = pages.history <= 1;
        $('nextHistoryPage').disabled = pages.history >= totalPages;
    }

    function render() {
        renderActiveRecords();
        renderHistory();
    }

    async function load() {
        try {
            state = await request('overview');
            render();
        } catch (error) {
            showNotice(error.message || 'Trashbin records could not be loaded.', true);
        }
    }

    function openAction(action, data) {
        $('authForm').reset();
        $('authAction').value = action;
        $('authRecordModule').value = data.module || '';
        $('authRecordId').value = data.recordId || '';
        $('authHistoryId').value = data.historyId || '';
        $('purgeAcknowledgeLabel').hidden = action !== 'permanent_delete';
        $('purgeAcknowledge').required = action === 'permanent_delete';
        $('authSubmit').className = action === 'restore' ? 'button' : 'button danger-button';
        $('authSubmit').textContent = action === 'restore' ? 'Authorize Restore' : action === 'permanent_delete' ? 'Permanently Delete' : 'Authorize Delete';
        $('authDialogTitle').textContent = action === 'restore' ? 'Confirm Restore' : action === 'permanent_delete' ? 'Permanently Delete Record' : 'Confirm Deletion';
        if (action === 'restore') {
            $('authCopy').innerHTML = `Enter your administrator password to restore <strong>${esc(data.label)}</strong>.`;
        } else if (action === 'permanent_delete') {
            $('authCopy').innerHTML = `Permanently delete <strong>${esc(data.label)}</strong>? This removes the soft-deleted record and its stored snapshot. An audit entry will remain. This action cannot be undone.`;
        } else {
            $('authCopy').innerHTML = data.module === 'users'
                ? `Enter your administrator password to move user account <strong>${esc(data.label)}</strong> to the Trashbin. The account can be restored later.`
                : `Enter your administrator password to delete <strong>${esc(data.label)}</strong> from ${esc(moduleNames[data.module] || data.module)}.`;
        }
        $('authError').textContent = '';
        $('authDialog').showModal();
    }

    $('deletionSearch').addEventListener('input', () => { pages.deletion = 1; renderActiveRecords(); });
    $('deletionModule').addEventListener('change', () => { pages.deletion = 1; renderActiveRecords(); });
    $('historySearch').addEventListener('input', () => { pages.history = 1; renderHistory(); });
    $('previousDeletionPage').addEventListener('click', () => {
        if (pages.deletion <= 1) return;
        pages.deletion -= 1;
        renderActiveRecords();
    });
    $('nextDeletionPage').addEventListener('click', () => {
        pages.deletion += 1;
        renderActiveRecords();
    });
    $('previousHistoryPage').addEventListener('click', () => {
        if (pages.history <= 1) return;
        pages.history -= 1;
        renderHistory();
    });
    $('nextHistoryPage').addEventListener('click', () => {
        pages.history += 1;
        renderHistory();
    });
    $('deletionBody').addEventListener('click', event => {
        const button = event.target.closest('[data-delete-record]');
        if (button) openAction('delete', {module:button.dataset.module,recordId:button.dataset.deleteRecord,label:button.dataset.label});
    });
    $('historyBody').addEventListener('click', event => {
        const restore = event.target.closest('[data-restore-history]');
        const purge = event.target.closest('[data-permanent-delete-history]');
        if (restore) openAction('restore', {historyId:restore.dataset.restoreHistory,label:restore.dataset.label});
        if (purge) openAction('permanent_delete', {historyId:purge.dataset.permanentDeleteHistory,label:purge.dataset.label});
    });
    $('authForm').addEventListener('submit', async event => {
        event.preventDefault();
        if (!isAdmin) return;
        if (!event.currentTarget.reportValidity()) return;
        const submitButton = $('authSubmit');
        if (submitButton.disabled) return;
        const action = $('authAction').value;
        if (action === 'permanent_delete' && !$('purgeAcknowledge').checked) {
            $('authError').textContent = 'Confirm that you understand this action cannot be undone.';
            return;
        }
        const actions = {
            delete: ['delete_record', {module:$('authRecordModule').value,record_id:Number($('authRecordId').value),password:$('authPassword').value}],
            restore: ['restore_record', {history_id:Number($('authHistoryId').value),password:$('authPassword').value}],
            permanent_delete: ['permanent_delete_record', {history_id:Number($('authHistoryId').value),password:$('authPassword').value}]
        };
        submitButton.disabled = true;
        submitButton.textContent = 'Working…';
        try {
            const [endpoint, body] = actions[action];
            await request(endpoint, {method:'POST',body:JSON.stringify(body)});
            $('authDialog').close();
            const deletedModule = $('authRecordModule').value;
            showNotice(action === 'restore' ? 'Record restored.' : action === 'permanent_delete' ? 'Record permanently deleted; its audit entry remains.' : deletedModule === 'users' ? 'User account moved to the Trashbin.' : 'Record deleted.');
            await load();
        } catch (error) {
            $('authError').textContent = error.message || 'The action could not be completed.';
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = action === 'restore' ? 'Authorize Restore' : action === 'permanent_delete' ? 'Permanently Delete' : 'Authorize Delete';
        }
    });
    $('authPasswordToggle').addEventListener('click', () => {
        const password = $('authPassword');
        password.type = password.type === 'password' ? 'text' : 'password';
        $('authPasswordToggle').textContent = password.type === 'password' ? 'Show' : 'Hide';
    });
    document.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => $(button.dataset.close).close()));
    window.addEventListener('calix:search', event => {
        $('historySearch').value = event.detail?.query || '';
        pages.history = 1;
        renderHistory();
    });

    load();
}());
