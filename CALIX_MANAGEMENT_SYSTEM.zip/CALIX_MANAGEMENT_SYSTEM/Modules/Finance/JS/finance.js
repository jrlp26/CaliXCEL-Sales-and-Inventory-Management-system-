(async function () {
    const $ = id => document.getElementById(id);
    const esc = CalixUI.escape;
    const money = value => CalixUI.money(Number(value || 0));
    const isBilling = document.body.dataset.page === 'finance-billing';
    const account = (() => { try { return JSON.parse(sessionStorage.getItem('calixAccount') || 'null'); } catch (_) { return null; } })();
    const can = permission => account?.role === 'ADMIN' || (account?.permissions || []).includes(permission);
    const canManageBilling = can('billing.manage');
    const canManagePayments = can('payments.manage');
    const pageSize = 8;
    let invoices = [];
    let payments = [];
    let projects = [];
    let invoicePage = 1;
    let paymentPage = 1;
    let invoiceDueDays = 30;
    let paymentMethods = ['Cash', 'Bank Transfer', 'GCash', 'Cheque', 'Other'];
    let invoiceDueDateIsDefault = true;

    const localDate = () => {
        const now = new Date();
        const pad = value => String(value).padStart(2, '0');
        return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
    };
    const datePlusDays = (date, days) => {
        if (!date || Number(days) <= 0) return '';
        const value = new Date(`${date}T12:00:00`);
        value.setDate(value.getDate() + Number(days));
        const pad = part => String(part).padStart(2, '0');
        return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}`;
    };

    function notice(id, message = '', type = '') {
        const box = $(id);
        if (!box) return;
        box.textContent = message;
        box.className = `notice${type ? ' ' + type : ''}`;
        box.hidden = !message;
    }

    function statusChip(status) {
        const cls = `finance-status-${String(status || '').toLowerCase()}`;
        return `<span class="status-chip ${cls}">${esc(status || '—')}</span>`;
    }

    function updateBillingSummary() {
        const issued = invoices.filter(invoice => invoice.payment_status !== 'DRAFT');
        $('totalBilled').textContent = money(issued.reduce((sum, invoice) => sum + Number(invoice.amount || 0), 0));
        $('billingOutstanding').textContent = money(issued.reduce((sum, invoice) => sum + Number(invoice.balance || 0), 0));
        $('overdueCount').textContent = issued.filter(invoice => invoice.payment_status === 'OVERDUE').length.toLocaleString('en-PH');
    }

    function renderInvoiceRows(resetPage = false) {
        const query = $('invoiceSearch').value.trim().toLowerCase();
        const status = $('invoiceStatusFilter').value;
        const visible = invoices.filter(invoice => {
            const haystack = [invoice.invoice_number, invoice.description, invoice.customer_name, invoice.project_name, invoice.quotation_number]
                .filter(Boolean).join(' ').toLowerCase();
            return (!query || haystack.includes(query)) && (!status || invoice.payment_status === status);
        });
        $('invoiceCount').textContent = `${visible.length} invoice${visible.length === 1 ? '' : 's'}`;
        const totalPages = Math.max(1, Math.ceil(visible.length / pageSize));
        if (resetPage) invoicePage = 1;
        invoicePage = Math.min(invoicePage, totalPages);
        const start = (invoicePage - 1) * pageSize;
        const pageInvoices = visible.slice(start, start + pageSize);
        $('invoiceRows').innerHTML = pageInvoices.map(invoice => {
            const itemDetails = invoice.items?.length
                ? `<details class="invoice-item-summary"><summary>${invoice.items.length} item${invoice.items.length === 1 ? '' : 's'}</summary><ul>${invoice.items.map(item => `<li>${esc(item.description)} · ${Number(item.quantity).toLocaleString('en-PH')} ${esc(item.unit)} × ${money(item.unit_price)}</li>`).join('')}</ul></details>`
                : '<small class="record-subline muted">Legacy invoice detail not available</small>';
            let action = '<span class="muted">—</span>';
            if (invoice.payment_status === 'DRAFT' && canManageBilling) {
                action = `<button class="text-button" type="button" data-issue-invoice="${invoice.billing_id}">Issue</button>`;
            } else if (Number(invoice.balance) > 0 && canManagePayments && invoice.payment_status !== 'DRAFT') {
                action = `<a class="text-button" href="Payments.html?invoice=${encodeURIComponent(invoice.billing_id)}">Record payment</a>`;
            }
            if (invoice.payment_status === 'DRAFT') action += CalixRecordDeletion.button('billing', invoice.billing_id, invoice.invoice_number || `Draft invoice ${invoice.billing_id}`);
            return `<tr>
                <td><div class="invoice-meta"><strong>${esc(invoice.invoice_number || 'Draft')}</strong><small>${esc(invoice.milestone_label ? `${invoice.milestone_label} · ${Number(invoice.milestone_percentage).toLocaleString('en-PH')}%` : invoice.description)}</small>${itemDetails}</div></td>
                <td><strong>${esc(invoice.customer_name)}</strong><small class="record-subline">${esc(invoice.project_name)} · ${esc(invoice.quotation_number)}</small></td>
                <td>${CalixUI.date(invoice.invoice_date || invoice.date_created)}<small class="record-subline">Due ${CalixUI.date(invoice.due_date)}</small></td>
                <td>${money(invoice.amount)}</td><td>${money(invoice.collected)}</td><td>${money(invoice.balance)}</td>
                <td>${statusChip(invoice.payment_status)}</td><td>${action}</td>
            </tr>`;
        }).join('') || '<tr><td colspan="8" class="empty-state">No invoices match these filters.</td></tr>';
        $('invoicePageSummary').textContent = visible.length
            ? `Showing ${start + 1}–${Math.min(start + pageSize, visible.length)} of ${visible.length} invoices`
            : 'Showing 0 invoices';
        $('invoicePageNumber').textContent = `Page ${invoicePage} of ${totalPages}`;
        $('previousInvoicePage').disabled = invoicePage <= 1;
        $('nextInvoicePage').disabled = invoicePage >= totalPages;
        updateBillingSummary();
    }

    function addInvoiceItem(item = {}) {
        const row = document.createElement('div');
        row.className = 'invoice-item-row';
        row.innerHTML = `<div class="form-field"><label>Item / service *</label><input data-item-description maxlength="255" required value="${esc(item.description || '')}"></div>
            <div class="form-field"><label>Quantity *</label><input data-item-quantity type="number" min="0.001" step="0.001" required value="${esc(item.quantity ?? '1')}"></div>
            <div class="form-field"><label>Unit *</label><input data-item-unit maxlength="30" required value="${esc(item.unit || 'set')}"></div>
            <div class="form-field"><label>Unit price *</label><input data-item-price type="number" min="0" step="0.01" required value="${esc(item.unitPrice ?? '')}"></div>
            <button class="icon-button secondary" type="button" data-remove-item aria-label="Remove invoice item">×</button>`;
        $('invoiceItems').append(row);
        row.addEventListener('input', updateInvoicePreview);
    }

    function invoiceFormItems() {
        return [...$('invoiceItems').querySelectorAll('.invoice-item-row')].map(row => ({
            description: row.querySelector('[data-item-description]').value.trim(),
            quantity: row.querySelector('[data-item-quantity]').value,
            unit: row.querySelector('[data-item-unit]').value.trim(),
            unitPrice: row.querySelector('[data-item-price]').value
        }));
    }

    function updateInvoicePreview() {
        const roundMoney = value => Math.round((value + Number.EPSILON) * 100) / 100;
        const subtotal = roundMoney(invoiceFormItems().reduce((sum, item) =>
            sum + roundMoney(Number(item.quantity || 0) * Number(item.unitPrice || 0)), 0));
        const discountRate = Math.min(100, Math.max(0, Number($('invoiceDiscount').value || 0)));
        const taxable = roundMoney(subtotal - roundMoney(subtotal * discountRate / 100));
        const type = $('invoiceVatType').value;
        const rate = type === 'NON-VAT' ? 0 : Math.min(100, Math.max(0, Number($('invoiceVatRate').value || 0)));
        const vat = type === 'VAT EXCLUSIVE' ? roundMoney(taxable * rate / 100) : 0;
        const total = roundMoney(taxable + vat);
        $('invoiceTotalPreview').textContent = money(total);
        $('invoiceVatFields').hidden = type === 'NON-VAT';
        const project = projects.find(row => String(row.project_id) === String($('invoiceProject').value));
        const remaining = Number(project?.remaining_to_invoice ?? 0);
        const saveButton = $('saveInvoiceButton');
        const exceedsAvailable = Boolean(project) && total > remaining + 0.005;
        if (project) {
            $('invoiceProjectBalance').textContent = `Available to invoice: ${money(remaining)} (Contract ${money(project.contract_amount)} · Prior collections ${money(project.opening_paid)} · Existing invoices ${money(project.scheduled)}).`;
        } else {
            $('invoiceProjectBalance').textContent = 'Select a project to see its remaining contract value available for invoicing.';
        }
        if (exceedsAvailable) {
            $('invoiceFormError').textContent = `Invoice total exceeds the ${money(remaining)} remaining contract value. Reduce the invoice amount or reconcile prior collections/invoices.`;
        } else if ($('invoiceFormError').textContent.startsWith('Invoice total exceeds the ')) {
            $('invoiceFormError').textContent = '';
        }
        saveButton.disabled = Boolean(project) && (remaining <= 0.005 || exceedsAvailable);
    }

    function setInvoiceMilestone() {
        $('invoiceFormError').textContent='';
        const project=projects.find(row=>String(row.project_id)===String($('invoiceProject').value));
        const milestone=project?.milestones?.find(row=>String(row.milestone_id)===String($('invoiceMilestone').value));
        const controls=['invoiceDiscount','invoiceVatType','invoiceVatRate'];
        $('invoiceItems').replaceChildren();
        if (!milestone || !milestone.eligible) {
            $('invoiceMilestoneHint').textContent=milestone?.reason || 'Choose an available milestone for this project.';
            $('addInvoiceItem').disabled=true;
            controls.forEach(id=>$(id).disabled=true);
            $('invoiceDescription').value='';
            updateInvoicePreview();
            return;
        }
        const amount=Number(milestone.available_amount);
        $('invoiceMilestoneHint').textContent=`${milestone.label}: ${money(amount)} due (${Number(milestone.percentage)}% of contract). ${milestone.reason || 'Ready to invoice.'}`;
        $('invoiceDescription').value=`${milestone.label} milestone`;
        $('invoiceDiscount').value='0';
        $('invoiceVatType').value='NON-VAT';
        $('invoiceVatRate').value='0';
        controls.forEach(id=>$(id).disabled=true);
        $('addInvoiceItem').disabled=true;
        addInvoiceItem({description:`${milestone.label} (${Number(milestone.percentage)}%)`,quantity:'1',unit:'milestone',unitPrice:amount});
        $('invoiceItems').querySelectorAll('input').forEach(input=>{input.readOnly=true;});
        $('invoiceItems').querySelectorAll('[data-remove-item]').forEach(button=>{button.disabled=true;});
        updateInvoicePreview();
    }

    async function loadBilling() {
        try {
            invoices = await CalixAPI.get('finance.php?action=invoices') || [];
            if (canManageBilling) {
                const defaults = await CalixAPI.get('finance.php?action=module-defaults&module=billing');
                invoiceDueDays = Number(defaults.dueDays || 0);
            }
            const requestedStatus = new URLSearchParams(location.search).get('status');
            if (requestedStatus && $('invoiceStatusFilter').querySelector(`option[value="${CSS.escape(requestedStatus)}"]`)) {
                $('invoiceStatusFilter').value = requestedStatus;
            }
            renderInvoiceRows(true);
            if (canManageBilling) {
                projects = await CalixAPI.get('finance.php?action=projects') || [];
                $('invoiceProject').innerHTML = '<option value="">Select approved project</option>' + projects.map(project => {
                    const remaining = Number(project.remaining_to_invoice || 0);
                    const exhausted = remaining <= 0.005 || !(project.milestones || []).some(milestone=>milestone.eligible);
                    const details = exhausted
                        ? ` · No amount available (${money(project.opening_paid)} collected, ${money(project.scheduled)} invoiced)`
                        : ` · ${money(remaining)} available`;
                    return `<option value="${project.project_id}" ${exhausted ? 'disabled' : ''}>${esc(project.project_name)} · ${esc(project.customer_name)} · Contract ${money(project.contract_amount)}${details}</option>`;
                }).join('');
            }
        } catch (error) {
            $('invoiceRows').innerHTML = `<tr><td colspan="8" class="empty-state">${esc(error.message || 'Invoices could not be loaded.')}</td></tr>`;
        }
    }

    function openInvoiceForm() {
        $('invoiceForm').reset();
        $('invoiceItems').replaceChildren();
        $('invoiceProject').value = '';
        $('invoiceMilestone').innerHTML='<option value="">Select a project first</option>';
        $('invoiceMilestoneHint').textContent='Down payment is due before work starts; later milestones unlock at their project stages.';
        previousInvoiceProject = '';
        $('invoiceDate').value = localDate();
        invoiceDueDateIsDefault = true;
        $('invoiceDueDate').value = datePlusDays($('invoiceDate').value, invoiceDueDays);
        $('invoiceVatRate').value = '12';
        $('invoiceDiscount').value = '0';
        $('invoiceVatType').value = 'VAT EXCLUSIVE';
        $('invoiceFormError').textContent = '';
        $('addInvoiceItem').disabled=false;
        ['invoiceDiscount','invoiceVatType','invoiceVatRate'].forEach(id=>$(id).disabled=false);
        updateInvoicePreview();
        $('invoiceDialog').showModal();
    }

    async function prefillInvoiceFromProject() {
        const selectedProject = $('invoiceProject').value;
        const project = projects.find(row => String(row.project_id) === String(selectedProject));
        if (!project) {
            $('invoiceProjectBalance').textContent = 'Select a project to see its remaining contract value available for invoicing.';
            $('invoiceMilestone').innerHTML='<option value="">Select a project first</option>';
            $('invoiceItems').replaceChildren();
            updateInvoicePreview();
            return;
        }
        $('invoiceMilestone').innerHTML='<option value="">Select milestone</option>'+(project.milestones||[]).map(milestone=>{
            const amount=Number(milestone.available_amount);
            const disabled=!milestone.eligible;
            const description=milestone.eligible?money(amount):milestone.reason;
            return `<option value="${milestone.milestone_id}" ${disabled?'disabled':''}>${esc(milestone.label)} · ${Number(milestone.percentage)}% · ${esc(description)}</option>`;
        }).join('');
        const firstEligible=(project.milestones||[]).find(milestone=>milestone.eligible);
        $('invoiceMilestone').value=firstEligible?String(firstEligible.milestone_id):'';
        setInvoiceMilestone();
        previousInvoiceProject = selectedProject;
    }

    let previousInvoiceProject = '';

    async function loadPayments() {
        try {
            const requests = [CalixAPI.get('finance.php?action=payments')];
            if (canManagePayments) requests.push(CalixAPI.get('finance.php?action=payment-invoices'));
            if (canManagePayments) requests.push(CalixAPI.get('finance.php?action=module-defaults&module=payments'));
            const result = await Promise.all(requests);
            payments = result[0] || [];
            if (canManagePayments) {
                invoices = result[1] || [];
                paymentMethods = result[2]?.paymentMethods || paymentMethods;
                $('paymentMethod').innerHTML = '<option value="">Not specified</option>' + paymentMethods.map(method => `<option>${esc(method)}</option>`).join('');
                const openInvoices = invoices.filter(invoice => invoice.status !== 'PLANNED' && Number(invoice.balance) > 0);
                $('paymentInvoice').innerHTML = '<option value="">Select an issued invoice</option>' + openInvoices.map(invoice =>
                    `<option value="${invoice.billing_id}">${esc(invoice.invoice_number || invoice.description)} · ${esc(invoice.customer_name)} · balance ${money(invoice.balance)}</option>`).join('');
            }
            renderPaymentRows(true);
            const target = new URLSearchParams(location.search).get('invoice');
            if (target && canManagePayments) openPaymentForm(target);
        } catch (error) {
            $('paymentRows').innerHTML = `<tr><td colspan="7" class="empty-state">${esc(error.message || 'Payments could not be loaded.')}</td></tr>`;
        }
    }

    function renderPaymentRows(resetPage = false) {
        const query = $('paymentSearch').value.trim().toLowerCase();
        const visible = payments.filter(payment =>
            [payment.payment_number, payment.invoice_number, payment.reference_no, payment.customer_name, payment.project_name, payment.quotation_number, payment.payment_method]
                .filter(Boolean).join(' ').toLowerCase().includes(query));
        $('paymentResultCount').textContent = `${visible.length} payment${visible.length === 1 ? '' : 's'}`;
        $('paymentCount').textContent = payments.length.toLocaleString('en-PH');
        $('totalReceived').textContent = money(payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0));
        const totalPages = Math.max(1, Math.ceil(visible.length / pageSize));
        if (resetPage) paymentPage = 1;
        paymentPage = Math.min(paymentPage, totalPages);
        const start = (paymentPage - 1) * pageSize;
        const pagePayments = visible.slice(start, start + pageSize);
        $('paymentRows').innerHTML = pagePayments.map(payment => `<tr>
            <td>${CalixUI.date(payment.payment_date)}<small class="record-subline">${esc(payment.payment_number || '—')}</small></td>
            <td><strong>${esc(payment.customer_name)}</strong><small class="record-subline">${esc(payment.project_name)} · ${esc(payment.quotation_number)}</small></td>
            <td>${esc(payment.invoice_number || payment.invoice_description)}</td>
            <td>${money(payment.amount)}</td>
            <td>${esc(payment.payment_method || '—')}<small class="record-subline">${esc(payment.reference_no || 'No reference')}</small></td>
            <td>${esc(payment.received_by || '—')}</td>
            <td>${CalixRecordDeletion.button('payments', payment.payment_id, payment.payment_number || `Payment #${payment.payment_id}`)}</td>
        </tr>`).join('') || '<tr><td colspan="7" class="empty-state">No payment records match these filters.</td></tr>';
        $('paymentPageSummary').textContent = visible.length
            ? `Showing ${start + 1}–${Math.min(start + pageSize, visible.length)} of ${visible.length} payments`
            : 'Showing 0 payments';
        $('paymentPageNumber').textContent = `Page ${paymentPage} of ${totalPages}`;
        $('previousPaymentPage').disabled = paymentPage <= 1;
        $('nextPaymentPage').disabled = paymentPage >= totalPages;
    }

    function openPaymentForm(invoiceId = '') {
        if (!canManagePayments) return;
        $('paymentForm').reset();
        $('paymentDate').value = localDate();
        $('paymentFormError').textContent = '';
        $('paymentInvoice').value = invoiceId || '';
        setPaymentInvoice();
        $('paymentDialog').showModal();
    }

    function setPaymentInvoice() {
        const invoice = invoices.find(row => String(row.billing_id) === String($('paymentInvoice').value));
        if (!invoice) {
            $('paymentInvoiceBalance').textContent = 'Select an issued invoice.';
            $('paymentAmount').removeAttribute('max');
            return;
        }
        $('paymentInvoiceBalance').textContent = `${invoice.invoice_number || invoice.description} · Remaining ${money(invoice.balance)}`;
        $('paymentAmount').max = Number(invoice.balance);
    }

    if (isBilling) {
        CalixRecordDeletion.bind($('invoiceRows'), loadBilling);
        $('invoiceSearch').addEventListener('input', () => renderInvoiceRows(true));
        $('invoiceStatusFilter').addEventListener('change', () => renderInvoiceRows(true));
        $('previousInvoicePage').addEventListener('click', () => {
            if (invoicePage > 1) {
                invoicePage -= 1;
                renderInvoiceRows();
            }
        });
        $('nextInvoicePage').addEventListener('click', () => {
            invoicePage += 1;
            renderInvoiceRows();
        });
        $('newInvoiceButton')?.addEventListener('click', openInvoiceForm);
        $('invoiceProject').addEventListener('change', prefillInvoiceFromProject);
        $('invoiceMilestone').addEventListener('change',setInvoiceMilestone);
        $('invoiceDate').addEventListener('change', () => {
            if (invoiceDueDateIsDefault) $('invoiceDueDate').value = datePlusDays($('invoiceDate').value, invoiceDueDays);
        });
        $('invoiceDueDate').addEventListener('change', () => { invoiceDueDateIsDefault = false; });
        $('invoiceItems').addEventListener('click', event => {
            const remove = event.target.closest('[data-remove-item]');
            if (!remove) return;
            const rows = $('invoiceItems').querySelectorAll('.invoice-item-row');
            if (rows.length <= 1) {
                notice('billingNotice', 'An invoice needs at least one item.', 'error');
                return;
            }
            remove.closest('.invoice-item-row').remove();
            updateInvoicePreview();
        });
        $('addInvoiceItem').addEventListener('click', () => addInvoiceItem());
        ['invoiceDiscount', 'invoiceVatType', 'invoiceVatRate'].forEach(id => $(id).addEventListener('input', updateInvoicePreview));
        $('invoiceVatType').addEventListener('change', updateInvoicePreview);
        $('invoiceRows').addEventListener('click', event => {
            const button = event.target.closest('[data-issue-invoice]');
            if (!button) return;
            $('issueBillingId').value = button.dataset.issueInvoice;
            $('issueInvoiceError').textContent = '';
            $('issueInvoiceDialog').showModal();
        });
        $('invoiceForm').addEventListener('submit', async event => {
            event.preventDefault();
            const form = $('invoiceForm');
            const button = $('saveInvoiceButton');
            if (!canManageBilling || button.disabled || !form.reportValidity()) return;
            const originalText = button.textContent;
            button.disabled = true;
            button.textContent = 'Saving invoice…';
            CalixUI.clearFieldErrors(form);
            $('invoiceFormError').textContent = '';
            try {
                const created = await CalixAPI.post('finance.php?action=invoice-create', {
                    projectId: Number($('invoiceProject').value),
                    milestoneId: Number($('invoiceMilestone').value),
                    description: $('invoiceDescription').value.trim(),
                    invoiceDate: $('invoiceDate').value,
                    dueDate: $('invoiceDueDate').value,
                    discountPercent: $('invoiceDiscount').value,
                    vatType: $('invoiceVatType').value,
                    vatRate: $('invoiceVatRate').value,
                    items: invoiceFormItems()
                });
                $('invoiceDialog').close();
                await loadBilling();
                notice('billingNotice', `Draft invoice saved (${created.billingId}). Issue it when it is ready to send.`, 'success');
            } catch (error) {
                CalixUI.showFormError(form, error, $('invoiceFormError'));
            } finally {
                button.disabled = false;
                button.textContent = originalText;
                updateInvoicePreview();
            }
        });
        $('issueInvoiceForm').addEventListener('submit', async event => {
            event.preventDefault();
            const form = $('issueInvoiceForm');
            const button = form.querySelector('[type="submit"]');
            if (button.disabled || !form.reportValidity()) return;
            const originalText = button.textContent;
            button.disabled = true;
            button.textContent = 'Issuing…';
            CalixUI.clearFieldErrors(form);
            $('issueInvoiceError').textContent = '';
            try {
                const issued = await CalixAPI.post('finance.php?action=invoice-issue', {
                    billingId: Number($('issueBillingId').value)
                });
                $('issueInvoiceDialog').close();
                await loadBilling();
                notice('billingNotice', `Invoice ${issued.invoiceNumber} issued and is available for payment recording.`, 'success');
            } catch (error) {
                CalixUI.showFormError(form, error, $('issueInvoiceError'));
            } finally {
                button.disabled = false;
                button.textContent = originalText;
            }
        });
        document.querySelectorAll('[data-invoice-close]').forEach(button => button.addEventListener('click', () => $('invoiceDialog').close()));
        document.querySelectorAll('[data-issue-close]').forEach(button => button.addEventListener('click', () => $('issueInvoiceDialog').close()));
        window.addEventListener('calix:search', event => {
            $('invoiceSearch').value = event.detail?.query || '';
            renderInvoiceRows(true);
        });
        await loadBilling();
    } else {
        CalixRecordDeletion.bind($('paymentRows'), loadPayments);
        $('paymentSearch').addEventListener('input', () => renderPaymentRows(true));
        $('previousPaymentPage').addEventListener('click', () => {
            if (paymentPage > 1) {
                paymentPage -= 1;
                renderPaymentRows();
            }
        });
        $('nextPaymentPage').addEventListener('click', () => {
            paymentPage += 1;
            renderPaymentRows();
        });
        $('newPaymentButton')?.addEventListener('click', () => openPaymentForm());
        $('paymentInvoice').addEventListener('change', setPaymentInvoice);
        $('paymentForm').addEventListener('submit', async event => {
            event.preventDefault();
            const form = $('paymentForm');
            const button = $('savePaymentButton');
            if (!canManagePayments || button.disabled || !form.reportValidity()) return;
            const originalText = button.textContent;
            button.disabled = true;
            button.textContent = 'Recording payment…';
            CalixUI.clearFieldErrors(form);
            $('paymentFormError').textContent = '';
            try {
                await CalixAPI.post('finance.php?action=payment-create', {
                    billingId: Number($('paymentInvoice').value),
                    amount: $('paymentAmount').value,
                    paymentDate: $('paymentDate').value,
                    paymentMethod: $('paymentMethod').value,
                    referenceNo: $('paymentReference').value.trim(),
                    notes: $('paymentNotes').value.trim()
                });
                $('paymentDialog').close();
                await loadPayments();
                notice('paymentNotice', 'Payment recorded. The invoice balance has been recalculated.', 'success');
            } catch (error) {
                CalixUI.showFormError(form, error, $('paymentFormError'));
            } finally {
                button.disabled = false;
                button.textContent = originalText;
            }
        });
        document.querySelectorAll('[data-payment-close]').forEach(button => button.addEventListener('click', () => $('paymentDialog').close()));
        window.addEventListener('calix:search', event => {
            $('paymentSearch').value = event.detail?.query || '';
            renderPaymentRows(true);
        });
        await loadPayments();
    }
})();
