<?php
require __DIR__ . '/../../../api/common.php';

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

function canViewSalesFinancials(mysqli $conn, array $user): bool
{
    if ($user['role'] === 'ADMIN') return true;
    $permissions = userPermissions($conn, (string)$user['role']);
    return in_array('reports.financial', $permissions, true)
        || in_array('sales.manage', $permissions, true);
}

if ($action === 'list' && $method === 'GET') {
    $user = requirePermission($conn, 'sales.view');
    if (canViewSalesFinancials($conn, $user)) {
        sendJson(allRows($conn, "SELECT s.sales_id,s.customer_id,s.project_id,s.quotation_id,s.sale_date,s.total_amount,
            c.customer_name,c.company_name,p.project_name,p.status project_status,q.quotation_number
            FROM sales s
            JOIN customers c ON c.customer_id=s.customer_id
            LEFT JOIN projects p ON p.project_id=s.project_id
            LEFT JOIN quotations q ON q.quotation_id=s.quotation_id
            WHERE s.deleted_at IS NULL
            ORDER BY s.sale_date DESC,s.sales_id DESC"));
    }
    sendJson(allRows($conn, "SELECT s.sales_id,s.customer_id,s.project_id,s.quotation_id,s.sale_date,
        c.customer_name,c.company_name,p.project_name,p.status project_status,q.quotation_number
        FROM sales s
        JOIN customers c ON c.customer_id=s.customer_id
        LEFT JOIN projects p ON p.project_id=s.project_id
        LEFT JOIN quotations q ON q.quotation_id=s.quotation_id
        WHERE s.deleted_at IS NULL
        ORDER BY s.sale_date DESC,s.sales_id DESC"));
}

if ($action === 'summary' && $method === 'GET') {
    $user = requirePermission($conn, 'sales.view');
    if (!canViewSalesFinancials($conn, $user)) {
        $row = one($conn, 'SELECT COUNT(*) records FROM sales WHERE deleted_at IS NULL');
        sendJson(['records' => (int)($row['records'] ?? 0), 'financialVisible' => false]);
    }
    $row = one($conn, "SELECT COUNT(*) records,
        COALESCE(SUM(total_amount),0) contract_value,
        COALESCE(SUM(CASE WHEN YEAR(sale_date)=YEAR(CURDATE()) AND MONTH(sale_date)=MONTH(CURDATE()) THEN total_amount ELSE 0 END),0) month_contract_value
        FROM sales WHERE deleted_at IS NULL");
    sendJson(($row ?: []) + ['financialVisible' => true]);
}

if ($action === 'save' && $method === 'POST') {
    requirePermission($conn, 'sales.manage');
    sendError('Sales contract records are created from approved quotations and cannot be manually added or edited.', 409);
}

sendError('Sales API route not found.', 404);
