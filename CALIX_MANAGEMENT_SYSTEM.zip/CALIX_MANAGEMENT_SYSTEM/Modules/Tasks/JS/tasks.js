(() => {
  'use strict';

  const form = document.getElementById('taskForm');
  const dialog = document.getElementById('taskDialog');
  const detailsDialog = document.getElementById('noteDetailsDialog');
  const rows = document.getElementById('taskRows');
  if (!form || !dialog || !detailsDialog || !rows) return;

  const $ = (id) => document.getElementById(id);
  const account = JSON.parse(sessionStorage.getItem('calixAccount') || '{}');
  const canManage = account.role === 'ADMIN' || (account.permissions || []).includes('tasks.manage');
  const isAdmin = account.role === 'ADMIN';
  const filters = { scope: 'personal', search: '', view: 'list' };
  let notes = [];
  let calendarDate = new Date();

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (character) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
  }

  function notify(message, type = 'error') {
    if (window.CalixUI?.notify) window.CalixUI.notify(message, type);
    else window.alert(message);
  }

  async function api(action, data) {
    return window.CalixAPI.request(`tasks.php?action=${encodeURIComponent(action)}`, data === undefined
      ? { method: 'GET' }
      : { method: 'POST', body: JSON.stringify(data) });
  }

  function localDate(value) {
    if (!value) return '';
    const date = new Date(`${value}T00:00:00`);
    return Number.isNaN(date.getTime())
      ? value
      : date.toLocaleDateString('en-PH', { year: 'numeric', month: 'short', day: 'numeric' });
  }

  function dateKey(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  }

  function visibleNotes() {
    const query = filters.search.toLocaleLowerCase();
    return notes.filter((note) => {
      if (filters.scope === 'personal' && (note.visibility !== 'PERSONAL' || Number(note.is_owner) !== 1)) return false;
      if (filters.scope === 'team' && note.visibility !== 'TEAM') return false;
      return !query || `${note.title} ${note.note_text || ''} ${note.creator_name || ''}`.toLocaleLowerCase().includes(query);
    });
  }

  function canEdit(note) {
    return canManage && Number(note.is_owner) === 1;
  }

  function showNote(note) {
    if (!note) return;
    $('noteDetailsVisibility').textContent = note.visibility === 'TEAM' ? 'Team' : 'Personal';
    $('noteDetailsTitle').textContent = note.title || 'Untitled note';
    $('noteDetailsContent').textContent = note.note_text || 'This note has no additional details.';
    $('noteDetailsMeta').textContent = [
      `By ${note.creator_name || 'Team member'}`,
      note.due_date ? `Reminder ${localDate(note.due_date)}` : ''
    ].filter(Boolean).join(' · ');
    const editButton = $('noteDetailsEdit');
    editButton.hidden = !canEdit(note);
    editButton.dataset.noteId = note.todo_id;
    detailsDialog.showModal();
  }

  function render() {
    const shown = visibleNotes();
    $('personalNoteCount').textContent = notes.filter((note) => note.visibility === 'PERSONAL' && Number(note.is_owner) === 1).length;
    $('teamNoteCount').textContent = notes.filter((note) => note.visibility === 'TEAM').length;

    $('taskResultCount').textContent = filters.view === 'list'
      ? `${shown.length} ${shown.length === 1 ? 'note' : 'notes'}`
      : `${shown.filter((note) => note.due_date && note.due_date.startsWith(`${calendarDate.getFullYear()}-${String(calendarDate.getMonth() + 1).padStart(2, '0')}`)).length} reminders this month`;
    rows.hidden = filters.view !== 'list';
    $('taskCalendar').hidden = filters.view !== 'calendar';
    $('taskEmpty').hidden = filters.view !== 'list' || shown.length > 0;
    rows.innerHTML = shown.map((note) => {
      const actions = `<div class="team-note-actions">
          ${canEdit(note) ? `<button type="button" class="button secondary" data-note-edit="${Number(note.todo_id)}">Edit</button>` : ''}
          ${canManage && (Number(note.is_owner) === 1 || isAdmin || Number(note.can_manage) === 1) ? `<button type="button" class="button danger" data-note-delete="${Number(note.todo_id)}">Delete</button>` : ''}
        </div>`;
      const color = /^#[0-9a-f]{6}$/i.test(note.color || '') ? note.color : '#fff2cc';
      return `<article class="team-note-card" style="--note-color:${color}">
        <div class="team-note-card-top">
          <h3><button type="button" class="note-title-button" data-note-view="${Number(note.todo_id)}">${escapeHtml(note.title)}</button></h3>
          <div class="team-note-badges">
            <span class="team-note-badge">${note.visibility === 'TEAM' ? 'Team' : 'Personal'}</span>
          </div>
        </div>
        ${note.note_text ? `<p class="team-note-details">${escapeHtml(note.note_text)}</p>` : ''}
        <div class="team-note-card-footer">
          <span>${escapeHtml(note.creator_name || 'Team member')}${note.due_date ? ` · Reminder ${escapeHtml(localDate(note.due_date))}` : ''}</span>
          ${actions}
        </div>
      </article>`;
    }).join('');
    renderCalendar(shown);
    renderReminderNotices(shown);
    const emptyTitle = filters.search
      ? 'No matching notes'
      : (filters.scope === 'personal' ? 'No personal notes yet' : 'No team notes yet');
    $('taskEmptyTitle').textContent = emptyTitle;
    $('taskEmptyDescription').textContent = filters.search
      ? 'Try changing your search or filters.'
      : (filters.scope === 'personal'
        ? 'Add a personal note or choose a reminder date to see it on the calendar.'
        : 'Share a note with your team and it will appear here.');
  }

  function renderCalendar(shown) {
    const year = calendarDate.getFullYear();
    const month = calendarDate.getMonth();
    const monthKey = `${year}-${String(month + 1).padStart(2, '0')}`;
    $('calendarMonth').textContent = calendarDate.toLocaleDateString('en-PH', { month: 'long', year: 'numeric' });
    const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const firstDay = new Date(year, month, 1).getDay();
    const gridStart = new Date(year, month, 1 - firstDay);
    const entriesByDate = new Map();
    shown.forEach((note) => {
      if (!note.due_date) return;
      if (!entriesByDate.has(note.due_date)) entriesByDate.set(note.due_date, []);
      entriesByDate.get(note.due_date).push(note);
    });
    const todayKey = dateKey(new Date());
    const cells = weekdays.map((day) => `<div class="notes-calendar-weekday">${day}</div>`);
    for (let offset = 0; offset < 42; offset += 1) {
      const date = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + offset);
      const key = dateKey(date);
      const items = entriesByDate.get(key) || [];
      const itemMarkup = items.map((note) => {
        const itemContent = `<span class="notes-calendar-item-title">${escapeHtml(note.title)}</span>`;
        const color = /^#[0-9a-f]{6}$/i.test(note.color || '') ? note.color : '#fff2cc';
        return `<button type="button" class="notes-calendar-item" data-note-view="${Number(note.todo_id)}" style="--note-color:${color}" title="${escapeHtml(note.title)}">${itemContent}</button>`;
      }).join('');
      cells.push(`<div class="notes-calendar-day${key.slice(0, 7) !== monthKey ? ' outside' : ''}${key === todayKey ? ' today' : ''}">
        <span class="notes-calendar-date">${date.getDate()}</span>${itemMarkup}
      </div>`);
    }
    $('taskCalendarGrid').innerHTML = cells.join('');
  }

  function renderReminderNotices(shown) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const weekEnd = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 7);
    const notices = shown.filter((note) => {
      if (!note.due_date || Number(note.is_completed) === 1) return false;
      const due = new Date(`${note.due_date}T00:00:00`);
      return due <= weekEnd;
    }).sort((left, right) => left.due_date.localeCompare(right.due_date));
    const notice = $('reminderNotice');
    notice.hidden = notices.length === 0;
    $('reminderNoticeItems').innerHTML = notices.map((note) => {
      const due = new Date(`${note.due_date}T00:00:00`);
      const overdue = due < today;
      const label = overdue ? 'Overdue' : (dateKey(due) === dateKey(today) ? 'Today' : localDate(note.due_date));
      const title = `<button type="button" data-note-view="${Number(note.todo_id)}">${escapeHtml(note.title)}</button>`;
      return `<p class="reminder-notice-item${overdue ? ' overdue' : ''}"><strong>${label}</strong>${title}</p>`;
    }).join('');
  }

  async function loadNotes() {
    rows.innerHTML = '<p class="empty-state">Loading notes…</p>';
    try {
      const result = await api('list');
      notes = Array.isArray(result.notes) ? result.notes : [];
      render();
    } catch (error) {
      rows.innerHTML = '';
      $('taskResultCount').textContent = 'Notes unavailable';
      notify(error.message);
    }
  }

  function clearForm() {
    form.reset();
    $('taskId').value = '';
    $('taskDialogTitle').textContent = 'New note';
    $('taskFormError').textContent = '';
    form.querySelector('input[name="noteVisibility"][value="PERSONAL"]').checked = true;
    $('teamNoteVisibility').disabled = !isAdmin;
    $('teamVisibilityHelp').textContent = isAdmin
      ? 'Share this note with everyone on the team'
      : 'Only admins can create team reminders';
    form.querySelector('input[name="noteColor"][value="#fff2cc"]').checked = true;
  }

  function openForm(note) {
    clearForm();
    if (note) {
      $('taskId').value = note.todo_id;
      $('taskDialogTitle').textContent = 'Edit note';
      $('taskTitle').value = note.title || '';
      $('taskDetails').value = note.note_text || '';
      $('taskDueDate').value = note.due_date || '';
      form.querySelector(`input[name="noteVisibility"][value="${note.visibility === 'TEAM' ? 'TEAM' : 'PERSONAL'}"]`).checked = true;
      const colorChoice = form.querySelector(`input[name="noteColor"][value="${note.color || '#fff2cc'}"]`);
      (colorChoice || form.querySelector('input[name="noteColor"][value="#fff2cc"]')).checked = true;
      $('teamNoteVisibility').disabled = !isAdmin && note.visibility !== 'TEAM';
    }
    dialog.showModal();
  }

  $('addTaskButton')?.addEventListener('click', () => openForm());
  dialog.querySelectorAll('[data-close-task]').forEach((button) => button.addEventListener('click', () => dialog.close()));
  dialog.addEventListener('click', (event) => {
    if (event.target === dialog) dialog.close();
  });
  detailsDialog.querySelectorAll('[data-close-note-details]').forEach((button) => button.addEventListener('click', () => detailsDialog.close()));
  detailsDialog.addEventListener('click', (event) => {
    if (event.target === detailsDialog) detailsDialog.close();
  });
  $('noteDetailsEdit').addEventListener('click', () => {
    const note = notes.find((item) => Number(item.todo_id) === Number($('noteDetailsEdit').dataset.noteId));
    if (!note || !canEdit(note)) return;
    detailsDialog.close();
    openForm(note);
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    $('saveTaskButton').disabled = true;
    $('taskFormError').textContent = '';
    try {
      await api('save', {
        id: $('taskId').value || null,
        title: $('taskTitle').value.trim(),
        details: $('taskDetails').value.trim(),
        visibility: form.querySelector('input[name="noteVisibility"]:checked').value,
        due_date: $('taskDueDate').value || null,
        color: form.querySelector('input[name="noteColor"]:checked').value
      });
      dialog.close();
      await loadNotes();
      notify('Note saved.', 'success');
    } catch (error) {
      $('taskFormError').textContent = error.message;
    } finally {
      $('saveTaskButton').disabled = false;
    }
  });

  rows.addEventListener('click', async (event) => {
    const viewButton = event.target.closest('[data-note-view]');
    if (viewButton) {
      showNote(notes.find((item) => Number(item.todo_id) === Number(viewButton.dataset.noteView)));
      return;
    }
    const editButton = event.target.closest('[data-note-edit]');
    if (editButton) {
      const note = notes.find((item) => Number(item.todo_id) === Number(editButton.dataset.noteEdit));
      if (note && canEdit(note)) openForm(note);
      return;
    }
    const deleteButton = event.target.closest('[data-note-delete]');
    if (!deleteButton) return;
    const note = notes.find((item) => Number(item.todo_id) === Number(deleteButton.dataset.noteDelete));
    if (!note) return;
    const confirmed = window.CalixUI?.confirm
      ? await window.CalixUI.confirm({
        title: 'Move note to Trash?',
        message: `“${note.title}” will be recoverable from the administrator-protected Trashbin.`,
        confirmLabel: 'Move to Trash',
        danger: true
      })
      : window.confirm(`Move “${note.title}” to Trash? An administrator can restore it.`);
    if (!confirmed) return;
    try {
      await api('delete', { id: note.todo_id });
      await loadNotes();
      notify('Note moved to Trash.', 'success');
    } catch (error) {
      notify(error.message);
    }
  });

  $('taskSearch')?.addEventListener('input', (event) => {
    filters.search = event.target.value.trim();
    render();
  });
  document.querySelectorAll('[data-scope]').forEach((button) => button.addEventListener('click', () => {
    filters.scope = button.dataset.scope;
    document.querySelectorAll('[data-scope]').forEach((item) => {
      item.classList.toggle('active', item === button);
      item.setAttribute('aria-pressed', String(item === button));
    });
    render();
  }));

  document.querySelectorAll('[data-notes-view]').forEach((button) => button.addEventListener('click', () => {
    filters.view = button.dataset.notesView;
    document.querySelectorAll('[data-notes-view]').forEach((item) => {
      const active = item === button;
      item.classList.toggle('active', active);
      item.setAttribute('aria-pressed', String(active));
    });
    render();
  }));

  $('calendarPrevious')?.addEventListener('click', () => {
    calendarDate = new Date(calendarDate.getFullYear(), calendarDate.getMonth() - 1, 1);
    render();
  });
  $('calendarNext')?.addEventListener('click', () => {
    calendarDate = new Date(calendarDate.getFullYear(), calendarDate.getMonth() + 1, 1);
    render();
  });
  $('calendarToday')?.addEventListener('click', () => {
    calendarDate = new Date();
    render();
  });

  ['taskCalendarGrid', 'reminderNoticeItems'].forEach((id) => {
    $(id).addEventListener('click', (event) => {
      const viewButton = event.target.closest('[data-note-view]');
      if (!viewButton) return;
      showNote(notes.find((item) => Number(item.todo_id) === Number(viewButton.dataset.noteView)));
    });
  });

  loadNotes();
})();
