(async () => {
  const $ = (id) => document.getElementById(id);
  const esc = (value) => CalixUI.escape(String(value ?? ""));
  const quotationId = new URLSearchParams(location.search).get("id");
  const projectRoot = new URL("../../../", location.href);
  const logoUrl = new URL("Assets/CALIX_LOGO_PRINT.png", projectRoot).href;

  $("backBtn").addEventListener("click", () => {
    location.href = "Projects.html";
  });

  $("printBtn").addEventListener("click", async () => {
    const images = [...document.querySelectorAll("#quotePaper img")];
    await Promise.all(
      images.map((image) =>
        image.complete
          ? Promise.resolve()
          : new Promise((resolve) => {
              image.addEventListener("load", resolve, { once: true });
              image.addEventListener("error", resolve, { once: true });
            }),
      ),
    );
    window.print();
  });

  if (!quotationId) {
    $("quotePaper").innerHTML =
      '<div class="print-error"><h2>Quotation ID is missing.</h2></div>';
    return;
  }

  function printDate(value) {
    if (!value) return "—";
    const date = new Date(`${String(value).slice(0, 10)}T00:00:00`);
    if (Number.isNaN(date.getTime())) return esc(value);
    return new Intl.DateTimeFormat("en-PH", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
      .format(date)
      .replace(",", "");
  }

  function number(value) {
    return new Intl.NumberFormat("en-PH", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(Number(value) || 0);
  }

  function money(value) {
    return `₱ ${number(value)}`;
  }

  function lines(value) {
    return String(value || "")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);
  }

  function validityDays(quotation, business) {
    if (quotation.quotation_date && quotation.valid_until) {
      const start = new Date(
        `${String(quotation.quotation_date).slice(0, 10)}T00:00:00`,
      );
      const end = new Date(
        `${String(quotation.valid_until).slice(0, 10)}T00:00:00`,
      );
      const days = Math.round((end - start) / 86400000);
      if (days > 0) return days;
    }
    return Number(business.default_validity_days) || 7;
  }

  function paymentRows(value) {
    const defaults = [
      "50% DOWN PAYMENT (Cash or Online Payment)",
      "30% UPON DELIVERY OF THE MATERIALS",
      "20% BALANCE UPON COMPLETION OF THE PROJECT",
    ];
    return (lines(value).length ? lines(value) : defaults)
      .map((line) => {
        const match = line.match(/^\s*(\d+(?:\.\d+)?%)\s*[-–:]?\s*(.*)$/);
        if (!match) {
          return `<div class="ref-payment-line"><span></span><span>${esc(line)}</span></div>`;
        }
        return `<div class="ref-payment-line"><span class="ref-payment-percent">${esc(match[1])}</span><span>${esc(match[2])}</span></div>`;
      })
      .join("");
  }

  function drawingPaths(item) {
    let drawings = [];
    if (Array.isArray(item.drawing_images)) drawings = item.drawing_images;
    else if (
      typeof item.drawing_images === "string" &&
      item.drawing_images.trim()
    ) {
      try {
        const parsed = JSON.parse(item.drawing_images);
        if (Array.isArray(parsed)) drawings = parsed;
      } catch (error) {
        console.warn("Quotation drawing list is invalid.", error);
      }
    }
    if (!drawings.length && item.drawing_image) drawings = [item.drawing_image];
    return drawings.filter(Boolean).slice(0, 4);
  }

  function drawingUrl(path) {
    const match = String(path || "").match(
      /(?:^|\/)(drawing_[0-9]{8}_[0-9]{6}_[a-f0-9]{12}\.(?:jpg|png|webp))$/i,
    );
    return match
      ? CalixAPI.url(
          `quotation-drawing.php?file=${encodeURIComponent(match[1])}`,
        )
      : "";
  }

  function drawingMarkup(item) {
    const sources = drawingPaths(item).map(drawingUrl).filter(Boolean);
    if (!sources.length) return "";
    const gridClass =
      sources.length === 1 ? "ref-drawing-grid single" : "ref-drawing-grid";
    return `<div class="${gridClass}">${sources
      .map(
        (source, index) =>
          `<img class="ref-drawing" src="${esc(source)}" alt="Quotation item drawing ${index + 1}">`,
      )
      .join("")}</div>`;
  }

  function detailMarkup(item) {
    const drawings = drawingMarkup(item);
    const description = String(item.description || "").trim();
    const specification = String(item.specification || "").trim();
    if (!drawings && !description && !specification) return "";

    const text = [description, specification]
      .filter(Boolean)
      .map(
        (value) =>
          `<div class="ref-spec-copy">${esc(value).replace(/\r?\n/g, "<br>")}</div>`,
      )
      .join("");
    return `<tr class="ref-detail-row">
            <td class="ref-drawing-cell" colspan="2">${drawings}</td>
            <td class="ref-specification-cell">${text}</td>
            <td class="ref-empty-detail-cell"></td>
            <td class="ref-empty-detail-cell"></td>
            <td class="ref-empty-detail-cell"></td>
        </tr>`;
  }

  function itemMarkup(item, index) {
    const detail = detailMarkup(item);
    return `<tbody class="ref-item-group">
            <tr class="ref-summary-row">
                <td class="item-cell">${esc(item.item_code || `W-${String(index + 1).padStart(2, "0")}`)}</td>
                <td>${esc(item.location || "")}</td>
                <td>${esc(item.dimensions || "")}</td>
                <td class="qty-cell">${esc(String(Number(item.quantity ?? 0)))} ${esc(item.unit || "set")}</td>
                <td class="money-cell">${number(item.unit_price)}</td>
                <td class="money-cell">${number(item.amount)}</td>
            </tr>
            ${detail}
        </tbody>`;
  }

  function render(quotation, business) {
    const items = Array.isArray(quotation.items) ? quotation.items : [];
    const representatives = lines(quotation.authorized_representatives);
    const customerName = quotation.customer_name || "—";
    const location =
      quotation.project_address || quotation.customer_address || "—";
    const names = representatives.length ? representatives : [customerName];
    const vatType = String(
      quotation.vat_type || business.default_vat_type || "VAT EXCLUSIVE",
    ).toUpperCase();
    const vatLabel =
      vatType === "NON-VAT"
        ? "NON-VAT"
        : vatType === "VAT INCLUSIVE"
          ? "VAT inclusive"
          : "VAT exclusive";
    const validity = validityDays(quotation, business);
    const fabrication =
      quotation.fabrication_terms || business.default_fabrication_terms || "";
    const acceptance =
      quotation.acceptance_statement ||
      business.default_acceptance_statement ||
      "";
    const signer =
      business.authorized_representative || "Ms. Rowena L. Paeldon";
    const position =
      business.authorized_representative_position || "Marketing Manager";
    const introduction =
      "We are pleased to submit our quotation for your evaluation. Our standard terms and conditions are also included for your ready reference.";

    document.title = `${quotation.quotation_number || "Quotation"} | CALIX`;
    $("quotePaper").innerHTML = `
            <header class="ref-brand">
                <img class="ref-brand-logo" src="${esc(logoUrl)}" alt="CALIX glass and aluminum fabrication">
            </header>
            <section class="ref-meta" aria-label="Quotation details">
                <div class="ref-meta-row"><span class="ref-meta-label">DATE</span><span class="ref-meta-colon">:</span><span class="ref-meta-value">${printDate(quotation.quotation_date)}</span></div>
                <div class="ref-meta-row"><span class="ref-meta-label">ATTENTION</span><span class="ref-meta-colon">:</span><span class="ref-meta-value">${esc(customerName)}</span></div>
                <div class="ref-meta-row"><span class="ref-meta-label">PROJECT LOCATION</span><span class="ref-meta-colon">:</span><span class="ref-meta-value">${esc(location)}</span></div>
                ${Number(quotation.estimated_duration_days) > 0 ? `<div class="ref-meta-row"><span class="ref-meta-label">ESTIMATED DURATION</span><span class="ref-meta-colon">:</span><span class="ref-meta-value">${Number(quotation.estimated_duration_days)} calendar days</span></div>` : ""}
                <div class="ref-meta-row"><span class="ref-meta-label">QUOTATION No.</span><span class="ref-meta-colon">:</span><span class="ref-meta-value">${esc(quotation.quotation_number || "—")}</span></div>
            </section>
            <section class="ref-letter">
                <p>Dear Sir / Ma’am,</p>
                <p>${introduction}</p>
            </section>
            <div class="ref-items-wrap">
                <table class="ref-items" aria-label="Quotation items">
                    <colgroup><col class="item"><col class="location"><col class="specification"><col class="qty"><col class="unitprice"><col class="total"></colgroup>
                    <thead><tr><th>ITEM</th><th>LOCATION</th><th>SPECIFICATION</th><th>QTY</th><th>UNIT PRICE</th><th>TOTAL AMNT</th></tr></thead>
                    ${items.map(itemMarkup).join("")}
                </table>
            </div>
            <section class="ref-contract">
                <div class="ref-total-block">
                    <div class="ref-total-grid">
                        <span class="label">Total Contract Price:</span><span class="amount">${money(quotation.total_amount)}</span>
                        <span class="vat">${esc(vatLabel)}</span>
                    </div>
                </div>
                <div class="ref-term-row ref-protected-section">
                    <h2 class="ref-term-label">PAYMENT TERMS:</h2>
                    <div class="ref-payment-list">${paymentRows(quotation.payment_terms || business.default_payment_terms)}</div>
                </div>
                <div class="ref-term-row ref-protected-section">
                    <h2 class="ref-term-label">QUOTATION VALIDITY:</h2>
                    <div class="ref-term-copy">${validity} calendar days, prices are subject to change after the validity period without prior notice.</div>
                </div>
                ${fabrication ? `<div class="ref-term-row ref-protected-section"><h2 class="ref-term-label">FABRICATION:</h2><div class="ref-term-copy">${esc(fabrication).replace(/\r?\n/g, "<br>")}</div></div>` : ""}
                <div class="ref-confirmation-section">
                    ${acceptance ? `<p class="ref-acceptance">${esc(acceptance).replace(/\r?\n/g, "<br>")}</p>` : ""}
                    <p class="ref-closing">Very truly yours,</p>
                    <div class="ref-signer-signature-space" aria-hidden="true"></div>
                    <div class="ref-signer"><span class="ref-signer-name">${esc(signer)}</span><span class="ref-signer-position">${esc(position)}</span></div>
                    <div class="ref-confirmed-list">${names
                      .map(
                        (name, index) => `<div class="ref-confirmed-row">
                        <span class="ref-confirm-label">${index === 0 ? "Conformed by:" : ""}</span>
                        <div class="ref-name-block"><span class="ref-line"></span><span class="ref-confirm-name">${esc(name)}</span></div>
                        <span class="ref-date-label">Date:</span><span class="ref-date-line"></span>
                    </div>`,
                      )
                      .join("")}</div>
                </div>
            </section>`;
  }

  try {
    const data = await CalixAPI.get(
      `quotations.php?action=print-data&id=${encodeURIComponent(quotationId)}`,
    );
    if (!data?.quotation)
      throw new Error("Quotation data was not returned by the server.");
    render(data.quotation, data.business || {});
  } catch (error) {
    console.error("Unable to load printable quotation.", error);
    $("quotePaper").innerHTML =
      `<div class="print-error"><h2>Quotation could not be loaded</h2><p>${esc(error.message || "Please try again.")}</p></div>`;
  }
})();
