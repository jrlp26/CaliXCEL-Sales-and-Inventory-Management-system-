(function () {
  let quotes = [];
  let projects = [];
  let dashboardTargetHandled = false;
  let account = null;
  try {
    account = JSON.parse(sessionStorage.getItem("calixAccount") || "null");
  } catch (_) {}
  const permissionSet = new Set(account?.permissions || []);
  const can = (permission) =>
    account?.role === "ADMIN" || permissionSet.has(permission);
  const canManageQuotations = can("quotations.manage");
  const canManageProjects = can("projects.manage");

  const body = document.getElementById("quoteRows");
  const search = document.getElementById("quoteSearch");
  const quoteFilter = document.getElementById("quoteStatus");
  const projectFilter = document.getElementById("projectFilter");
  const quoteDialog = document.getElementById("quoteDialog");
  const approvalDialog = document.getElementById("contractApprovalDialog");
  const approvalForm = document.getElementById("contractApprovalForm");
  const projectDialog = document.getElementById("projectDialog");
  const projectForm = document.getElementById("projectForm");
  const pageSize = 8;
  let currentPage = 1;

  if (!body) return;

  function projectByQuote() {
    return Object.fromEntries(
      projects.map((project) => [String(project.quotation_id), project]),
    );
  }

  function actionOptions(quotation, project) {
    const options = [["print", "Print quotation"]];
    if (quotation.status === "DRAFT" && canManageQuotations) {
      options.push(["edit", "Edit quotation"]);
      options.push(["submit", "Submit for review"]);
    }
    if (quotation.status === "PENDING" && canManageQuotations) {
      options.push(["edit", "Edit quotation"]);
      options.push(["approve", "Approve quotation"]);
      options.push(["reject", "Reject quotation"]);
    }
    if (project && canManageProjects)
      options.push(["project", "Manage project"]);
    const quotationId = CalixUI.escape(String(quotation.quotation_id));
    const projectId = CalixUI.escape(String(project?.project_id || ""));
    return options
      .map(
        ([action, label]) =>
          `<button class="text-button" type="button" data-quotation-action="${action}" data-quotation-id="${quotationId}" data-project-id="${projectId}">${label}</button>`,
      )
      .join("");
  }

  function quotationStatus(status) {
    const label = status === "PENDING" ? "For Review" : status;
    return `<span class="status-chip ${status === "PENDING" ? "pending" : String(status || "").toLowerCase()}">${CalixUI.escape(label || "—")}</span>`;
  }

  function render(resetPage = false) {
    const term = (search.value || "").trim().toLowerCase();
    const quotationStatusFilter = quoteFilter.value;
    const projectStatus = projectFilter.value;
    const map = projectByQuote();
    const filtered = quotes.filter((quotation) => {
      const project = map[String(quotation.quotation_id)];
      const currentProjectStatus = project ? project.status : "NOT_CREATED";
      return (
        (!quotationStatusFilter ||
          quotation.status === quotationStatusFilter) &&
        (!projectStatus || currentProjectStatus === projectStatus) &&
        (!term ||
          JSON.stringify({ ...quotation, project: project || {} })
            .toLowerCase()
            .includes(term))
      );
    });

    const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
    if (resetPage) currentPage = 1;
    currentPage = Math.min(currentPage, totalPages);
    const start = (currentPage - 1) * pageSize;
    const visible = filtered.slice(start, start + pageSize);
    body.innerHTML =
      visible
        .map((quotation) => {
          const project = map[String(quotation.quotation_id)];
          const projectTitle = project
            ? `<small class="record-subline">${CalixUI.escape(project.project_name || "Project")}</small>`
            : '<small class="record-subline muted">Project created after approval</small>';
          const projectStatusMarkup = project
            ? CalixUI.status(project.status)
            : quotation.status === "APPROVED"
              ? '<span class="status-chip pending">Creating…</span>'
              : '<span class="status-chip neutral">Not created</span>';
          return `<tr>
                <td><strong>${CalixUI.escape(quotation.quotation_number)}</strong>${projectTitle}</td>
                <td>${CalixUI.escape(quotation.customer_name)}</td>
                <td>${CalixUI.date(quotation.quotation_date)}</td>
                <td>${CalixUI.money(quotation.total_amount)}</td>
                <td>${quotationStatus(quotation.status)}</td>
                <td>${projectStatusMarkup}</td>
                <td>${Number(project?.estimated_duration_days || quotation.estimated_duration_days) > 0 ? `${Number(project?.estimated_duration_days || quotation.estimated_duration_days)} days` : "—"}</td>
                <td>${project?.deadline ? CalixUI.date(project.deadline) : "—"}</td>
                <td><div class="action-row project-history-actions">
                    <button class="text-button" type="button" data-view="${quotation.quotation_id}">View</button>
                    <details class="project-action-menu">
                        <summary class="text-button" aria-label="Actions for ${CalixUI.escape(quotation.quotation_number)}">Actions</summary>
                        <div class="project-action-options">${actionOptions(quotation, project)}</div>
                    </details>
                ${CalixRecordDeletion.button("quotations", quotation.quotation_id, quotation.quotation_number)}
                ${project ? CalixRecordDeletion.button("projects", project.project_id, project.project_name) : ""}
                </div></td>
            </tr>`;
        })
        .join("") ||
      '<tr><td colspan="9" class="empty-state">No quotation or project records match these filters.</td></tr>';
    document.getElementById("projectResultCount").textContent =
      `${filtered.length} record${filtered.length === 1 ? "" : "s"}`;
    document.getElementById("projectPageSummary").textContent = filtered.length
      ? `Showing ${start + 1}–${Math.min(start + pageSize, filtered.length)} of ${filtered.length} records`
      : "Showing 0 records";
    document.getElementById("projectPageNumber").textContent =
      `Page ${currentPage} of ${totalPages}`;
    document.getElementById("previousProjectPage").disabled = currentPage <= 1;
    document.getElementById("nextProjectPage").disabled = currentPage >= totalPages;
  }

  function localDate(date) {
    const pad = (value) => String(value).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  }

  async function load() {
    try {
      const results = await Promise.all([
        CalixAPI.get("quotations.php?action=list"),
        CalixAPI.get("projects.php?action=list"),
      ]);
      quotes = results[0] || [];
      projects = results[1] || [];

      const params = new URLSearchParams(location.search);
      if (!dashboardTargetHandled) {
        const status = params.get("status");
        const projectStatusParam = params.get("project_status");
        if (status && quoteFilter) quoteFilter.value = status;
        if (projectStatusParam && projectFilter)
          projectFilter.value = projectStatusParam;
      }

      render(true);

      if (!dashboardTargetHandled) {
        const target = params.get("quotation");
        if (target) {
          const quotation = quotes.find(
            (item) => String(item.quotation_id) === String(target),
          );
          if (quotation) {
            search.value = quotation.quotation_number || "";
            render(true);
            setTimeout(
              () =>
                body
                  .querySelector(`[data-view="${CSS.escape(String(target))}"]`)
                  ?.click(),
              0,
            );
          }
        }
        dashboardTargetHandled = true;
      }
    } catch (error) {
      body.innerHTML = `<tr><td colspan="9" class="empty-state">${CalixUI.escape(error?.message || "Unable to load project history.")}</td></tr>`;
    }
  }

  function drawingCount(item) {
    if (Array.isArray(item.drawing_images)) return item.drawing_images.length;
    if (typeof item.drawing_images === "string" && item.drawing_images.trim()) {
      try {
        const parsed = JSON.parse(item.drawing_images);
        if (Array.isArray(parsed)) return parsed.filter(Boolean).length;
      } catch (_) {}
    }
    return item.drawing_image ? 1 : 0;
  }

  async function openQuotation(id) {
    const quotation = await CalixAPI.get(
      `quotations.php?action=get&id=${encodeURIComponent(id)}`,
    );
    document.getElementById("quoteDialogTitle").textContent =
      quotation.quotation_number;
    document.getElementById("quoteDetails").innerHTML = `
            <div class="quote-detail-summary">
                <p><strong>${CalixUI.escape(quotation.customer_name)}</strong></p>
                <p>${CalixUI.escape(quotation.project_name || "No project name")}</p>
                ${Number(quotation.estimated_duration_days) > 0 ? `<p>Estimated duration: ${Number(quotation.estimated_duration_days)} days</p>` : ""}
                <p>                ${quotationStatus(quotation.status)}</p>
                ${quotation.signed_contract_file ? `<p>Signed by ${CalixUI.escape(quotation.signed_by || "Customer")} on ${CalixUI.date(quotation.signed_date)} · <a href="${CalixAPI.url(`quotation-contract-file.php?id=${encodeURIComponent(quotation.quotation_id)}`)}">Download signed contract</a></p>` : ""}
            </div>
            <div class="table-wrap"><table class="data-table">
                <thead><tr><th>Item</th><th>Location / Description</th><th>Qty</th><th>Unit</th><th>Price</th><th>Amount</th></tr></thead>
                <tbody>${(quotation.items || [])
                  .map((item) => {
                    const drawings = drawingCount(item);
                    return `<tr><td>${CalixUI.escape(item.item_code || "—")}</td><td><strong>${CalixUI.escape(item.location || item.description)}</strong>${item.specification ? `<small class="record-subline">${CalixUI.escape(item.specification)}</small>` : ""}${drawings ? `<small class="record-subline">${drawings} drawing${drawings === 1 ? "" : "s"} attached</small>` : ""}</td><td>${String(Number(item.quantity ?? 0))}</td><td>${CalixUI.escape(item.unit)}</td><td>${CalixUI.money(item.unit_price)}</td><td>${CalixUI.money(item.amount)}</td></tr>`;
                  })
                  .join("")}</tbody>
            </table></div>
            <p class="right"><strong>Total: ${CalixUI.money(quotation.total_amount)}</strong></p>`;
    quoteDialog.showModal();
  }

  function openProject(project) {
    if (!project || !projectDialog) return;
    projectForm.reset();
    document.getElementById("projectId").value = project.project_id;
    document.getElementById("projectName").value = project.project_name || "";
    document.getElementById("projectAddress").value =
      project.project_address || "";
    document.getElementById("projectStart").value = project.start_date || "";
    document.getElementById("projectDeadline").value = project.deadline || "";
    const durationDays = Number(project.estimated_duration_days || 0);
    document.getElementById("projectDurationHint").textContent =
      durationDays > 0
        ? `Quotation estimate: ${durationDays} calendar days. Setting a start date calculates a suggested deadline.`
        : "No estimated duration was set on the quotation.";
    document.getElementById("projectStart").dataset.durationDays =
      String(durationDays);
    document.getElementById("projectStatus").value =
      project.status || "PENDING";
    const downPaymentPaid = Boolean(project.down_payment_paid);
    const alreadyPastStart = [
      "IN_PROGRESS",
      "FOR_INSTALLATION",
      "COMPLETED",
      "CLOSED",
    ].includes(project.status);
    const paymentGateSatisfied = downPaymentPaid || alreadyPastStart;
    document.getElementById("projectPaymentHint").textContent = downPaymentPaid
      ? `50% down payment paid (${CalixUI.money(project.down_payment_collected)} of ${CalixUI.money(project.down_payment_amount)}).`
      : alreadyPastStart
        ? `This project was already active before the milestone gate. Current down-payment collections: ${CalixUI.money(project.down_payment_collected)} of ${CalixUI.money(project.down_payment_amount)}.`
        : `In Progress and later stages are blocked until the 50% down payment is fully paid (${CalixUI.money(project.down_payment_collected)} of ${CalixUI.money(project.down_payment_amount)} collected). Record payment in Finance → Payments.`;
    document.querySelectorAll("#projectStatus option").forEach((option) => {
      option.disabled =
        !paymentGateSatisfied &&
        ["IN_PROGRESS", "FOR_INSTALLATION", "COMPLETED", "CLOSED"].includes(
          option.value,
        ) &&
        option.value !== project.status;
    });
    document.getElementById("projectDescription").value =
      project.description || "";
    document.getElementById("projectNotes").value = project.notes || "";
    document.getElementById("projectError").textContent = "";
    projectDialog.showModal();
  }

  function openContractApproval(quotationId) {
    if (!approvalDialog || !approvalForm) return;
    approvalForm.reset();
    document.getElementById("approvalQuotationId").value = quotationId;
    document.getElementById("contractSignedDate").value = localDate(new Date());
    document.getElementById("contractApprovalError").textContent = "";
    approvalDialog.showModal();
    document.getElementById("contractSignedBy").focus();
  }

  async function updateQuotationStatus(id, next) {
    if (
      next === "REJECTED" &&
      !(await CalixUI.confirm({
        title: "Reject quotation?",
        message:
          "This quotation will remain in quotation history and cannot be converted to a project.",
        confirmLabel: "Reject quotation",
        danger: true,
      }))
    )
      return;
    await CalixAPI.post("quotations.php?action=status", {
      quotationId: id,
      status: next,
    });
    await load();
    CalixUI.notify(
      next === "REJECTED"
        ? "Quotation rejected. It remains available in quotation history."
        : "Quotation submitted for review.",
      "success",
    );
  }

  search.addEventListener("input", () => render(true));
  CalixRecordDeletion.bind(body, load);
  quoteFilter.addEventListener("change", () => render(true));
  projectFilter.addEventListener("change", () => render(true));
  document.getElementById("previousProjectPage").addEventListener("click", () => {
    if (currentPage > 1) {
      currentPage -= 1;
      render();
    }
  });
  document.getElementById("nextProjectPage").addEventListener("click", () => {
    currentPage += 1;
    render();
  });
  window.addEventListener("calix:search", (event) => {
    search.value = event.detail?.query || "";
    render(true);
  });

  body.addEventListener("click", async (event) => {
    const viewButton = event.target.closest("[data-view]");
    if (viewButton) {
      try {
        await openQuotation(viewButton.dataset.view);
      } catch (error) {
        CalixUI.notify(error.message, "error");
      }
      return;
    }
    const actionButton = event.target.closest("[data-quotation-action]");
    if (!actionButton) return;
    const quotationId = actionButton.dataset.quotationId;
    const projectId = actionButton.dataset.projectId;
    const action = actionButton.dataset.quotationAction;
    actionButton.closest("details")?.removeAttribute("open");
    try {
      if (action === "print") {
        const preview = window.open(
          `PrintQuotation.html?id=${encodeURIComponent(quotationId)}&printVersion=${Date.now()}`,
          "_blank",
        );
        if (preview) preview.opener = null;
        return;
      }
      if (action === "edit") {
        location.href = `CreateQuotation.html?edit=${encodeURIComponent(quotationId)}`;
        return;
      }
      if (action === "approve") {
        openContractApproval(quotationId);
        return;
      }
      if (action === "reject") {
        await updateQuotationStatus(quotationId, "REJECTED");
        return;
      }
      if (action === "submit") {
        await updateQuotationStatus(quotationId, "PENDING");
        return;
      }
      if (action === "project") {
        openProject(
          projects.find(
            (project) => String(project.project_id) === String(projectId),
          ),
        );
      }
    } catch (error) {
      CalixUI.notify(error.message, "error");
    }
  });

  quoteDialog
    ?.querySelectorAll("[data-quote-close]")
    .forEach((button) =>
      button.addEventListener("click", () => quoteDialog.close()),
    );
  document
    .querySelectorAll("[data-approval-close]")
    .forEach((button) =>
      button.addEventListener("click", () => approvalDialog?.close()),
    );
  document
    .querySelectorAll("[data-close]")
    .forEach((button) =>
      button.addEventListener("click", () => projectDialog?.close()),
    );
  document
    .getElementById("projectStart")
    ?.addEventListener("change", (event) => {
      const days = Number(event.target.dataset.durationDays || 0);
      const start = event.target.value;
      if (!days || !start) return;
      const deadline = new Date(`${start}T00:00:00`);
      deadline.setDate(deadline.getDate() + days);
      const pad = (value) => String(value).padStart(2, "0");
      document.getElementById("projectDeadline").value =
        `${deadline.getFullYear()}-${pad(deadline.getMonth() + 1)}-${pad(deadline.getDate())}`;
    });

  approvalForm?.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!approvalForm.reportValidity()) return;
    const quotationId = Number(
      document.getElementById("approvalQuotationId").value || 0,
    );
    const file = document.getElementById("signedContractFile").files?.[0];
    if (!file) return;
    const button = document.getElementById("confirmContractApproval");
    const errorBox = document.getElementById("contractApprovalError");
    button.disabled = true;
    button.textContent = "Uploading & activating…";
    errorBox.textContent = "";
    try {
      const data = new FormData();
      data.append("quotationId", String(quotationId));
      data.append(
        "signedBy",
        document.getElementById("contractSignedBy").value.trim(),
      );
      data.append(
        "signedDate",
        document.getElementById("contractSignedDate").value,
      );
      data.append("file", file);
      const result = await CalixAPI.upload(
        "quotation-contract-upload.php",
        data,
      );
      approvalDialog.close();
      await load();
      CalixUI.notify(
        result.projectCreated
          ? `Signed quotation approved. Project #${result.projectId} is now active, with its billing milestones ready.`
          : `Signed quotation approved. Its linked project #${result.projectId} is now active.`,
        "success",
      );
    } catch (error) {
      errorBox.textContent =
        error.message || "The quotation could not be approved.";
    } finally {
      button.disabled = false;
      button.textContent = "Upload & Activate Project";
    }
  });

  if (projectForm) {
    projectForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      if (!projectForm.reportValidity()) return;
      const button = projectForm.querySelector('[type="submit"]');
      if (button.disabled) return;
      button.disabled = true;
      button.textContent = "Saving…";
      try {
        await CalixAPI.post("projects.php?action=update", {
          projectId: document.getElementById("projectId").value,
          projectName: document.getElementById("projectName").value,
          projectAddress: document.getElementById("projectAddress").value,
          startDate: document.getElementById("projectStart").value,
          deadline: document.getElementById("projectDeadline").value,
          status: document.getElementById("projectStatus").value,
          description: document.getElementById("projectDescription").value,
          notes: document.getElementById("projectNotes").value,
        });
        projectDialog.close();
        await load();
        CalixUI.notify("Project details saved.", "success");
      } catch (error) {
        document.getElementById("projectError").textContent = error.message;
      } finally {
        button.disabled = false;
        button.textContent = "Save Project";
      }
    });
  }

  window.loadQuotationRecords = load;
  window.loadProjects = load;
  setTimeout(load, 100);
})();
