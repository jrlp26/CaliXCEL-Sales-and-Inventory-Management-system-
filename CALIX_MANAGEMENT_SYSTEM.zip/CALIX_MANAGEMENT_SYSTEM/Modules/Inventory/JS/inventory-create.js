(function () {
    "use strict";

    const form = document.getElementById("inventoryForm");
    if (!form) return;

    const params = new URLSearchParams(window.location.search);
    const editId = Number(params.get("edit") || 0);
    const successNotice = document.getElementById("inventorySuccess");
    const errorNotice = document.getElementById("inventoryError");
    const successText = document.getElementById("inventorySuccessText");
    const pageTitle = document.getElementById("inventoryPageTitle");
    const saveButton = document.getElementById("saveInventoryButton") || form.querySelector('button[type="submit"]');
    const resetButton = document.getElementById("resetInventoryForm");
    const quantityHelp = document.getElementById("quantityHelp");
    let originalItem = null;
    let saving = false;

    const fields = {
        itemCode: document.getElementById("itemCode"),
        itemName: document.getElementById("itemName"),
        category: document.getElementById("category"),
        unit: document.getElementById("unit"),
        quantity: document.getElementById("quantity"),
        reorderLevel: document.getElementById("reorderLevel"),
        unitCost: document.getElementById("unitCost"),
        sellingPrice: document.getElementById("sellingPrice"),
        supplier: document.getElementById("supplier"),
        location: document.getElementById("location"),
        description: document.getElementById("description")
    };

    const preview = {
        code: document.getElementById("previewCode"),
        name: document.getElementById("previewName"),
        category: document.getElementById("previewCategory"),
        stock: document.getElementById("previewStock"),
        unit: document.getElementById("previewUnit"),
        cost: document.getElementById("previewCost"),
        price: document.getElementById("previewPrice"),
        status: document.getElementById("previewStatus")
    };

    function formatCurrency(value) {
        return new Intl.NumberFormat("en-PH", {style:"currency", currency:"PHP"}).format(Number(value) || 0);
    }

    function updatePreview() {
        const quantity = Number(fields.quantity.value) || 0;
        const reorderLevel = Number(fields.reorderLevel.value) || 0;
        let status = "In Stock";
        let statusClass = "status-chip";
        if (quantity <= 0) { status = "Out of Stock"; statusClass += " out"; }
        else if (quantity <= reorderLevel) { status = "Low Stock"; statusClass += " low"; }

        preview.code.textContent = fields.itemCode.value.trim().toUpperCase() || "ITEM CODE";
        preview.name.textContent = fields.itemName.value.trim() || "New inventory item";
        preview.category.textContent = fields.category.value || "Choose a category";
        preview.stock.textContent = quantity.toLocaleString("en-PH");
        preview.unit.textContent = fields.unit.value || "Unit";
        preview.cost.textContent = formatCurrency(fields.unitCost.value);
        preview.price.textContent = formatCurrency(fields.sellingPrice.value);
        preview.status.textContent = status;
        preview.status.className = statusClass;
    }

    function hideNotices() {
        successNotice.classList.remove("show");
        errorNotice.classList.remove("show");
    }

    function fill(item) {
        fields.itemCode.value = item?.itemCode || "";
        fields.itemName.value = item?.itemName || "";
        fields.category.value = item?.category || "";
        fields.unit.value = item?.unit || "";
        fields.quantity.value = Number(item?.quantity ?? 0);
        fields.reorderLevel.value = Number(item?.reorderLevel ?? 5);
        fields.unitCost.value = Number(item?.unitCost ?? 0);
        fields.sellingPrice.value = Number(item?.sellingPrice ?? 0);
        fields.supplier.value = item?.supplier || "";
        fields.location.value = item?.location || "";
        fields.description.value = item?.description || "";
        updatePreview();
    }

    function newDefaults(reorderLevel = 5) {
        fill({quantity:0,reorderLevel,unitCost:0,sellingPrice:0});
    }

    form.addEventListener("input", function () {
        hideNotices();
        updatePreview();
    });

    form.addEventListener("reset", function () {
        window.setTimeout(function () {
            if (editId && originalItem) fill(originalItem);
            else newDefaults();
        }, 0);
    });

    form.addEventListener("submit", async function (event) {
        event.preventDefault();
        hideNotices();
        if (saving || !form.reportValidity()) return;

        const payload = {
            itemCode: fields.itemCode.value,
            itemName: fields.itemName.value,
            category: fields.category.value,
            unit: fields.unit.value,
            reorderLevel: fields.reorderLevel.value,
            unitCost: fields.unitCost.value,
            sellingPrice: fields.sellingPrice.value,
            supplier: fields.supplier.value,
            location: fields.location.value,
            description: fields.description.value
        };
        if (!editId) payload.quantity = fields.quantity.value;

        const originalText = saveButton.textContent;
        saving = true;
        saveButton.disabled = true;
        saveButton.textContent = editId ? "Updating..." : "Saving...";
        try {
            const savedItem = editId
                ? await window.InventoryData.updateItem(editId, payload)
                : await window.InventoryData.createItem(payload);

            if (editId) {
                originalItem = savedItem;
                fill(savedItem);
                successText.textContent = savedItem.itemName + " was updated successfully.";
            } else {
                successText.textContent = savedItem.itemName + " was added successfully. You can now view or adjust its stock.";
                form.reset();
            }
            successNotice.classList.add("show");
            successNotice.scrollIntoView({behavior:"smooth", block:"center"});
        } catch (error) {
            errorNotice.textContent = error.message || (editId ? "The inventory item could not be updated." : "The inventory item could not be saved.");
            errorNotice.classList.add("show");
            errorNotice.scrollIntoView({behavior:"smooth", block:"center"});
        } finally {
            saving = false;
            saveButton.disabled = false;
            saveButton.textContent = originalText;
        }
    });

    async function init() {
        if (!editId) {
            try {
                const defaults = await window.InventoryData.defaults();
                newDefaults(defaults.reorderLevel);
            } catch (error) {
                errorNotice.textContent = error.message || "Inventory defaults could not be loaded.";
                errorNotice.classList.add("show");
                form.querySelectorAll("input,select,textarea,button").forEach(control => {
                    if (control.type !== "button") control.disabled = true;
                });
            }
            return;
        }
        try {
            originalItem = await window.InventoryData.getItem(editId);
            pageTitle.textContent = "Edit Inventory Item";
            saveButton.textContent = "Update Inventory Item";
            if (resetButton) resetButton.textContent = "Reset Changes";
            fields.quantity.disabled = true;
            if (quantityHelp) quantityHelp.hidden = false;
            fill(originalItem);
        } catch (error) {
            errorNotice.textContent = error.message || "The inventory item could not be loaded.";
            errorNotice.classList.add("show");
            form.querySelectorAll("input,select,textarea,button").forEach(control => {
                if (control.type !== "button") control.disabled = true;
            });
        }
    }

    init();
}());
