<?php
require __DIR__ . '/../../../api/common.php';

requirePermission($conn, 'quotations.view');

$file = (string)($_GET['file'] ?? '');
if (!preg_match('/^drawing_[0-9]{8}_[0-9]{6}_[a-f0-9]{12}\.(jpg|png|webp)$/i', $file)) {
    sendError('Quotation drawing not found.', 404);
}

$storedPath = '../uploads/quotation_drawings/' . $file;
$linked = one(
    $conn,
    "SELECT qi.item_id
        FROM quotation_items qi
        JOIN quotations q ON q.quotation_id=qi.quotation_id
        WHERE q.deleted_at IS NULL
          AND (qi.drawing_image=? OR qi.drawing_images LIKE ? ESCAPE '!')
        LIMIT 1",
    'ss',
    [$storedPath, '%"' . strtr($storedPath, ['!' => '!!', '%' => '!%', '_' => '!_']) . '"%']
);
if (!$linked) {
    sendError('Quotation drawing not found.', 404);
}

$path = dirname(__DIR__) . '/uploads/quotation_drawings/' . $file;
if (!is_file($path) || !is_readable($path)) {
    sendError('Quotation drawing is unavailable.', 404);
}

$mimeByExtension = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];
$extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
$mime = $mimeByExtension[$extension] ?? '';
$image = @getimagesize($path);
if (!$mime || !$image || ($image['mime'] ?? '') !== $mime) {
    error_log('Stored quotation drawing failed image validation: ' . $file);
    sendError('Quotation drawing is unavailable.', 404);
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . (string)filesize($path));
header('Content-Disposition: inline; filename="' . $file . '"');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
