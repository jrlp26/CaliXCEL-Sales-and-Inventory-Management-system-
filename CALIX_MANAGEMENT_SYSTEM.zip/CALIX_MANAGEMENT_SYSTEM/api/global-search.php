<?php
require_once __DIR__ . '/common.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') sendError('Global search only supports GET requests.', 405);

$user = currentUser($conn);
$permissions = userPermissions($conn, (string)$user['role']);
$allowed = static fn(string $permission): bool =>
    $user['role'] === 'ADMIN' || in_array($permission, $permissions, true);

$query = trim((string)($_GET['q'] ?? ''));
if (mb_strlen($query) > 100) sendError('Search text must be 100 characters or fewer.', 422);
if (mb_strlen($query) < 2) sendJson([]);

$escaped = str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $query);
$like = '%' . $escaped . '%';
$results = [];
$limit = 5;

$append = static function (array $rows, string $type, string $url) use (&$results): void {
    foreach ($rows as $row) {
        $results[] = [
            'type' => $type,
            'label' => (string)$row['label'],
            'detail' => (string)$row['detail'],
            'url' => $url
        ];
    }
};

if ($allowed('customers.lookup')) {
    $append(allRows($conn, "SELECT customer_name label,
        CONCAT_WS(' · ',NULLIF(company_name,''),NULLIF(contact_number,''),NULLIF(email,'')) detail
        FROM customers
        WHERE deleted_at IS NULL AND (customer_name LIKE ? ESCAPE '!' OR company_name LIKE ? ESCAPE '!'
            OR contact_number LIKE ? ESCAPE '!' OR email LIKE ? ESCAPE '!')
        ORDER BY customer_name LIMIT $limit", 'ssss', [$like, $like, $like, $like]), 'Customer', 'Modules/Customers/HTML/Customers.html');
}

if ($allowed('quotations.view') && $allowed('projects.view')) {
    $append(allRows($conn, "SELECT q.quotation_number label,
        CONCAT_WS(' · ',c.customer_name,q.status,DATE_FORMAT(q.quotation_date,'%Y-%m-%d')) detail
        FROM quotations q JOIN customers c ON c.customer_id=q.customer_id
        WHERE q.deleted_at IS NULL AND (q.quotation_number LIKE ? ESCAPE '!' OR c.customer_name LIKE ? ESCAPE '!'
            OR q.status LIKE ? ESCAPE '!')
        ORDER BY q.quotation_date DESC,q.quotation_id DESC LIMIT $limit", 'sss', [$like, $like, $like]), 'Quotation', 'Modules/Quotation/HTML/Projects.html');

    $append(allRows($conn, "SELECT p.project_name label,
        CONCAT_WS(' · ',c.customer_name,p.status,q.quotation_number) detail
        FROM projects p JOIN customers c ON c.customer_id=p.customer_id
        LEFT JOIN quotations q ON q.quotation_id=p.quotation_id
        WHERE p.deleted_at IS NULL AND (p.project_name LIKE ? ESCAPE '!' OR c.customer_name LIKE ? ESCAPE '!'
            OR p.status LIKE ? ESCAPE '!' OR q.quotation_number LIKE ? ESCAPE '!')
        ORDER BY p.project_id DESC LIMIT $limit", 'ssss', [$like, $like, $like, $like]), 'Project', 'Modules/Quotation/HTML/Projects.html');
}

if ($allowed('inventory.view')) {
    $append(allRows($conn, "SELECT material_name label,
        CONCAT_WS(' · ',NULLIF(item_code,''),NULLIF(category,''),CONCAT('Stock: ',quantity,' ',unit)) detail
        FROM inventory
        WHERE deleted_at IS NULL AND (material_name LIKE ? ESCAPE '!' OR item_code LIKE ? ESCAPE '!'
            OR category LIKE ? ESCAPE '!')
        ORDER BY material_name LIMIT $limit", 'sss', [$like, $like, $like]), 'Inventory', 'Modules/Inventory/HTML/ViewInventory.html');
}

if ($allowed('sales.view')) {
    $append(allRows($conn, "SELECT COALESCE(p.project_name,c.customer_name) label,
        CONCAT_WS(' · ',c.customer_name,q.quotation_number,DATE_FORMAT(s.sale_date,'%Y-%m-%d')) detail
        FROM sales s JOIN customers c ON c.customer_id=s.customer_id
        LEFT JOIN projects p ON p.project_id=s.project_id
        LEFT JOIN quotations q ON q.quotation_id=s.quotation_id
        WHERE s.deleted_at IS NULL AND (c.customer_name LIKE ? ESCAPE '!' OR p.project_name LIKE ? ESCAPE '!'
            OR q.quotation_number LIKE ? ESCAPE '!')
        ORDER BY s.sale_date DESC,s.sales_id DESC LIMIT $limit", 'sss', [$like, $like, $like]), 'Sale', 'Modules/Sales/HTML/ViewSales.html');
}

if ($allowed('billing.view')) {
    $activeBillings = activeRecordClause($conn, 'project_billings', 'b');
    $activeProjects = activeRecordClause($conn, 'projects', 'p');
    $activeCustomers = activeRecordClause($conn, 'customers', 'c');
    $append(allRows($conn, "SELECT COALESCE(NULLIF(b.invoice_number,''),b.description) label,
        CONCAT_WS(' · ',c.customer_name,p.project_name,q.quotation_number) detail
        FROM project_billings b JOIN projects p ON p.project_id=b.project_id
        JOIN customers c ON c.customer_id=p.customer_id
        LEFT JOIN quotations q ON q.quotation_id=p.quotation_id
        WHERE $activeBillings AND $activeProjects AND $activeCustomers AND (b.invoice_number LIKE ? ESCAPE '!'
            OR b.description LIKE ? ESCAPE '!' OR c.customer_name LIKE ? ESCAPE '!'
            OR p.project_name LIKE ? ESCAPE '!' OR q.quotation_number LIKE ? ESCAPE '!')
        ORDER BY b.billing_id DESC LIMIT $limit", 'sssss', [$like, $like, $like, $like, $like]), 'Invoice', 'Modules/Finance/HTML/Billing.html');
}

if ($allowed('payments.view')) {
    $activePayments = activeRecordClause($conn, 'project_billing_payments', 'pay');
    $activeBillings = activeRecordClause($conn, 'project_billings', 'b');
    $activeProjects = activeRecordClause($conn, 'projects', 'p');
    $activeCustomers = activeRecordClause($conn, 'customers', 'c');
    $append(allRows($conn, "SELECT CONCAT('PAY-',YEAR(pay.payment_date),'-',LPAD(pay.payment_id,6,'0')) label,
        CONCAT_WS(' · ',NULLIF(pay.reference_no,''),c.customer_name,b.invoice_number,p.project_name) detail
        FROM project_billing_payments pay JOIN project_billings b ON b.billing_id=pay.billing_id
        JOIN projects p ON p.project_id=b.project_id JOIN customers c ON c.customer_id=p.customer_id
        LEFT JOIN quotations q ON q.quotation_id=p.quotation_id
        WHERE $activePayments AND $activeBillings AND $activeProjects AND $activeCustomers
            AND (pay.reference_no LIKE ? ESCAPE '!' OR c.customer_name LIKE ? ESCAPE '!'
                OR b.invoice_number LIKE ? ESCAPE '!' OR p.project_name LIKE ? ESCAPE '!'
                OR q.quotation_number LIKE ? ESCAPE '!'
                OR CONCAT('PAY-',YEAR(pay.payment_date),'-',LPAD(pay.payment_id,6,'0')) LIKE ? ESCAPE '!')
        ORDER BY pay.payment_date DESC,pay.payment_id DESC LIMIT $limit", 'ssssss', [$like, $like, $like, $like, $like, $like]), 'Payment', 'Modules/Finance/HTML/Payments.html');
}

sendJson(array_slice($results, 0, 30));
