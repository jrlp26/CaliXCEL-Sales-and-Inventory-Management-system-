﻿<?php
require_once __DIR__ . '/../../../api/common.php';

function settingsOut($data, int $status = 200): void {
    http_response_code($status);
    if (array_key_exists('error', $data)) {
        $payload = ['success' => false, 'error' => (string)$data['error']];
        if (isset($data['details']) && is_array($data['details'])) $payload['details'] = $data['details'];
        $payload['code'] = apiErrorCode($status);
    } else {
        $payload = ['success' => true, 'data' => $data];
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function tableExistsSettings(mysqli $conn, string $name): bool {
    $r = one($conn, 'SELECT COUNT(*) c FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?', 's', [$name]);
    return (int)($r['c'] ?? 0) > 0;
}
function columnExistsSettings(mysqli $conn, string $table, string $column): bool {
    $r = one($conn, 'SELECT COUNT(*) c FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?', 'ss', [$table, $column]);
    return (int)($r['c'] ?? 0) > 0;
}
function activeRecordClauseSettings(mysqli $conn, string $table, string $alias = ''): string {
    return columnExistsSettings($conn, $table, 'deleted_at')
        ? ($alias !== '' ? $alias . '.' : '') . 'deleted_at IS NULL'
        : '1=1';
}
function passwordMatchesSettings(string $candidate, string $stored): bool {
    $info = password_get_info($stored);
    return !empty($info['algo']) ? password_verify($candidate, $stored) : hash_equals($stored, $candidate);
}
function verifyAdminPasswordSettings(mysqli $conn, array $admin, string $password): void {
    $row = one($conn, 'SELECT password FROM users WHERE user_id=?', 'i', [(int)$admin['user_id']]);
    $stored = (string)($row['password'] ?? '');
    if (!passwordMatchesSettings($password, $stored)) settingsOut(['error' => 'Incorrect administrator password.'], 401);
}
function normalizeRolePermissionsSettings(mysqli $conn, array $input): array {
    $valid = array_column(allRows($conn, 'SELECT permission_key FROM permissions'), 'permission_key');
    $perms = array_values(array_unique(array_intersect(array_map('strval', $input), $valid)));
    foreach (['dashboard.view', 'todo.manage'] as $always) {
        if (in_array($always, $valid, true)) $perms[] = $always;
    }
    $deps = [
        'inventory.manage' => ['inventory.view'],
        'projects.view' => ['quotations.view'],
        'projects.manage' => ['projects.view', 'quotations.view'],
        'quotations.manage' => ['quotations.view', 'customers.lookup'],
        'sales.manage' => ['sales.view', 'customers.lookup'],
        'billing.manage' => ['billing.view', 'projects.view'],
        'payments.view' => ['billing.view'],
        'payments.manage' => ['payments.view', 'billing.view'],
        'tasks.manage' => ['tasks.view'],
        'tasks.configure' => ['tasks.view', 'tasks.manage'],
        'customers.manage' => ['customers.lookup'],
        'reports.financial' => ['reports.operational'],
        'settings.manage' => ['users.manage'],
        'users.manage' => ['settings.manage']
    ];
    do {
        $before = count($perms);
        foreach ($deps as $key => $adds) {
            if (in_array($key, $perms, true)) {
                foreach ($adds as $add) $perms[] = $add;
            }
        }
        $perms = array_values(array_unique($perms));
    } while (count($perms) > $before);
    return $perms;
}
function activeCountSettings(mysqli $conn, string $sql, string $types = '', array $params = []): int {
    $r = one($conn, $sql, $types, $params);
    return (int)($r['c'] ?? 0);
}
function lockActiveAdminsSettings(mysqli $conn): int {
    $result = $conn->query("SELECT user_id FROM users WHERE role='ADMIN' AND is_active=1 AND deleted_at IS NULL ORDER BY user_id FOR UPDATE");
    $count = $result->num_rows;
    $result->free();
    return $count;
}
function recomputePaymentTotalsSettings(mysqli $conn, int $billingId): void {
    $invoice = one($conn, 'SELECT billing_id,project_id,amount,status FROM project_billings WHERE billing_id=? FOR UPDATE', 'i', [$billingId]);
    if (!$invoice) throw new RuntimeException('The linked invoice could not be found.');
    $activePayments = activeRecordClauseSettings($conn, 'project_billing_payments');
    $paid = one($conn, "SELECT COALESCE(SUM(amount),0) collected FROM project_billing_payments WHERE billing_id=? AND $activePayments", 'i', [$billingId]);
    $invoiceStatus = $invoice['status'] === 'PLANNED'
        ? 'PLANNED'
        : ((float)$paid['collected'] + 0.005 >= (float)$invoice['amount'] ? 'PAID' : 'INVOICED');
    $updateInvoice = $conn->prepare('UPDATE project_billings SET status=? WHERE billing_id=?');
    $updateInvoice->bind_param('si', $invoiceStatus, $billingId);
    $updateInvoice->execute();
    $updateInvoice->close();

    $sale = one($conn, 'SELECT sales_id,total_amount,amount_paid,billing_paid_total FROM sales WHERE project_id=? AND deleted_at IS NULL FOR UPDATE', 'i', [(int)$invoice['project_id']]);
    if (!$sale) throw new RuntimeException('Restore the linked project sales record before changing its payments.');
    $activeBillings = activeRecordClauseSettings($conn, 'project_billings', 'b');
    $activePaymentRows = activeRecordClauseSettings($conn, 'project_billing_payments', 'pay');
    $projectPaid = one($conn, "SELECT COALESCE(SUM(pay.amount),0) collected FROM project_billings b JOIN project_billing_payments pay ON pay.billing_id=b.billing_id WHERE b.project_id=? AND $activeBillings AND $activePaymentRows", 'i', [(int)$invoice['project_id']]);
    $billingPaid = (float)$projectPaid['collected'];
    $openingPaid = max(0, (float)$sale['amount_paid'] - (float)$sale['billing_paid_total']);
    $collected = $openingPaid + $billingPaid;
    if ($collected > (float)$sale['total_amount'] + 0.005) throw new RuntimeException('The payment change would exceed the project contract amount.');
    $status = $collected + 0.005 >= (float)$sale['total_amount'] ? 'PAID' : ($collected > 0 ? 'PARTIAL' : 'UNPAID');
    $updateSale = $conn->prepare('UPDATE sales SET amount_paid=?,billing_paid_total=?,payment_status=? WHERE sales_id=?');
    $updateSale->bind_param('ddsi', $collected, $billingPaid, $status, $sale['sales_id']);
    $updateSale->execute();
    $updateSale->close();
}
function deletionDependencyMessage(mysqli $conn, string $module, int $id): string {
    if ($module === 'users') {
        $target = one($conn, 'SELECT role,is_active FROM users WHERE user_id=? AND deleted_at IS NULL', 'i', [$id]);
        if (!$target) return 'User account not found or already deleted.';
        if ($target['role'] === 'ADMIN' && (int)$target['is_active'] === 1
            && activeCountSettings($conn, "SELECT COUNT(*) c FROM users WHERE role='ADMIN' AND is_active=1 AND deleted_at IS NULL") <= 1) {
            return 'The last active administrator account cannot be deleted.';
        }
    }
    if ($module === 'customers') {
        $q = activeCountSettings($conn, 'SELECT COUNT(*) c FROM quotations WHERE customer_id=? AND deleted_at IS NULL', 'i', [$id]);
        $p = activeCountSettings($conn, 'SELECT COUNT(*) c FROM projects WHERE customer_id=? AND deleted_at IS NULL', 'i', [$id]);
        $s = activeCountSettings($conn, 'SELECT COUNT(*) c FROM sales WHERE customer_id=? AND deleted_at IS NULL', 'i', [$id]);
        if ($q || $p || $s) return "This customer still has active records ($q quotation(s), $p project(s), $s sale(s)). Delete or reassign those records first.";
    }
    if ($module === 'quotations') {
        $p = activeCountSettings($conn, 'SELECT COUNT(*) c FROM projects WHERE quotation_id=? AND deleted_at IS NULL', 'i', [$id]);
        $s = activeCountSettings($conn, 'SELECT COUNT(*) c FROM sales WHERE quotation_id=? AND deleted_at IS NULL', 'i', [$id]);
        if ($p || $s) return "This quotation is still linked to $p active project(s) and $s active sale(s). Delete those dependent records first.";
    }
    if ($module === 'projects') {
        $s = activeCountSettings($conn, 'SELECT COUNT(*) c FROM sales WHERE project_id=? AND deleted_at IS NULL', 'i', [$id]);
        $b = tableExistsSettings($conn, 'project_billings')
            ? activeCountSettings($conn, 'SELECT COUNT(*) c FROM project_billings WHERE project_id=? AND ' . activeRecordClauseSettings($conn, 'project_billings'), 'i', [$id])
            : 0;
        $t = columnExistsSettings($conn, 'inventory_transactions', 'project_id')
            ? activeCountSettings($conn, 'SELECT COUNT(*) c FROM inventory_transactions WHERE project_id=?', 'i', [$id])
            : 0;
        if ($s || $b || $t) return "This project still has $s active sale(s), $b active invoice(s), and $t inventory transaction(s). Delete or reassign the dependent records first.";
    }
    if ($module === 'sales' && tableExistsSettings($conn, 'project_billings')) {
        $projectId = (int)(one($conn, 'SELECT project_id FROM sales WHERE sales_id=?', 'i', [$id])['project_id'] ?? 0);
        if ($projectId > 0) {
            $b = activeCountSettings($conn, 'SELECT COUNT(*) c FROM project_billings WHERE project_id=? AND ' . activeRecordClauseSettings($conn, 'project_billings'), 'i', [$projectId]);
            if ($b) return "This sale still supports $b active invoice(s). Delete eligible invoices first.";
        }
    }
    if ($module === 'billing') {
        $invoice = one($conn, 'SELECT status FROM project_billings WHERE billing_id=? AND ' . activeRecordClauseSettings($conn, 'project_billings'), 'i', [$id]);
        if (!$invoice) return 'Invoice not found or already deleted.';
        if ($invoice['status'] !== 'PLANNED') return 'Only draft invoices can be deleted. Issued invoices must remain for financial audit history.';
        $p = activeCountSettings($conn, 'SELECT COUNT(*) c FROM project_billing_payments WHERE billing_id=? AND ' . activeRecordClauseSettings($conn, 'project_billing_payments'), 'i', [$id]);
        if ($p) return 'An invoice with recorded payments cannot be deleted.';
    }
    if ($module === 'inventory') {
        $item = one($conn, 'SELECT quantity FROM inventory WHERE material_id=? AND deleted_at IS NULL', 'i', [$id]);
        if (!$item) return 'Inventory item not found or already deleted.';
        if (abs((float)$item['quantity']) > 0.0001) return 'Inventory with remaining stock cannot be deleted. Record an authorized stock adjustment to bring the quantity to zero first.';
    }
    return '';
}
function permanentDeletionDependencyMessage(mysqli $conn, string $module, int $id): string {
    $checks = [
        'customers' => [
            ['quotations', 'customer_id', 'quotation(s)'],
            ['projects', 'customer_id', 'project(s)'],
            ['sales', 'customer_id', 'sale(s)']
        ],
        'quotations' => [
            ['projects', 'quotation_id', 'project(s)'],
            ['sales', 'quotation_id', 'sale(s)']
        ],
        'projects' => [
            ['sales', 'project_id', 'sale(s)'],
            ['project_billings', 'project_id', 'invoice(s)'],
            ['inventory_transactions', 'project_id', 'inventory transaction(s)']
        ],
        'inventory' => [
            ['inventory_transactions', 'material_id', 'inventory transaction(s)']
        ],
        'billing' => [
            ['project_billing_payments', 'billing_id', 'payment(s)']
        ],
        'users' => [
            ['user_todos', 'user_id', 'task(s)'],
            ['todo_notes', 'user_id', 'task or note(s)'],
            ['inventory_transactions', 'user_id', 'inventory transaction(s)'],
            ['system_audit_log', 'user_id', 'audit log record(s)']
        ]
    ][$module] ?? [];
    $linked = [];
    foreach ($checks as [$table, $column, $label]) {
        if (!tableExistsSettings($conn, $table) || !columnExistsSettings($conn, $table, $column)) continue;
        $count = activeCountSettings($conn, "SELECT COUNT(*) c FROM `$table` WHERE `$column`=?", 'i', [$id]);
        if ($count > 0) $linked[] = "$count linked $label";
    }
    return $linked
        ? 'This record still has ' . implode(', ', $linked) . '. Keep it in deletion history or remove/reassign the related records first.'
        : '';
}
function canRestoreSettings(mysqli $conn, string $module, array $target): string {
    if ($module === 'users' && !one($conn, 'SELECT role_key FROM roles WHERE role_key=?', 's', [(string)$target['role']])) return 'Restore the assigned role first.';
    if ($module === 'billing') {
        $pid = (int)($target['project_id'] ?? 0);
        if ($pid && !one($conn, 'SELECT project_id FROM projects WHERE project_id=? AND deleted_at IS NULL', 'i', [$pid])) return 'Restore the linked project first.';
    }
    if ($module === 'payments') {
        $billingId = (int)($target['billing_id'] ?? 0);
        if ($billingId && !one($conn, 'SELECT billing_id FROM project_billings WHERE billing_id=? AND ' . activeRecordClauseSettings($conn, 'project_billings'), 'i', [$billingId])) return 'Restore the linked invoice first.';
        $sales = one($conn, 'SELECT s.sales_id FROM sales s JOIN project_billings b ON b.project_id=s.project_id WHERE b.billing_id=? AND s.deleted_at IS NULL LIMIT 1', 'i', [$billingId]);
        if (!$sales) return 'Restore the linked project sales record first.';
    }
    if ($module === 'quotations') {
        $cid = (int)($target['customer_id'] ?? 0);
        if ($cid && !one($conn, 'SELECT customer_id FROM customers WHERE customer_id=? AND deleted_at IS NULL', 'i', [$cid])) return 'Restore the linked customer first.';
    }
    if ($module === 'projects') {
        $cid = (int)($target['customer_id'] ?? 0);
        $qid = (int)($target['quotation_id'] ?? 0);
        if ($cid && !one($conn, 'SELECT customer_id FROM customers WHERE customer_id=? AND deleted_at IS NULL', 'i', [$cid])) return 'Restore the linked customer first.';
        if ($qid && !one($conn, 'SELECT quotation_id FROM quotations WHERE quotation_id=? AND deleted_at IS NULL', 'i', [$qid])) return 'Restore the linked quotation first.';
    }
    if ($module === 'sales') {
        $cid = (int)($target['customer_id'] ?? 0);
        $qid = (int)($target['quotation_id'] ?? 0);
        $pid = (int)($target['project_id'] ?? 0);
        if ($cid && !one($conn, 'SELECT customer_id FROM customers WHERE customer_id=? AND deleted_at IS NULL', 'i', [$cid])) return 'Restore the linked customer first.';
        if ($qid && !one($conn, 'SELECT quotation_id FROM quotations WHERE quotation_id=? AND deleted_at IS NULL', 'i', [$qid])) return 'Restore the linked quotation first.';
        if ($pid && !one($conn, 'SELECT project_id FROM projects WHERE project_id=? AND deleted_at IS NULL', 'i', [$pid])) return 'Restore the linked project first.';
        if ($pid && one($conn, 'SELECT sales_id FROM sales WHERE project_id=? AND sales_id<>? AND deleted_at IS NULL LIMIT 1', 'ii', [$pid, (int)$target['sales_id']])) return 'Another active sale is already linked to this project.';
        if ($qid && one($conn, 'SELECT sales_id FROM sales WHERE quotation_id=? AND sales_id<>? AND deleted_at IS NULL LIMIT 1', 'ii', [$qid, (int)$target['sales_id']])) return 'Another active sale is already linked to this quotation.';
    }
    if ($module === 'customers') {
        $conflicts = [
            ['quotations', 'quotation_id', 'quotation_number', 'quotation'],
            ['projects', 'project_id', 'project_name', 'project'],
            ['sales', 'sales_id', null, 'sale']
        ];
        foreach ($conflicts as [$table, $idColumn, $labelColumn, $label]) {
            $query = "SELECT `$idColumn` record_id" . ($labelColumn ? ",`$labelColumn` record_label" : '') .
                " FROM `$table` WHERE customer_id=? AND deleted_at IS NULL LIMIT 1";
            $conflict = one($conn, $query, 'i', [(int)$target['customer_id']]);
            if ($conflict) {
                $record = $labelColumn ? (string)($conflict['record_label'] ?? '') : '#' . (int)$conflict['record_id'];
                return "This customer cannot be restored while an active $label ($record) is linked to it. Delete or reassign that record first.";
            }
        }
    }
    return '';
}
function deletionRecordsSettings(mysqli $conn): array {
    $defs = [
        'quotations' => ['quotations', 'quotation_id', "COALESCE(NULLIF(quotation_number,''),CONCAT('Quotation #',quotation_id))", "COALESCE(NULLIF(project_name,''),'Quotation record')"],
        'projects' => ['projects', 'project_id', "COALESCE(NULLIF(project_name,''),CONCAT('Project #',project_id))", "CONCAT('Status: ',COALESCE(status,'—'))"],
        'inventory' => ['inventory', 'material_id', "COALESCE(NULLIF(material_name,''),CONCAT('Inventory #',material_id))", "CONCAT(COALESCE(item_code,''),' · Qty: ',COALESCE(quantity,0),' ',COALESCE(unit,''))"],
        'customers' => ['customers', 'customer_id', "COALESCE(NULLIF(customer_name,''),CONCAT('Customer #',customer_id))", "COALESCE(NULLIF(company_name,''),NULLIF(contact_number,''),'Customer record')"],
        'sales' => ['sales', 'sales_id', "CONCAT('Sale #',sales_id)", "CONCAT('Amount: ',COALESCE(total_amount,0),' · ',COALESCE(payment_status,''))"],
        'billing' => ['project_billings', 'billing_id', "COALESCE(NULLIF(invoice_number,''),CONCAT('Invoice #',billing_id))", "CONCAT(COALESCE(description,''),' · ',COALESCE(status,''))"],
        'payments' => ['project_billing_payments', 'payment_id', "CONCAT('Payment #',payment_id)", "CONCAT('Amount: ',COALESCE(amount,0),' · ',COALESCE(payment_date,''))"],
        'todo_notes' => ['todo_notes', 'todo_id', "COALESCE(NULLIF(title,''),CONCAT('Task or note #',todo_id))", "CONCAT(IF(record_type='NOTE','Note','Task'),' · ',IF(visibility='TEAM','Shared','Personal'),' · ',COALESCE(priority,''))"]
    ];
    $out = [];
    foreach ($defs as $module => $def) {
        [$table, $idCol, $label, $details] = $def;
        if (!tableExistsSettings($conn, $table) || !columnExistsSettings($conn, $table, $idCol) || !columnExistsSettings($conn, $table, 'deleted_at')) continue;
        $result = $conn->query("SELECT '$module' module, `$idCol` record_id, $label record_label, $details details FROM `$table` WHERE deleted_at IS NULL ORDER BY `$idCol` DESC LIMIT 200");
        while ($row = $result->fetch_assoc()) $out[] = $row;
    }
    if (tableExistsSettings($conn, 'users')) {
        $where = columnExistsSettings($conn, 'users', 'deleted_at') ? ' WHERE deleted_at IS NULL' : '';
        $result = $conn->query("SELECT 'users' module,user_id record_id,username record_label,CONCAT('Role: ',role,IF(COALESCE(is_active,1)=1,' · Active',' · Inactive')) details FROM users$where ORDER BY user_id DESC LIMIT 200");
        while ($row = $result->fetch_assoc()) $out[] = $row;
    }
    return $out;
}

foreach (['roles', 'permissions', 'role_permissions', 'system_settings', 'business_settings'] as $table) {
    if (!tableExistsSettings($conn, $table)) settingsOut(['error' => 'Settings database upgrade is required. Back up the database, then import Database/calix_existing_database_upgrade.sql in phpMyAdmin.'], 503);
}
$me = requirePermission($conn, 'settings.manage');
$action = $_GET['action'] ?? 'overview';
$method = $_SERVER['REQUEST_METHOD'];

if ($action === 'overview' && $method === 'GET') {
    $canManageUsers = $me['role'] === 'ADMIN' || in_array('users.manage', $me['permissions'], true);
    $userWhere = columnExistsSettings($conn, 'users', 'deleted_at') ? ' WHERE deleted_at IS NULL' : '';
    $users = $canManageUsers
        ? allRows($conn, "SELECT user_id,username," . (columnExistsSettings($conn, 'users', 'full_name') ? 'full_name,' : "'' full_name,") . "role,COALESCE(is_active,1) is_active FROM users$userWhere ORDER BY username")
        : [];
    $roles = allRows($conn, 'SELECT role_key,role_name,is_system FROM roles ORDER BY role_name');
    foreach ($roles as &$role) {
        if ($role['role_key'] === 'ADMIN') {
            $role['permissions'] = allRows($conn, 'SELECT permission_key,permission_name,description FROM permissions ORDER BY permission_name');
        } else {
            $allowedClause = columnExistsSettings($conn, 'role_permissions', 'allowed') ? ' AND COALESCE(rp.allowed,1)=1' : '';
            $role['permissions'] = allRows($conn, "SELECT p.permission_key,p.permission_name,p.description FROM permissions p JOIN role_permissions rp ON rp.permission_key=p.permission_key WHERE rp.role_key=?$allowedClause ORDER BY p.permission_name", 's', [$role['role_key']]);
        }
    }
    unset($role);
    $permissions = allRows($conn, 'SELECT permission_key,permission_name,description FROM permissions ORDER BY permission_name');
    $history = [];
    $isAdmin = $me['role'] === 'ADMIN';
    $permanentDeleteAvailable = tableExistsSettings($conn, 'delete_history')
        && columnExistsSettings($conn, 'delete_history', 'permanently_deleted_at')
        && columnExistsSettings($conn, 'delete_history', 'permanently_deleted_by');
    if ($isAdmin && tableExistsSettings($conn, 'delete_history')) {
        $purgeFields = $permanentDeleteAvailable
            ? "h.permanently_deleted_by,h.permanently_deleted_at,COALESCE(pu.username,'') permanently_deleted_by_name"
            : "NULL permanently_deleted_by,NULL permanently_deleted_at,'' permanently_deleted_by_name";
        $purgeJoin = $permanentDeleteAvailable ? ' LEFT JOIN users pu ON pu.user_id=h.permanently_deleted_by' : '';
        $history = allRows($conn, "SELECT h.history_id,h.module,h.record_id,h.record_label,h.deleted_by,h.deleted_at,h.restored_by,h.restored_at,$purgeFields,COALESCE(u.username,CONCAT('User #',h.deleted_by)) deleted_by_name,COALESCE(ru.username,'') restored_by_name FROM delete_history h LEFT JOIN users u ON u.user_id=h.deleted_by LEFT JOIN users ru ON ru.user_id=h.restored_by$purgeJoin ORDER BY h.deleted_at DESC,h.history_id DESC LIMIT 300");
    }
    $businessSettings = [];
    foreach (allRows($conn, 'SELECT setting_key,setting_value FROM business_settings') as $setting) {
        $businessSettings[$setting['setting_key']] = $setting['setting_value'];
    }
    settingsOut(['users' => $users, 'roles' => $roles, 'permissions' => $permissions, 'history' => $history, 'deletable' => $isAdmin ? deletionRecordsSettings($conn) : [], 'businessSettings' => $businessSettings, 'currentUserId' => (int)$me['user_id'], 'permanentDeleteAvailable' => $permanentDeleteAvailable]);
}

if ($action === 'save_business' && $method === 'POST') {
    $user = requirePermission($conn, 'settings.manage');
    $data = body();
    $values = is_array($data['settings'] ?? null) ? $data['settings'] : array_intersect_key($data, ['default_vat_rate' => true]);
    $numericRanges = [
        'default_validity_days' => [1, 3650],
        'default_vat_rate' => [0, 100],
        'default_project_duration_days' => [0, 3650],
        'inventory_default_reorder_level' => [0, 99999999.99],
        'billing_default_due_days' => [0, 3650]
    ];
    $stringLimits = [
        'authorized_representative' => 150, 'authorized_representative_position' => 120,
        'default_payment_terms' => 2000, 'default_fabrication_terms' => 2000,
        'default_acceptance_statement' => 2000
    ];
    $allowedKeys = array_merge(array_keys($numericRanges), array_keys($stringLimits), [
        'default_vat_type', 'customer_duplicate_email', 'customer_duplicate_name_contact',
        'payment_methods', 'report_default_range_months'
    ]);
    if (!$values || array_diff(array_keys($values), $allowedKeys)) settingsOut(['error' => 'The submitted module settings are invalid.'], 422);
    $normalized = [];
    foreach ($values as $key => $value) {
        if (isset($numericRanges[$key])) {
            [$min, $max] = $numericRanges[$key];
            if (!is_numeric($value) || !is_finite((float)$value) || (float)$value < $min || (float)$value > $max) {
                settingsOut(['error' => "The value for $key is outside its allowed range."], 422);
            }
            $normalized[$key] = $key === 'default_vat_rate'
                ? number_format((float)$value, 2, '.', '')
                : (string)(int)$value;
        } elseif (isset($stringLimits[$key])) {
            $text = trim((string)$value);
            if (strlen($text) > $stringLimits[$key] || ($key === 'email' && $text !== '' && !filter_var($text, FILTER_VALIDATE_EMAIL))) {
                settingsOut(['error' => "The value for $key is invalid or too long."], 422);
            }
            $normalized[$key] = $text;
        } elseif ($key === 'default_vat_type') {
            $vatType = trim((string)$value);
            if (!in_array($vatType, ['VAT EXCLUSIVE', 'VAT INCLUSIVE', 'NON-VAT'], true)) settingsOut(['error' => 'Choose a valid default VAT treatment.'], 422);
            $normalized[$key] = $vatType;
        } elseif (in_array($key, ['customer_duplicate_email', 'customer_duplicate_name_contact'], true)) {
            $normalized[$key] = !empty($value) && $value !== '0' ? '1' : '0';
        } elseif ($key === 'payment_methods') {
            $methods = array_values(array_unique(array_filter(array_map('trim', preg_split('/\R/', (string)$value) ?: []), static fn($method) => $method !== '')));
            if (!$methods || count($methods) > 10) settingsOut(['error' => 'Enter between 1 and 10 payment methods.'], 422);
            foreach ($methods as $methodName) {
                if (strlen($methodName) > 40) settingsOut(['error' => 'Each payment method must be 40 characters or fewer.'], 422);
            }
            $normalized[$key] = implode("\n", $methods);
        } elseif ($key === 'report_default_range_months') {
            if (!in_array((string)$value, ['0', '1', '3', '6', '12', '24'], true)) settingsOut(['error' => 'Choose a valid default report range.'], 422);
            $normalized[$key] = (string)(int)$value;
        }
    }
    if (array_intersect(array_keys($normalized), ['customer_duplicate_email', 'customer_duplicate_name_contact'])) {
        $existingDuplicateSettings = [];
        foreach (allRows($conn, "SELECT setting_key,setting_value FROM business_settings WHERE setting_key IN ('customer_duplicate_email','customer_duplicate_name_contact')") as $setting) {
            $existingDuplicateSettings[$setting['setting_key']] = (string)$setting['setting_value'];
        }
        $emailCheck = $normalized['customer_duplicate_email'] ?? $existingDuplicateSettings['customer_duplicate_email'] ?? '1';
        $nameCheck = $normalized['customer_duplicate_name_contact'] ?? $existingDuplicateSettings['customer_duplicate_name_contact'] ?? '1';
        if ($emailCheck === '0' && $nameCheck === '0') {
            settingsOut(['error' => 'At least one customer duplicate check must remain enabled.'], 422);
        }
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare('INSERT INTO business_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
        foreach ($normalized as $key => $value) {
            $previous = one($conn, 'SELECT setting_value FROM business_settings WHERE setting_key=?', 's', [$key]);
            $stmt->bind_param('ss', $key, $value);
            $stmt->execute();
            auditEvent($conn, $user, 'updated', 'business_setting', 0, ['key' => $key, 'value' => $value], $previous['setting_value'] ?? null, $value);
        }
        $stmt->close();
        $conn->commit();
        settingsOut(['ok' => true, 'settings' => $normalized]);
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        error_log('Business settings update failed: ' . $e->getMessage());
        settingsOut(['error' => 'Business settings could not be saved.'], 500);
    }
}

if ($action === 'save_user' && $method === 'POST') {
    $user = requirePermission($conn, 'users.manage');
    $d = body();
    $id = (int)($d['user_id'] ?? 0);
    $username = trim((string)($d['username'] ?? ''));
    $fullName = trim((string)($d['full_name'] ?? ''));
    $role = trim((string)($d['role'] ?? ''));
    $password = (string)($d['password'] ?? '');
    $passwordConfirmation = (string)($d['password_confirmation'] ?? '');
    $active = !empty($d['is_active']) ? 1 : 0;

    if ($username === '' || $fullName === '' || $role === '') settingsOut(['error' => 'Full name, username, and role are required.'], 422);
    if (!preg_match('/^[A-Za-z0-9._-]{3,50}$/', $username)) settingsOut(['error' => 'Username must be 3–50 characters and use only letters, numbers, dot, dash, or underscore.'], 422);
    if (function_exists('mb_strlen') ? mb_strlen($fullName, 'UTF-8') > 120 : strlen($fullName) > 120) settingsOut(['error' => 'Full name must be 120 characters or fewer.'], 422);
    if (!one($conn, 'SELECT role_key FROM roles WHERE role_key=?', 's', [$role])) settingsOut(['error' => 'Selected role does not exist.'], 422);
    if ($role === 'ADMIN' && $me['role'] !== 'ADMIN') settingsOut(['error' => 'Only an administrator can assign the Administrator role.'], 403);
    $existing = one($conn, 'SELECT user_id FROM users WHERE LOWER(username)=LOWER(?) AND user_id<>?' . (columnExistsSettings($conn, 'users', 'deleted_at') ? ' AND deleted_at IS NULL' : ''), 'si', [$username, $id]);
    if ($existing) settingsOut(['error' => 'Username already exists.'], 409);
    if ($password !== '' && ($passwordConfirmation === '' || !hash_equals($password, $passwordConfirmation))) settingsOut(['error' => 'Passwords do not match. Enter the same password in both fields.'], 422);
    if ($id === (int)$me['user_id'] && !$active) settingsOut(['error' => 'You cannot deactivate the account you are currently using.'], 422);
    if ($id === (int)$me['user_id'] && $me['role'] === 'ADMIN' && $role !== 'ADMIN') settingsOut(['error' => 'You cannot remove Administrator access from the account you are currently using.'], 422);
    if ($password !== '' && strlen($password) < 8) settingsOut(['error' => 'Password must be at least 8 characters.'], 422);

    $created = $id <= 0;
    $previousRole = null;
    if ($id > 0) {
        $target = one($conn, 'SELECT user_id,role,is_active FROM users WHERE user_id=?' . (columnExistsSettings($conn, 'users', 'deleted_at') ? ' AND deleted_at IS NULL' : ''), 'i', [$id]);
        if (!$target) settingsOut(['error' => 'User account not found.'], 404);
        if ($target['role'] === 'ADMIN' && $me['role'] !== 'ADMIN') settingsOut(['error' => 'Only an administrator can modify an Administrator account.'], 403);
        if ($target['role'] === 'ADMIN' && (int)$target['is_active'] === 1 && ($role !== 'ADMIN' || !$active)
            && activeCountSettings($conn, "SELECT COUNT(*) c FROM users WHERE role='ADMIN' AND is_active=1 AND deleted_at IS NULL") <= 1) {
            settingsOut(['error' => 'The last active administrator must remain active with the Administrator role.'], 409);
        }
        $previousRole = (string)$target['role'];
        if ($password !== '') {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $s = $conn->prepare('UPDATE users SET username=?,full_name=?,password=?,role=?,is_active=? WHERE user_id=?');
            $s->bind_param('ssssii', $username, $fullName, $hash, $role, $active, $id);
        } else {
            $s = $conn->prepare('UPDATE users SET username=?,full_name=?,role=?,is_active=? WHERE user_id=?');
            $s->bind_param('sssii', $username, $fullName, $role, $active, $id);
        }
    } else {
        if (strlen($password) < 8) settingsOut(['error' => 'A password of at least 8 characters is required for a new user.'], 422);
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $s = $conn->prepare('INSERT INTO users(username,full_name,password,role,is_active) VALUES(?,?,?,?,?)');
        $s->bind_param('ssssi', $username, $fullName, $hash, $role, $active);
    }

    $conn->begin_transaction();
    $passwordLockAcquired = false;
    try {
        if ($id > 0 && $target['role'] === 'ADMIN' && (int)$target['is_active'] === 1 && ($role !== 'ADMIN' || !$active)) {
            if (lockActiveAdminsSettings($conn) <= 1) {
                throw new DomainException('The last active administrator must remain active with the Administrator role.', 409);
            }
        }
        if ($password !== '') {
            $lock = one($conn, "SELECT GET_LOCK('calix_user_password_uniqueness',10) acquired");
            if ((int)($lock['acquired'] ?? 0) !== 1) {
                throw new DomainException('The password uniqueness check is busy. Please retry in a moment.', 503);
            }
            $passwordLockAcquired = true;
            $otherUsers = $created
                ? allRows($conn, 'SELECT password FROM users')
                : allRows($conn, 'SELECT password FROM users WHERE user_id<>?', 'i', [$id]);
            foreach ($otherUsers as $otherUser) {
                if (passwordMatchesSettings($password, (string)$otherUser['password'])) {
                    throw new DomainException('Each user must have a unique password. Choose a password not used by another account.', 409);
                }
            }
        }
        $s->execute();
        if ($created) $id = (int)$s->insert_id;
        $s->close();
        auditEvent($conn, $user, $created ? 'created' : 'updated', 'user', $id, ['username' => $username, 'role' => $role, 'active' => (bool)$active], $previousRole, $role);
        $conn->commit();
        if ($passwordLockAcquired) one($conn, "SELECT RELEASE_LOCK('calix_user_password_uniqueness')");
        settingsOut(['ok' => true]);
    } catch (DomainException $e) {
        $conn->rollback();
        if ($passwordLockAcquired) one($conn, "SELECT RELEASE_LOCK('calix_user_password_uniqueness')");
        settingsOut(['error' => $e->getMessage()], $e->getCode() ?: 409);
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        if ($passwordLockAcquired) one($conn, "SELECT RELEASE_LOCK('calix_user_password_uniqueness')");
        error_log('User save failed: ' . $e->getMessage());
        if ((int)$e->getCode() === 1062) settingsOut(['error' => 'That username is already in use. Choose a different username.'], 409);
        settingsOut(['error' => 'The user account could not be saved because of a server error. Please retry or contact your administrator.'], 500);
    }
}

if ($action === 'save_role' && $method === 'POST') {
    requirePermission($conn, 'users.manage');
    $d = body();
    $original = trim((string)($d['original_key'] ?? ''));
    $code = strtoupper(trim(preg_replace('/[^A-Za-z0-9_]+/', '_', trim((string)($d['role_key'] ?? ''))), '_'));
    $name = trim((string)($d['role_name'] ?? ''));

    if ($name === '') settingsOut(['error' => 'Role name is required.'], 422);
    $perms = normalizeRolePermissionsSettings($conn, is_array($d['permissions'] ?? null) ? $d['permissions'] : []);
    $conn->begin_transaction();
    try {
        if ($original !== '') {
            $role = one($conn, 'SELECT role_key,is_system FROM roles WHERE role_key=?', 's', [$original]);
            if (!$role) throw new RuntimeException('Role not found.');
            if ($original === 'ADMIN') throw new RuntimeException('Administration permissions are fixed for safety.');
            if ((int)$role['is_system'] === 1) {
                $code = $original;
            } else {
                if ($code === '') $code = $original;
                if ($code !== $original && one($conn, 'SELECT role_key FROM roles WHERE role_key=?', 's', [$code])) throw new RuntimeException('Role code already exists.');
                if ($code !== $original) {
                    $r = $conn->prepare('INSERT INTO roles(role_key,role_name,is_system,date_created) SELECT ?,?,is_system,date_created FROM roles WHERE role_key=?');
                    $r->bind_param('sss', $code, $name, $original);
                    $r->execute();
                    if ($r->affected_rows !== 1) throw new RuntimeException('Role not found.');
                    $r->close();
                    $rp = $conn->prepare('UPDATE role_permissions SET role_key=? WHERE role_key=?');
                    $rp->bind_param('ss', $code, $original);
                    $rp->execute();
                    $rp->close();
                    $u = $conn->prepare('UPDATE users SET role=? WHERE role=?');
                    $u->bind_param('ss', $code, $original);
                    $u->execute();
                    $r = $conn->prepare('DELETE FROM roles WHERE role_key=?');
                    $r->bind_param('s', $original);
                    $r->execute();
                    $r->close();
                } else {
                    $r = $conn->prepare('UPDATE roles SET role_name=? WHERE role_key=?');
                    $r->bind_param('ss', $name, $original);
                    $r->execute();
                }
            }
            if ((int)$role['is_system'] === 1) {
                $r = $conn->prepare('UPDATE roles SET role_name=? WHERE role_key=?');
                $r->bind_param('ss', $name, $code);
                $r->execute();
            }
        } else {
            if ($code === '') $code = strtoupper(trim(preg_replace('/[^A-Za-z0-9]+/', '_', $name), '_'));
            if ($code === '' || one($conn, 'SELECT role_key FROM roles WHERE role_key=? OR role_name=?', 'ss', [$code, $name])) throw new RuntimeException('A role with that name or code already exists.');
            $r = $conn->prepare('INSERT INTO roles(role_key,role_name,is_system) VALUES(?,?,0)');
            $r->bind_param('ss', $code, $name);
            $r->execute();
        }
        $dstmt = $conn->prepare('DELETE FROM role_permissions WHERE role_key=?');
        $dstmt->bind_param('s', $code);
        $dstmt->execute();
        if ($perms) {
            if (columnExistsSettings($conn, 'role_permissions', 'allowed')) {
                $ins = $conn->prepare('INSERT INTO role_permissions(role_key,permission_key,allowed) VALUES(?,?,1)');
            } else {
                $ins = $conn->prepare('INSERT INTO role_permissions(role_key,permission_key) VALUES(?,?)');
            }
            foreach ($perms as $perm) {
                $ins->bind_param('ss', $code, $perm);
                $ins->execute();
            }
        }
        auditEvent($conn, $me, $original !== '' ? 'updated' : 'created', 'role', 0, ['role_key' => $code, 'role_name' => $name, 'permissions' => $perms]);
        $conn->commit();
        settingsOut(['ok' => true, 'role_key' => $code]);
    } catch (Throwable $e) {
        $conn->rollback();
        if ($e instanceof mysqli_sql_exception || !($e instanceof RuntimeException)) {
            error_log('Role save failed: ' . $e->getMessage());
            settingsOut(['error' => 'The role could not be saved. No partial changes were saved.'], 500);
        }
        settingsOut(['error' => $e->getMessage()], 422);
    }
}

if ($action === 'delete_role' && $method === 'POST') {
    $user = requirePermission($conn, 'users.manage');
    $code = trim((string)(body()['role_key'] ?? ''));
    $role = one($conn, 'SELECT is_system FROM roles WHERE role_key=?', 's', [$code]);
    if (!$role) settingsOut(['error' => 'Role not found.'], 404);
    if ((int)$role['is_system'] === 1) settingsOut(['error' => 'System roles cannot be deleted.'], 422);
    if (activeCountSettings($conn, 'SELECT COUNT(*) c FROM users WHERE role=?', 's', [$code]) > 0) settingsOut(['error' => 'Reassign or permanently remove users before deleting this role.'], 422);
    $conn->begin_transaction();
    try {
        $s = $conn->prepare('DELETE FROM role_permissions WHERE role_key=?');
        $s->bind_param('s', $code);
        $s->execute();
        $s = $conn->prepare('DELETE FROM roles WHERE role_key=?');
        $s->bind_param('s', $code);
        $s->execute();
        auditEvent($conn, $user, 'deleted', 'role', 0, ['role_key' => $code], 'ACTIVE', 'DELETED');
        $conn->commit();
        settingsOut(['ok' => true]);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Role deletion failed: ' . $e->getMessage());
        settingsOut(['error' => 'Role could not be deleted.'], 422);
    }
}

if ($action === 'delete_record' && $method === 'POST') {
    $d = body();
    $module = strtolower(trim((string)($d['module'] ?? '')));
    $id = (int)($d['record_id'] ?? 0);
    $password = (string)($d['password'] ?? '');

    if ($me['role'] !== 'ADMIN') settingsOut(['error' => 'Administrator authentication is required.'], 403);
    if ($id <= 0 || $password === '') settingsOut(['error' => 'Administrator password is required.'], 422);
    verifyAdminPasswordSettings($conn, $me, $password);
    $cfg = [
        'users' => ['users', 'user_id', 'username', true],
        'quotations' => ['quotations', 'quotation_id', 'quotation_number', true],
        'projects' => ['projects', 'project_id', 'project_name', true],
        'inventory' => ['inventory', 'material_id', 'material_name', true],
        'customers' => ['customers', 'customer_id', 'customer_name', true],
        'sales' => ['sales', 'sales_id', 'sales_id', true],
        'billing' => ['project_billings', 'billing_id', 'invoice_number', true],
        'payments' => ['project_billing_payments', 'payment_id', 'payment_id', true],
        'todo_notes' => ['todo_notes', 'todo_id', 'title', true]
    ];
    if (!isset($cfg[$module])) settingsOut(['error' => 'Unsupported deletion module.'], 422);
    [$table, $idCol, $labelCol, $soft] = $cfg[$module];
    if ($soft && (!columnExistsSettings($conn, $table, 'deleted_at') || !columnExistsSettings($conn, $table, 'deleted_by'))) {
        settingsOut(['error' => 'Recoverable deletion is not configured for this record type. Back up the database, then apply Database/calix_existing_database_upgrade.sql.'], 503);
    }
    if ($module === 'users' && $id === (int)$me['user_id']) settingsOut(['error' => 'You cannot delete the account you are currently signed in with.'], 422);
    $conn->begin_transaction();
    try {
        if ($module === 'users') lockActiveAdminsSettings($conn);
        $target = one($conn, "SELECT * FROM `$table` WHERE `$idCol`=?" . ($soft ? ' AND deleted_at IS NULL' : '') . ' FOR UPDATE', 'i', [$id]);
        if (!$target) throw new DomainException('Record not found or already deleted.', 404);
        $dependency = deletionDependencyMessage($conn, $module, $id);
        if ($dependency !== '') throw new DomainException($dependency, 409);
        $label = in_array($module, ['sales', 'payments'], true)
            ? ucfirst($module === 'payments' ? 'payment' : 'sale') . ' #' . $id
            : (string)($target[$labelCol] ?? ucfirst($module) . ' #' . $id);
        $snapshot = $target;
        unset($snapshot['password']);
        $snapshotJson = json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $uid = (int)$me['user_id'];
        $h = $conn->prepare('INSERT INTO delete_history(module,record_id,record_label,snapshot_json,deleted_by) VALUES(?,?,?,?,?)');
        $h->bind_param('sissi', $module, $id, $label, $snapshotJson, $uid);
        $h->execute();
        if ($soft) {
            $x = $conn->prepare("UPDATE `$table` SET deleted_at=CURRENT_TIMESTAMP,deleted_by=? WHERE `$idCol`=? AND deleted_at IS NULL");
            $x->bind_param('ii', $uid, $id);
            $x->execute();
            if ($x->affected_rows < 1) throw new RuntimeException('Unable to delete record.');
            if ($module === 'payments') recomputePaymentTotalsSettings($conn, (int)$target['billing_id']);
        } else {
            $x = $conn->prepare("DELETE FROM `$table` WHERE `$idCol`=?");
            $x->bind_param('i', $id);
            $x->execute();
            if ($x->affected_rows < 1) throw new RuntimeException('Unable to delete account.');
        }
        auditEvent($conn, $me, 'deleted', $module, $id, ['record_label' => $label], 'ACTIVE', 'DELETED');
        $conn->commit();
        settingsOut(['ok' => true, 'recoverable' => $soft]);
    } catch (DomainException $e) {
        $conn->rollback();
        settingsOut(['error' => $e->getMessage()], $e->getCode() ?: 409);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Record deletion failed: ' . $e->getMessage());
        settingsOut(['error' => $module === 'users' ? 'The account could not be moved to the Trashbin. No changes were saved.' : 'The record could not be deleted. No changes were saved.'], 422);
    }
}

if ($action === 'restore_record' && $method === 'POST') {
    $d = body();
    $historyId = (int)($d['history_id'] ?? 0);
    $password = (string)($d['password'] ?? '');

    if ($me['role'] !== 'ADMIN') settingsOut(['error' => 'Administrator authentication is required.'], 403);
    if ($historyId <= 0 || $password === '') settingsOut(['error' => 'Administrator password is required.'], 422);
    verifyAdminPasswordSettings($conn, $me, $password);
    $history = one($conn, 'SELECT * FROM delete_history WHERE history_id=? AND restored_at IS NULL' . (columnExistsSettings($conn, 'delete_history', 'permanently_deleted_at') ? ' AND permanently_deleted_at IS NULL' : '') . ' ORDER BY history_id DESC LIMIT 1', 'i', [$historyId]);
    if (!$history) settingsOut(['error' => 'Deletion history record is not available for restore.'], 404);
    $cfg = [
        'quotations' => ['quotations', 'quotation_id'],
        'projects' => ['projects', 'project_id'],
        'inventory' => ['inventory', 'material_id'],
        'customers' => ['customers', 'customer_id'],
        'sales' => ['sales', 'sales_id'],
        'billing' => ['project_billings', 'billing_id'],
        'payments' => ['project_billing_payments', 'payment_id'],
        'users' => ['users', 'user_id'],
        'todo_notes' => ['todo_notes', 'todo_id']
    ];
    $module = (string)$history['module'];
    if (!isset($cfg[$module])) settingsOut(['error' => 'This deletion is permanent and cannot be restored.'], 422);
    [$table, $idCol] = $cfg[$module];
    if (!columnExistsSettings($conn, $table, 'deleted_at') || !columnExistsSettings($conn, $table, 'deleted_by')) {
        settingsOut(['error' => 'Recoverable deletion is not configured for this record type. Back up the database, then apply Database/calix_existing_database_upgrade.sql.'], 503);
    }
    $id = (int)$history['record_id'];
    $target = one($conn, "SELECT * FROM `$table` WHERE `$idCol`=? AND deleted_at IS NOT NULL", 'i', [$id]);
    if (!$target) settingsOut(['error' => 'The deleted record no longer exists or has already been restored.'], 404);
    $dependency = canRestoreSettings($conn, $module, $target);
    if ($dependency !== '') settingsOut(['error' => $dependency], 409);
    $otherDeletion = one($conn, 'SELECT history_id FROM delete_history WHERE module=? AND record_id=? AND restored_at IS NULL AND history_id<>? ORDER BY history_id DESC LIMIT 1', 'sii', [$module, $id, $historyId]);
    if ($otherDeletion) settingsOut(['error' => 'Another active deletion record exists for this item. Restore that history entry instead.'], 409);
    $conn->begin_transaction();
    try {
        $x = $conn->prepare("UPDATE `$table` SET deleted_at=NULL,deleted_by=NULL WHERE `$idCol`=?");
        $x->bind_param('i', $id);
        $x->execute();
        if ($module === 'payments') recomputePaymentTotalsSettings($conn, (int)$target['billing_id']);
        $uid = (int)$me['user_id'];
        $h = $conn->prepare('UPDATE delete_history SET restored_by=?,restored_at=CURRENT_TIMESTAMP WHERE history_id=?');
        $h->bind_param('ii', $uid, $historyId);
        $h->execute();
        auditEvent($conn, $me, 'restored', $module, $id, ['history_id' => $historyId], 'DELETED', 'ACTIVE');
        $conn->commit();
        settingsOut(['ok' => true]);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Record restore failed: ' . $e->getMessage());
        settingsOut(['error' => 'Record could not be restored.'], 422);
    }
}

if ($action === 'permanent_delete_record' && $method === 'POST') {
    $d = body();
    $historyId = (int)($d['history_id'] ?? 0);
    $password = (string)($d['password'] ?? '');

    if ($me['role'] !== 'ADMIN') settingsOut(['error' => 'Administrator authentication is required.'], 403);
    if ($historyId <= 0 || $password === '') settingsOut(['error' => 'Administrator password is required.'], 422);
    if (!columnExistsSettings($conn, 'delete_history', 'permanently_deleted_at') || !columnExistsSettings($conn, 'delete_history', 'permanently_deleted_by')) {
        settingsOut(['error' => 'Permanent deletion is not configured yet. Back up the database, then import Database/calix_existing_database_upgrade.sql first.'], 503);
    }
    verifyAdminPasswordSettings($conn, $me, $password);

    $conn->begin_transaction();
    try {
        $history = one($conn, 'SELECT * FROM delete_history WHERE history_id=? AND restored_at IS NULL AND permanently_deleted_at IS NULL FOR UPDATE', 'i', [$historyId]);
        if (!$history) {
            $conn->rollback();
            settingsOut(['error' => 'This deletion history entry is restored, already purged, or unavailable.'], 404);
        }
        $cfg = [
            'quotations' => ['quotations', 'quotation_id'],
            'projects' => ['projects', 'project_id'],
            'inventory' => ['inventory', 'material_id'],
            'customers' => ['customers', 'customer_id'],
            'sales' => ['sales', 'sales_id'],
            'billing' => ['project_billings', 'billing_id'],
            'payments' => ['project_billing_payments', 'payment_id'],
            'users' => ['users', 'user_id'],
            'todo_notes' => ['todo_notes', 'todo_id']
        ];
        $module = (string)$history['module'];
        if (!isset($cfg[$module])) {
            $conn->rollback();
            settingsOut(['error' => 'Only soft-deleted business records can be permanently deleted here.'], 422);
        }
        [$table, $idColumn] = $cfg[$module];
        if (!columnExistsSettings($conn, $table, 'deleted_at')) {
            $conn->rollback();
            settingsOut(['error' => 'Recoverable deletion is not configured for this record type. Back up the database, then apply Database/calix_existing_database_upgrade.sql.'], 503);
        }
        $recordId = (int)$history['record_id'];
        $target = one($conn, "SELECT `$idColumn` FROM `$table` WHERE `$idColumn`=? AND deleted_at IS NOT NULL FOR UPDATE", 'i', [$recordId]);
        if (!$target) {
            $conn->rollback();
            settingsOut(['error' => 'The soft-deleted record no longer exists.'], 404);
        }
        $dependency = permanentDeletionDependencyMessage($conn, $module, $recordId);
        if ($dependency !== '') {
            $conn->rollback();
            settingsOut(['error' => $dependency], 409);
        }
        if ($module === 'quotations' && tableExistsSettings($conn, 'quotation_items')) {
            $items = $conn->prepare('DELETE FROM quotation_items WHERE quotation_id=?');
            $items->bind_param('i', $recordId);
            $items->execute();
            $items->close();
        }
        if ($module === 'billing' && tableExistsSettings($conn, 'project_billing_items')) {
            $items = $conn->prepare('DELETE FROM project_billing_items WHERE billing_id=?');
            $items->bind_param('i', $recordId);
            $items->execute();
            $items->close();
        }

        $delete = $conn->prepare("DELETE FROM `$table` WHERE `$idColumn`=? AND deleted_at IS NOT NULL");
        $delete->bind_param('i', $recordId);
        $delete->execute();
        if ($delete->affected_rows !== 1) throw new RuntimeException('The deleted record could not be found.');
        $delete->close();

        $adminId = (int)$me['user_id'];
        $mark = $conn->prepare('UPDATE delete_history SET permanently_deleted_by=?,permanently_deleted_at=CURRENT_TIMESTAMP,snapshot_json=NULL WHERE history_id=? AND permanently_deleted_at IS NULL AND restored_at IS NULL');
        $mark->bind_param('ii', $adminId, $historyId);
        $mark->execute();
        if ($mark->affected_rows !== 1) throw new RuntimeException('The deletion history could not be updated.');
        $mark->close();

        auditEvent($conn, $me, 'permanently_deleted', $module, $recordId, ['history_id' => $historyId, 'record_label' => $history['record_label']], 'DELETED', 'PURGED');
        $conn->commit();
        if ($module === 'customers') {
            try {
                if (activeCountSettings($conn, 'SELECT COUNT(*) c FROM customers') === 0) {
                    $conn->query('ALTER TABLE customers AUTO_INCREMENT = 1');
                }
            } catch (mysqli_sql_exception $e) {
                error_log('Customer ID sequence reset failed after permanent deletion: ' . $e->getMessage());
                settingsOut(['error' => 'The customer was permanently deleted, but the empty-table ID counter could not be reset.'], 500);
            }
        }
        settingsOut(['ok' => true]);
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        error_log('Permanent record deletion failed: ' . $e->getMessage());
        if ((int)$e->getCode() === 1451) settingsOut(['error' => 'This record is still linked to other data and cannot be permanently deleted. Remove or retain the related records first.'], 409);
        settingsOut(['error' => 'The record could not be permanently deleted. No changes were saved.'], 422);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Permanent record deletion failed: ' . $e->getMessage());
        settingsOut(['error' => 'The record could not be permanently deleted. No changes were saved.'], 422);
    }
}

settingsOut(['error' => 'Unsupported request.'], 404);
