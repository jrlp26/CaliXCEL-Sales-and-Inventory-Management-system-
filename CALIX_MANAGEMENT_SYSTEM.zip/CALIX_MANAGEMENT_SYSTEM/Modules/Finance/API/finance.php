<?php
require __DIR__ . '/../../../api/common.php';

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

function financeDate(string $value, string $label, bool $required = false): string
{
    $value = trim($value);
    if ($value === '' && !$required) return '';
    $date = DateTime::createFromFormat('Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value) sendError("Enter a valid $label.", 422);
    return $value;
}

function financeInvoiceStatus(array $invoice, string $today): string
{
    if ($invoice['status'] === 'PLANNED') return 'DRAFT';
    if ((float)$invoice['balance'] <= 0.005) return 'PAID';
    if (!empty($invoice['due_date']) && $invoice['due_date'] < $today) return 'OVERDUE';
    return (float)$invoice['collected'] > 0 ? 'PARTIAL' : 'UNPAID';
}

function invoiceRows(mysqli $conn): array
{
    $today = (string)(one($conn, 'SELECT CURDATE() today')['today'] ?? date('Y-m-d'));
    $activeBilling = activeRecordClause($conn, 'project_billings', 'b');
    $activePayments = activeRecordClause($conn, 'project_billing_payments');
    $activeProjects = activeRecordClause($conn, 'projects', 'p');
    $activeCustomers = activeRecordClause($conn, 'customers', 'c');
    $activeQuotations = activeRecordClause($conn, 'quotations', 'q');
    $hasMilestones = dbTableExists($conn, 'project_payment_milestones');
    $milestoneColumns = $hasMilestones ? 'm.label milestone_label,m.percentage milestone_percentage' : 'NULL milestone_label,NULL milestone_percentage';
    $milestoneJoin = $hasMilestones ? 'LEFT JOIN project_payment_milestones m ON m.billing_id=b.billing_id' : '';
    $rows = allRows($conn, "SELECT b.billing_id,b.project_id,b.description,b.amount,b.subtotal_amount,
        b.discount_amount,b.vat_amount,b.vat_rate,b.vat_type,b.invoice_date,b.due_date,
        b.invoice_number,b.status,b.date_created,p.project_name,p.customer_id,p.contract_amount,$milestoneColumns,
        c.customer_name,c.company_name,q.quotation_number,
        COALESCE(pay.collected,0) collected,GREATEST(b.amount-COALESCE(pay.collected,0),0) balance
        FROM project_billings b
        $milestoneJoin
        JOIN projects p ON p.project_id=b.project_id
        JOIN customers c ON c.customer_id=p.customer_id
        JOIN quotations q ON q.quotation_id=p.quotation_id
        LEFT JOIN (
            SELECT billing_id,SUM(amount) collected FROM project_billing_payments WHERE $activePayments GROUP BY billing_id
        ) pay ON pay.billing_id=b.billing_id
        WHERE $activeBilling AND $activeProjects AND $activeCustomers AND $activeQuotations AND q.status='APPROVED'
        ORDER BY COALESCE(b.invoice_date,b.date_created) DESC,b.billing_id DESC");
    foreach ($rows as &$row) {
        $row['items'] = allRows($conn, 'SELECT item_id,description,quantity,unit,unit_price,amount FROM project_billing_items WHERE billing_id=? ORDER BY item_id', 'i', [(int)$row['billing_id']]);
        $row['payment_status'] = financeInvoiceStatus($row, $today);
    }
    unset($row);
    return $rows;
}

if ($action === 'module-defaults' && $method === 'GET') {
    $module = (string)($_GET['module'] ?? '');
    if ($module === 'billing') {
        requirePermission($conn, 'billing.manage');
        $setting = one($conn, "SELECT setting_value FROM business_settings WHERE setting_key='billing_default_due_days'");
        sendJson(['dueDays' => is_numeric($setting['setting_value'] ?? null) ? max(0, (int)$setting['setting_value']) : 30]);
    }
    if ($module === 'payments') {
        requirePermission($conn, 'payments.manage');
        $setting = one($conn, "SELECT setting_value FROM business_settings WHERE setting_key='payment_methods'");
        $methods = array_values(array_filter(array_map('trim', preg_split('/\R/', (string)($setting['setting_value'] ?? '')) ?: [])));
        sendJson(['paymentMethods' => $methods ?: ['Cash', 'Bank Transfer', 'GCash', 'Cheque', 'Other']]);
    }
    sendError('Choose a valid finance settings module.', 422);
}

if ($action === 'invoices' && $method === 'GET') {
    requirePermission($conn, 'billing.view');
    sendJson(invoiceRows($conn));
}

if ($action === 'projects' && $method === 'GET') {
    requirePermission($conn, 'billing.manage');
    if (!dbTableExists($conn, 'project_payment_milestones')) {
        sendError('Project billing milestones are not installed. Back up the database, then apply Database/calix_existing_database_upgrade.sql before using this workflow.', 503);
    }
    $activeBilling = activeRecordClause($conn, 'project_billings');
    $activeSales = activeRecordClause($conn, 'sales');
    $activeProjects = activeRecordClause($conn, 'projects', 'p');
    $activeCustomers = activeRecordClause($conn, 'customers', 'c');
    $activeQuotations = activeRecordClause($conn, 'quotations', 'q');
    $projects = allRows($conn, "SELECT p.project_id,p.project_name,p.customer_id,p.quotation_id,p.contract_amount,p.status,
        c.customer_name,c.company_name,q.quotation_number,
        COALESCE(inv.scheduled,0) scheduled,COALESCE(s.opening_paid,0) opening_paid
        FROM projects p
        JOIN customers c ON c.customer_id=p.customer_id
        JOIN quotations q ON q.quotation_id=p.quotation_id
        LEFT JOIN (SELECT project_id,SUM(amount) scheduled FROM project_billings WHERE $activeBilling GROUP BY project_id) inv
            ON inv.project_id=p.project_id
        LEFT JOIN (
            SELECT project_id,MAX(GREATEST(amount_paid-billing_paid_total,0)) opening_paid
            FROM sales WHERE $activeSales GROUP BY project_id
        ) s ON s.project_id=p.project_id
        WHERE $activeProjects AND $activeCustomers AND $activeQuotations AND q.status='APPROVED'
        ORDER BY p.project_id DESC");
    foreach ($projects as &$project) {
        $project['remaining_to_invoice'] = max(
            0,
            (float)$project['contract_amount'] - (float)$project['opening_paid'] - (float)$project['scheduled']
        );
        $downPayment=projectMilestoneStatus($conn,(int)$project['project_id'],'DOWN_PAYMENT');
        $delivery=projectMilestoneStatus($conn,(int)$project['project_id'],'DELIVERY');
        $project['milestones']=[];
        foreach ([
            'DOWN_PAYMENT'=>$downPayment,
            'DELIVERY'=>$delivery,
            'FINAL_BALANCE'=>projectMilestoneStatus($conn,(int)$project['project_id'],'FINAL_BALANCE')
        ] as $key=>$milestone) {
            if (!$milestone) continue;
            $paid=(bool)$milestone['paid'];
            $alreadyInvoiced=!empty($milestone['billing_id']);
            $eligible=false;
            $reason='';
            if ($paid) $reason='This milestone is already fully paid.';
            elseif ($alreadyInvoiced) $reason='An invoice already exists for this milestone.';
            elseif ($key==='DOWN_PAYMENT') $eligible=true;
            elseif ($key==='DELIVERY' && (!$downPayment || !$downPayment['paid'])) $reason='The 50% down payment must be fully paid first.';
            elseif ($key==='DELIVERY' && !in_array($project['status'],['FOR_INSTALLATION','COMPLETED','CLOSED'],true)) $reason='Available when the project reaches For Installation.';
            elseif ($key==='FINAL_BALANCE' && (!$delivery || !$delivery['paid'])) $reason='The Materials Delivery milestone must be fully paid first.';
            elseif ($key==='FINAL_BALANCE' && !in_array($project['status'],['COMPLETED','CLOSED'],true)) $reason='Available when the project is completed.';
            else $eligible=true;
            $milestone['paid']=$paid;
            $milestone['eligible']=$eligible;
            $milestone['reason']=$reason;
            $milestone['available_amount']=(float)$milestone['remaining'];
            $project['milestones'][]=$milestone;
        }
    }
    unset($project);
    sendJson($projects);
}

if ($action === 'project-items' && $method === 'GET') {
    requirePermission($conn, 'billing.manage');
    $projectId = (int)($_GET['projectId'] ?? 0);
    if ($projectId <= 0) sendError('Select a valid project.', 422);
    $activeProjects = activeRecordClause($conn, 'projects', 'p');
    $activeQuotations = activeRecordClause($conn, 'quotations', 'q');
    $quotation = one($conn, "SELECT q.quotation_id,q.discount_percent,q.vat_type,q.vat_rate
        FROM projects p
        JOIN quotations q ON q.quotation_id=p.quotation_id
        WHERE p.project_id=? AND $activeProjects AND $activeQuotations AND q.status='APPROVED'", 'i', [$projectId]);
    if (!$quotation) sendError('The project is not available for billing.', 404);
    sendJson([
        'discountPercent' => (float)$quotation['discount_percent'],
        'vatType' => (string)$quotation['vat_type'],
        'vatRate' => (float)$quotation['vat_rate'],
        'items' => allRows($conn, 'SELECT item_code,location,description,specification,quantity,unit,unit_price FROM quotation_items WHERE quotation_id=? ORDER BY item_id', 'i', [(int)$quotation['quotation_id']])
    ]);
}

if ($action === 'invoice-create' && $method === 'POST') {
    $user = requirePermission($conn, 'billing.manage');
    if (!dbTableExists($conn, 'project_payment_milestones')) {
        sendError('Project billing milestones are not installed. Back up the database, then apply Database/calix_existing_database_upgrade.sql before creating milestone invoices.', 503);
    }
    $body = body();
    $projectId = (int)($body['projectId'] ?? 0);
    $milestoneId = (int)($body['milestoneId'] ?? 0);
    $description = trim((string)($body['description'] ?? ''));
    $invoiceDate = financeDate((string)($body['invoiceDate'] ?? ''), 'invoice date', true);
    $dueDate = financeDate((string)($body['dueDate'] ?? ''), 'due date');
    if ($dueDate === '') {
        $dueSetting = one($conn, "SELECT setting_value FROM business_settings WHERE setting_key='billing_default_due_days'");
        $dueDays = is_numeric($dueSetting['setting_value'] ?? null) ? max(0, (int)$dueSetting['setting_value']) : 30;
        if ($dueDays > 0) {
            $due = DateTime::createFromFormat('!Y-m-d', $invoiceDate);
            if ($due) $dueDate = $due->modify("+$dueDays days")->format('Y-m-d');
        }
    }
    $vatType = strtoupper(trim((string)($body['vatType'] ?? 'NON-VAT')));
    $discountValue = $body['discountPercent'] ?? 0;
    $vatRateValue = $body['vatRate'] ?? 0;
    $items = $body['items'] ?? null;

    if ($projectId <= 0) sendError('Select an approved project.', 422);
    if ($milestoneId <= 0) sendError('Select an available payment milestone.', 422);
    if ($description === '' || mb_strlen($description) > 150) sendError('Enter an invoice description up to 150 characters.', 422);
    if (!is_numeric($discountValue) || !is_finite((float)$discountValue) || (float)$discountValue < 0 || (float)$discountValue > 100) {
        sendError('Discount must be between 0 and 100 percent.', 422);
    }
    if (!is_numeric($vatRateValue) || !is_finite((float)$vatRateValue) || (float)$vatRateValue < 0 || (float)$vatRateValue > 100) {
        sendError('VAT rate must be between 0 and 100 percent.', 422);
    }
    if (!in_array($vatType, ['VAT EXCLUSIVE','VAT INCLUSIVE','NON-VAT'], true)) sendError('Select a valid VAT treatment.', 422);
    if (!is_array($items) || count($items) < 1 || count($items) > 100) sendError('Add between 1 and 100 invoice items.', 422);

    $cleanItems = [];
    $subtotal = 0.0;
    foreach ($items as $item) {
        if (!is_array($item)) sendError('Invoice items must be valid records.', 422);
        $itemDescription = trim((string)($item['description'] ?? ''));
        $quantityValue = $item['quantity'] ?? null;
        $unit = trim((string)($item['unit'] ?? 'unit'));
        $priceValue = $item['unitPrice'] ?? null;
        if ($itemDescription === '' || mb_strlen($itemDescription) > 255) sendError('Enter an invoice item description up to 255 characters.', 422);
        if (!is_numeric($quantityValue) || !is_finite((float)$quantityValue) || (float)$quantityValue <= 0 || (float)$quantityValue > 999999999) sendError('Enter a valid positive item quantity.', 422);
        if (!is_numeric($priceValue) || !is_finite((float)$priceValue) || (float)$priceValue < 0 || (float)$priceValue > 9999999999.99) sendError('Enter a valid non-negative unit price.', 422);
        if ($unit === '') $unit = 'unit';
        if (mb_strlen($unit) > 30) sendError('Item unit must be 30 characters or fewer.', 422);
        $quantity = round((float)$quantityValue, 3);
        $unitPrice = round((float)$priceValue, 2);
        $lineAmount = round($quantity * $unitPrice, 2);
        $subtotal = round($subtotal + $lineAmount, 2);
        if (!is_finite($subtotal) || $subtotal > 9999999999.99) sendError('Invoice subtotal exceeds the supported maximum.', 422);
        $cleanItems[] = [$itemDescription, $quantity, $unit, $unitPrice, $lineAmount];
    }

    $discount = round($subtotal * (float)$discountValue / 100, 2);
    $taxableAmount = round($subtotal - $discount, 2);
    $vatRate = $vatType === 'NON-VAT' ? 0.0 : (float)$vatRateValue;
    $vatAmount = $vatType === 'VAT EXCLUSIVE'
        ? round($taxableAmount * $vatRate / 100, 2)
        : ($vatType === 'VAT INCLUSIVE' ? round($taxableAmount * $vatRate / (100 + $vatRate), 2) : 0.0);
    $total = round($taxableAmount + ($vatType === 'VAT EXCLUSIVE' ? $vatAmount : 0), 2);
    if (!is_finite($total) || $total <= 0 || $total > 9999999999.99) sendError('Invoice total must be greater than zero and within the supported maximum.', 422);
    if (count($cleanItems)!==1 || (float)$discountValue!==0.0 || $vatType!=='NON-VAT' || (float)$vatRateValue!==0.0) {
        sendError('Milestone invoices must use one line item with no additional discount or tax.', 422);
    }

    $conn->begin_transaction();
    try {
        $activeProjects = activeRecordClause($conn, 'projects', 'p');
        $activeQuotations = activeRecordClause($conn, 'quotations', 'q');
        $activeSales = activeRecordClause($conn, 'sales');
        $activeBillings = activeRecordClause($conn, 'project_billings');
        $project = one($conn, "SELECT p.project_id,p.contract_amount,p.status
            FROM projects p JOIN quotations q ON q.quotation_id=p.quotation_id
            WHERE p.project_id=? AND $activeProjects AND $activeQuotations AND q.status='APPROVED'
            FOR UPDATE", 'i', [$projectId]);
        if (!$project) {
            $conn->rollback();
            sendError('Choose an active project linked to an approved quotation.', 422);
        }
        $sales = one($conn, "SELECT amount_paid,billing_paid_total FROM sales WHERE project_id=? AND $activeSales FOR UPDATE", 'i', [$projectId]);
        if (!$sales) {
            $conn->rollback();
            sendError('The approved project Sales contract record is missing.', 409);
        }
        $milestone=one($conn,'SELECT milestone_id,milestone_key,label,percentage,amount,billing_id FROM project_payment_milestones WHERE milestone_id=? AND project_id=? FOR UPDATE','ii',[$milestoneId,$projectId]);
        if (!$milestone || $milestone['billing_id']!==null) {
            $conn->rollback();
            sendError('This payment milestone is already invoiced or unavailable.',409);
        }
        $milestoneKey=(string)$milestone['milestone_key'];
        $downPayment=projectMilestoneStatus($conn,$projectId,'DOWN_PAYMENT');
        $delivery=projectMilestoneStatus($conn,$projectId,'DELIVERY');
        $stageAllowed=$milestoneKey==='DOWN_PAYMENT'
            || ($milestoneKey==='DELIVERY' && $downPayment && $downPayment['paid'] && in_array($project['status'],['FOR_INSTALLATION','COMPLETED','CLOSED'],true))
            || ($milestoneKey==='FINAL_BALANCE' && $delivery && $delivery['paid'] && in_array($project['status'],['COMPLETED','CLOSED'],true));
        if (!$stageAllowed) {
            $conn->rollback();
            sendError('This payment milestone is not yet available for the project stage.',409);
        }
        $openingPaid=max(0,(float)$sales['amount_paid']-(float)$sales['billing_paid_total']);
        $milestoneStatus=projectMilestoneStatus($conn,$projectId,$milestoneKey);
        $expectedAmount=round((float)($milestoneStatus['remaining']??0),2);
        if ($expectedAmount<=0 || abs($total-$expectedAmount)>0.005
            || abs((float)$cleanItems[0][1]-1)>0.0005
            || abs((float)$cleanItems[0][3]-$expectedAmount)>0.005) {
            $conn->rollback();
            sendError('Invoice line amount must exactly match the remaining ' . $milestone['label'] . ' milestone of ' . number_format(max(0,$expectedAmount),2) . '.',422);
        }
        $scheduled = one($conn, "SELECT COALESCE(SUM(amount),0) scheduled FROM project_billings WHERE project_id=? AND $activeBillings", 'i', [$projectId]);
        $alreadyScheduled = (float)$scheduled['scheduled'];
        $remainingContract = max(0, (float)$project['contract_amount'] - $openingPaid - $alreadyScheduled);
        if ($total > $remainingContract + 0.005) {
            $conn->rollback();
            sendError(
                'Invoice total ' . number_format($total, 2) . ' exceeds the remaining contract value of '
                . number_format($remainingContract, 2) . ' (Contract ' . number_format((float)$project['contract_amount'], 2)
                . '; prior collections ' . number_format($openingPaid, 2)
                . '; existing invoices ' . number_format($alreadyScheduled, 2) . ').',
                422
            );
        }

        $userId = (int)$user['user_id'];
        $stmt = $conn->prepare("INSERT INTO project_billings(project_id,description,amount,subtotal_amount,discount_amount,vat_amount,vat_rate,vat_type,invoice_date,due_date,created_by)
            VALUES(?,?,?,?,?,?,?,?,NULLIF(?,''),NULLIF(?,''),?)");
        $stmt->bind_param('isdddddsssi', $projectId, $description, $total, $subtotal, $discount, $vatAmount, $vatRate, $vatType, $invoiceDate, $dueDate, $userId);
        $stmt->execute();
        $billingId = (int)$stmt->insert_id;
        $stmt->close();

        $itemStmt = $conn->prepare('INSERT INTO project_billing_items(billing_id,description,quantity,unit,unit_price,amount) VALUES(?,?,?,?,?,?)');
        foreach ($cleanItems as [$itemDescription, $quantity, $unit, $unitPrice, $lineAmount]) {
            $itemStmt->bind_param('isdsdd', $billingId, $itemDescription, $quantity, $unit, $unitPrice, $lineAmount);
            $itemStmt->execute();
        }
        $itemStmt->close();
        $stmt=$conn->prepare('UPDATE project_payment_milestones SET billing_id=? WHERE milestone_id=? AND billing_id IS NULL');
        $stmt->bind_param('ii',$billingId,$milestoneId);
        $stmt->execute();
        if ($stmt->affected_rows!==1) {
            $stmt->close();
            throw new RuntimeException('Payment milestone was linked to another invoice during creation.');
        }
        $stmt->close();
        auditEvent($conn, $user, 'created', 'invoice', $billingId, ['project_id' => $projectId, 'amount' => $total, 'milestone' => $milestoneKey]);
        $conn->commit();
        sendJson(['billingId' => $billingId, 'subtotal' => $subtotal, 'discount' => $discount, 'vat' => $vatAmount, 'total' => $total], 201);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Invoice creation failed: ' . $e->getMessage());
        sendError('The invoice could not be saved.', 500);
    }
}

if ($action === 'invoice-issue' && $method === 'POST') {
    $user = requirePermission($conn, 'billing.manage');
    if (!dbTableExists($conn, 'project_payment_milestones')) {
        sendError('Project billing milestones are not installed. Back up the database, then apply Database/calix_existing_database_upgrade.sql before issuing invoices.', 503);
    }
    $body = body();
    $billingId = (int)($body['billingId'] ?? 0);
    if ($billingId <= 0) sendError('Select a valid invoice.', 422);
    $conn->begin_transaction();
    try {
        $activeBillings = activeRecordClause($conn, 'project_billings', 'b');
        $activeProjects = activeRecordClause($conn, 'projects', 'p');
        $activeQuotations = activeRecordClause($conn, 'quotations', 'q');
        $invoice = one($conn, "SELECT b.invoice_date,b.status,b.project_id,p.status project_status,m.milestone_key FROM project_billings b
            JOIN projects p ON p.project_id=b.project_id
            LEFT JOIN project_payment_milestones m ON m.billing_id=b.billing_id
            JOIN quotations q ON q.quotation_id=p.quotation_id
            WHERE b.billing_id=? AND $activeBillings AND $activeProjects AND $activeQuotations AND q.status='APPROVED'
            FOR UPDATE", 'i', [$billingId]);
        if (!$invoice || $invoice['status'] !== 'PLANNED') {
            $conn->rollback();
            sendError('This invoice is already issued or no longer available.', 409);
        }
        if (!empty($invoice['milestone_key'])) {
            $milestoneKey=(string)$invoice['milestone_key'];
            $currentMilestone=projectMilestoneStatus($conn,(int)$invoice['project_id'],$milestoneKey);
            if ($currentMilestone && $currentMilestone['paid']) {
                $conn->rollback();
                sendError('This milestone has already been fully collected; the draft invoice cannot be issued.',409);
            }
            $downPayment=projectMilestoneStatus($conn,(int)$invoice['project_id'],'DOWN_PAYMENT');
            $delivery=projectMilestoneStatus($conn,(int)$invoice['project_id'],'DELIVERY');
            $stageAllowed=$milestoneKey==='DOWN_PAYMENT'
                || ($milestoneKey==='DELIVERY' && $downPayment && $downPayment['paid'] && in_array($invoice['project_status'],['FOR_INSTALLATION','COMPLETED','CLOSED'],true))
                || ($milestoneKey==='FINAL_BALANCE' && $delivery && $delivery['paid'] && in_array($invoice['project_status'],['COMPLETED','CLOSED'],true));
            if (!$stageAllowed) {
                $conn->rollback();
                sendError('This payment milestone cannot be issued until its prerequisite milestone and project stage are complete.',409);
            }
        }
        $year = substr((string)($invoice['invoice_date'] ?? date('Y-m-d')), 0, 4);
        $invoiceNumber = 'INV-' . $year . '-' . str_pad((string)$billingId, 6, '0', STR_PAD_LEFT);
        $baseNumber = $invoiceNumber;
        $suffix = 1;
        while (one($conn, 'SELECT billing_id FROM project_billings WHERE invoice_number=? AND billing_id<>? LIMIT 1', 'si', [$invoiceNumber, $billingId])) {
            $invoiceNumber = $baseNumber . '-' . $suffix++;
        }
        $stmt = $conn->prepare("UPDATE project_billings SET invoice_number=?,status='INVOICED'
            WHERE billing_id=? AND status='PLANNED' AND EXISTS(
                SELECT 1 FROM projects p JOIN quotations q ON q.quotation_id=p.quotation_id
                WHERE p.project_id=project_billings.project_id AND " . activeRecordClause($conn, 'projects', 'p') . " AND q.status='APPROVED' AND " . activeRecordClause($conn, 'quotations', 'q') . "
            )");
        $stmt->bind_param('si', $invoiceNumber, $billingId);
        $stmt->execute();
        $changed = $stmt->affected_rows;
        $stmt->close();
        if ($changed < 1) {
            $conn->rollback();
            sendError('This invoice is already issued or no longer available.', 409);
        }
        auditEvent($conn, $user, 'issued', 'invoice', $billingId, ['invoice_number' => $invoiceNumber], 'DRAFT', 'UNPAID');
        $conn->commit();
        sendJson(['issued' => true, 'invoiceNumber' => $invoiceNumber]);
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        if ((int)$e->getCode() === 1062) sendError('That invoice number is already in use.', 409);
        error_log('Invoice issue failed: ' . $e->getMessage());
        sendError('The invoice could not be issued.', 500);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Invoice issue failed: ' . $e->getMessage());
        sendError('The invoice could not be issued.', 500);
    }
}

if ($action === 'payments' && $method === 'GET') {
    requirePermission($conn, 'payments.view');
    $activePayments = activeRecordClause($conn, 'project_billing_payments', 'pay');
    $activeBillings = activeRecordClause($conn, 'project_billings', 'b');
    $activeProjects = activeRecordClause($conn, 'projects', 'p');
    $activeCustomers = activeRecordClause($conn, 'customers', 'c');
    $activeQuotations = activeRecordClause($conn, 'quotations', 'q');
    sendJson(allRows($conn, "SELECT pay.payment_id,pay.billing_id,pay.amount,pay.payment_date,pay.payment_method,
        CONCAT('PAY-',YEAR(pay.payment_date),'-',LPAD(pay.payment_id,6,'0')) payment_number,
        pay.reference_no,pay.notes,COALESCE(u.username,'—') received_by,b.invoice_number,b.description invoice_description,
        b.amount invoice_total,p.project_name,c.customer_name,q.quotation_number
        FROM project_billing_payments pay
        JOIN project_billings b ON b.billing_id=pay.billing_id
        JOIN projects p ON p.project_id=b.project_id
        JOIN customers c ON c.customer_id=p.customer_id
        JOIN quotations q ON q.quotation_id=p.quotation_id
        LEFT JOIN users u ON u.user_id=pay.received_by
        WHERE $activePayments AND $activeBillings AND $activeProjects AND $activeCustomers AND $activeQuotations AND q.status='APPROVED'
        ORDER BY pay.payment_date DESC,pay.payment_id DESC"));
}

if ($action === 'payment-invoices' && $method === 'GET') {
    requirePermission($conn, 'payments.manage');
    sendJson(invoiceRows($conn));
}

if ($action === 'payment-create' && $method === 'POST') {
    $user = requirePermission($conn, 'payments.manage');
    $body = body();
    $billingId = (int)($body['billingId'] ?? 0);
    $amountValue = $body['amount'] ?? null;
    $paymentDate = financeDate((string)($body['paymentDate'] ?? ''), 'payment date', true);
    $paymentMethod = trim((string)($body['paymentMethod'] ?? ''));
    $reference = trim((string)($body['referenceNo'] ?? ''));
    $notes = trim((string)($body['notes'] ?? ''));
    if ($billingId <= 0) sendError('Select a valid invoice.', 422);
    if (!is_numeric($amountValue) || !is_finite((float)$amountValue)) sendError('Enter a valid payment amount.', 422);
    $amount = round((float)$amountValue, 2);
    if ($amount <= 0 || $amount > 9999999999.99) sendError('Payment amount must be greater than zero and within the supported maximum.', 422);
    if (mb_strlen($paymentMethod) > 50 || mb_strlen($reference) > 100 || mb_strlen($notes) > 500) sendError('Payment method, reference, or notes exceed the supported length.', 422);
    if ($paymentMethod !== '') {
        $methodSetting = one($conn, "SELECT setting_value FROM business_settings WHERE setting_key='payment_methods'");
        $allowedMethods = array_values(array_filter(array_map('trim', preg_split('/\R/', (string)($methodSetting['setting_value'] ?? 'Cash\nBank Transfer\nGCash\nCheque\nOther')) ?: [])));
        if (!in_array($paymentMethod, $allowedMethods, true)) sendError('Choose a payment method currently configured in Business Settings.', 422);
    }

    $conn->begin_transaction();
    try {
        $activeBillings = activeRecordClause($conn, 'project_billings', 'b');
        $activeBillingRows = activeRecordClause($conn, 'project_billings', 'b');
        $activePayments = activeRecordClause($conn, 'project_billing_payments', 'pay');
        $activeSales = activeRecordClause($conn, 'sales');
        $activeProjects = activeRecordClause($conn, 'projects', 'p');
        $activeQuotations = activeRecordClause($conn, 'quotations', 'q');
        $invoice = one($conn, "SELECT b.billing_id,b.project_id,b.amount,b.status
            FROM project_billings b JOIN projects p ON p.project_id=b.project_id
            JOIN quotations q ON q.quotation_id=p.quotation_id
            WHERE b.billing_id=? AND $activeBillings AND $activeProjects AND $activeQuotations AND q.status='APPROVED'
            FOR UPDATE", 'i', [$billingId]);
        if (!$invoice) {
            $conn->rollback();
            sendError('Invoice not found.', 404);
        }
        if ($invoice['status'] === 'PLANNED') {
            $conn->rollback();
            sendError('Issue the invoice before recording a payment.', 409);
        }
        $paidRow = one($conn, "SELECT COALESCE(SUM(amount),0) paid FROM project_billing_payments WHERE billing_id=? AND " . activeRecordClause($conn, 'project_billing_payments'), 'i', [$billingId]);
        $currentPaid = (float)$paidRow['paid'];
        if ($currentPaid + $amount > (float)$invoice['amount'] + 0.005) {
            $conn->rollback();
            sendError('Payment cannot exceed the invoice remaining balance.', 422);
        }

        $userId = (int)$user['user_id'];
        $stmt = $conn->prepare('INSERT INTO project_billing_payments(billing_id,amount,payment_date,payment_method,reference_no,notes,received_by) VALUES(?,?,?,?,?,?,?)');
        $stmt->bind_param('idssssi', $billingId, $amount, $paymentDate, $paymentMethod, $reference, $notes, $userId);
        $stmt->execute();
        $paymentId = (int)$stmt->insert_id;
        $stmt->close();
        $paymentNumber = 'PAY-' . substr($paymentDate, 0, 4) . '-' . str_pad((string)$paymentId, 6, '0', STR_PAD_LEFT);
        $billingPaid = $currentPaid + $amount;
        if ($billingPaid + 0.005 >= (float)$invoice['amount']) {
            $stmt = $conn->prepare("UPDATE project_billings SET status='PAID' WHERE billing_id=?");
            $stmt->bind_param('i', $billingId);
            $stmt->execute();
            $stmt->close();
        }

        $sales = one($conn, "SELECT sales_id,total_amount,amount_paid,billing_paid_total FROM sales WHERE project_id=? AND $activeSales FOR UPDATE", 'i', [(int)$invoice['project_id']]);
        if (!$sales) throw new DomainException('Project Sales contract record is unavailable.');
        $paidRow = one($conn, "SELECT COALESCE(SUM(pay.amount),0) paid
            FROM project_billings b LEFT JOIN project_billing_payments pay ON pay.billing_id=b.billing_id AND $activePayments
            WHERE b.project_id=? AND $activeBillingRows", 'i', [(int)$invoice['project_id']]);
        $billingPaidTotal = (float)$paidRow['paid'];
        $openingPaid = max(0, (float)$sales['amount_paid'] - (float)$sales['billing_paid_total']);
        $collected = $openingPaid + $billingPaidTotal;
        if ($collected > (float)$sales['total_amount'] + 0.005) throw new DomainException('Project payments exceed the contract amount.');
        $paymentStatus = $collected + 0.005 >= (float)$sales['total_amount'] ? 'PAID' : ($collected > 0 ? 'PARTIAL' : 'UNPAID');
        $stmt = $conn->prepare('UPDATE sales SET amount_paid=?,billing_paid_total=?,payment_status=? WHERE sales_id=?');
        $stmt->bind_param('ddsi', $collected, $billingPaidTotal, $paymentStatus, $sales['sales_id']);
        $stmt->execute();
        $stmt->close();
        auditEvent($conn, $user, 'payment_recorded', 'payment', $paymentId, [
            'billing_id' => $billingId,
            'project_id' => (int)$invoice['project_id'],
            'amount' => $amount,
            'payment_number' => $paymentNumber
        ], null, $paymentStatus);
        $conn->commit();
        sendJson(['recorded' => true, 'paymentNumber' => $paymentNumber, 'invoicePaid' => $billingPaid, 'projectCollected' => $collected]);
    } catch (DomainException $e) {
        $conn->rollback();
        if ($e->getMessage() === 'Project payments exceed the contract amount.') {
            sendError('This payment would exceed the remaining project contract balance. Refresh and verify the invoice balance before retrying.', 409);
        }
        error_log('Payment recording failed: ' . $e->getMessage());
        sendError('Payment could not be recorded because the project financial record is unavailable. Contact your administrator.', 409);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Payment recording failed: ' . $e->getMessage());
        sendError('The payment could not be recorded. Refresh the invoice and try again; contact your administrator if the problem continues.', 500);
    }
}

sendError('Finance API route not found.', 404);
