(function () {
    const account = (() => {
        try { return JSON.parse(sessionStorage.getItem('calixAccount') || 'null'); }
        catch (_) { return null; }
    })();
    const isAdmin = account?.role === 'ADMIN';
    const esc = CalixUI.escape;

    function button(module, id, label) {
        if (!isAdmin) return '';
        return `<button class="text-button danger" type="button" data-record-delete data-module="${esc(module)}" data-record-id="${esc(id)}" data-record-label="${esc(label)}">Delete</button>`;
    }

    function askPassword(module, recordId, label) {
        return new Promise(resolve => {
            const dialog = document.createElement('dialog');
            dialog.className = 'calix-confirm-dialog';
            dialog.dataset.module = module;
            dialog.dataset.recordId = recordId;
            const card = document.createElement('form');
            card.className = 'calix-confirm-card';
            const heading = document.createElement('h2');
            heading.textContent = 'Authorize deletion';
            const copy = document.createElement('p');
            copy.textContent = `Enter your administrator password to move ${label} to the Trashbin.`;
            const passwordLabel = document.createElement('label');
            passwordLabel.textContent = 'Administrator password';
            const password = document.createElement('input');
            password.type = 'password';
            password.autocomplete = 'current-password';
            password.required = true;
            passwordLabel.appendChild(password);
            const error = document.createElement('p');
            error.setAttribute('role', 'alert');
            const actions = document.createElement('div');
            actions.className = 'dialog-actions';
            const cancel = document.createElement('button');
            cancel.type = 'button';
            cancel.className = 'button secondary';
            cancel.textContent = 'Cancel';
            const submit = document.createElement('button');
            submit.type = 'submit';
            submit.className = 'button danger';
            submit.textContent = 'Authorize Delete';
            actions.append(cancel, submit);
            card.append(heading, copy, passwordLabel, error, actions);
            dialog.appendChild(card);
            document.body.appendChild(dialog);

            let settled = false;
            const finish = result => {
                if (settled) return;
                settled = true;
                if (dialog.open) dialog.close();
                dialog.remove();
                resolve(result);
            };
            cancel.addEventListener('click', () => finish(null));
            dialog.addEventListener('cancel', event => {
                event.preventDefault();
                finish(null);
            });
            card.addEventListener('submit', async event => {
                event.preventDefault();
                if (!card.reportValidity() || submit.disabled) return;
                submit.disabled = true;
                error.textContent = '';
                try {
                    await CalixAPI.request('settings.php?action=delete_record', {
                        method: 'POST',
                        redirectOnUnauthorized: false,
                        body: JSON.stringify({
                            module: dialog.dataset.module,
                            record_id: Number(dialog.dataset.recordId),
                            password: password.value
                        })
                    });
                    finish(true);
                } catch (requestError) {
                    if (requestError.status === 401 && requestError.message !== 'Incorrect administrator password.') {
                        sessionStorage.removeItem('calixAccount');
                        location.replace(new URL('../../../System/HTML/LoginPage.html', location.href).href);
                    }
                    error.textContent = requestError.message || 'The record could not be deleted.';
                    submit.disabled = false;
                    password.focus();
                }
            });
            dialog.showModal();
            password.focus();
        });
    }

    async function authorize(button, onDeleted) {
        if (!isAdmin || button.disabled) return;
        const label = button.dataset.recordLabel || 'this record';
        if (!await CalixUI.confirm({
            title: 'Move record to Trashbin?',
            message: `Delete ${label}? The record will be kept in the Trashbin when recovery is supported.`,
            confirmLabel: 'Continue',
            danger: true
        })) return;

        button.disabled = true;
        const dialogResult = askPassword(button.dataset.module, button.dataset.recordId, label);
        try {
            if (await dialogResult) {
                CalixUI.notify(`${label} deleted.`, 'success');
                await onDeleted();
            }
        } finally {
            button.disabled = false;
        }
    }

    function bind(container, onDeleted) {
        if (!container || typeof onDeleted !== 'function') return;
        container.addEventListener('click', event => {
            const button = event.target.closest('[data-record-delete]');
            if (!button || !container.contains(button)) return;
            authorize(button, onDeleted).catch(error => CalixUI.notify(error.message || 'The record could not be deleted.', 'error'));
        });
    }

    window.CalixRecordDeletion = {button, bind};
}());
