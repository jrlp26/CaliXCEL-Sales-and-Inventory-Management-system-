(function () {
    const $ = id => document.getElementById(id);
    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    let account = null;
    try { account = JSON.parse(sessionStorage.getItem('calixAccount') || 'null'); } catch (error) { account = null; }
    const isAdmin = account?.role === 'ADMIN';
    const canManageUsers = isAdmin || (account?.permissions || []).includes('users.manage');
    let state = {users:[],roles:[],permissions:[],businessSettings:{},currentUserId:0};

    async function request(action, options={}) {
        try {
            return await CalixAPI.request('settings.php?action=' + encodeURIComponent(action), {...options,redirectOnUnauthorized:false});
        } catch (error) {
            if (error.status === 401 && error.message !== 'Incorrect administrator password.') {
                sessionStorage.removeItem('calixAccount');
                location.replace(new URL('../../../System/HTML/LoginPage.html', location.href).href);
            }
            throw error;
        }
    }
    function roleName(code) { return state.roles.find(role => role.role_key === code)?.role_name || code; }
    const panels={users:$('usersPanel'),roles:$('rolesPanel'),business:$('businessPanel')};
    document.querySelectorAll('.settings-tab').forEach(button => button.addEventListener('click', () => {
        document.querySelectorAll('.settings-tab').forEach(item => item.classList.toggle('active', item === button));
        Object.keys(panels).forEach(key => panels[key].classList.toggle('active', key === button.dataset.tab));
    }));
    document.querySelectorAll('.module-settings-tab').forEach(button => button.addEventListener('click', () => {
        document.querySelectorAll('.module-settings-tab').forEach(item => item.classList.toggle('active', item === button));
        document.querySelectorAll('.module-settings-panel').forEach(panel => panel.classList.toggle('active', panel.dataset.modulePanel === button.dataset.moduleSettings));
    }));

    function populateModuleSettings() {
        const values = {
            customer_duplicate_email: '1',
            customer_duplicate_name_contact: '1',
            default_validity_days: '7',
            default_vat_rate: '12.00',
            default_vat_type: 'VAT EXCLUSIVE',
            default_project_duration_days: '0',
            inventory_default_reorder_level: '5',
            billing_default_due_days: '30',
            payment_methods: 'Cash\nBank Transfer\nGCash\nCheque\nOther',
            report_default_range_months: '12',
            ...state.businessSettings
        };
        document.querySelectorAll('.module-settings-form').forEach(form => {
            form.querySelectorAll('[name]').forEach(control => {
                const value = values[control.name] ?? '';
                if (control.type === 'checkbox') control.checked = value === '1' || value === 1 || value === true;
                else control.value = value;
            });
        });
    }

    function renderUsers() {
        const q=$('userSearch').value.trim().toLowerCase(), role=$('roleFilter').value;
        const users=state.users.filter(user => (!q || [user.full_name,user.username,roleName(user.role)].filter(Boolean).join(' ').toLowerCase().includes(q)) && (!role || user.role===role));
        $('usersBody').innerHTML=users.map(user=>{
            const canEdit = canManageUsers && (isAdmin || user.role !== 'ADMIN');
            const actions = `${canEdit?`<button class="small-button" type="button" data-edit-user="${user.user_id}">Edit</button>`:''}${isAdmin&&Number(user.user_id)!==Number(state.currentUserId)?`<button class="small-button danger" type="button" data-delete-user="${user.user_id}">Move to Trashbin</button>`:''}`;
            return `<tr><td><strong>${esc(user.full_name || '—')}</strong></td><td>${esc(user.username)}</td><td>${esc(roleName(user.role))}</td><td><span class="status-pill ${Number(user.is_active)?'active':'inactive'}">${Number(user.is_active)?'Active':'Inactive'}</span></td><td><div class="row-actions">${actions||'—'}</div></td></tr>`;
        }).join('');
        $('usersEmpty').hidden=users.length>0;
    }
    function renderRoles() {
        $('rolesGrid').innerHTML=state.roles.map(role=>`<article class="role-card"><div class="role-card-head"><div><h3>${esc(role.role_name)}</h3><div class="role-code">${esc(role.role_key)}${Number(role.is_system)?' · System role':''}</div></div><div class="row-actions">${canManageUsers&&role.role_key!=='ADMIN'?`<button class="small-button" type="button" data-edit-role="${esc(role.role_key)}">Edit</button>`:''}${canManageUsers&&!Number(role.is_system)?`<button class="small-button danger" type="button" data-delete-role="${esc(role.role_key)}">Delete</button>`:''}</div></div><div class="role-permissions">${(role.permissions||[]).map(p=>`<span class="permission-chip">${esc(p.permission_name)}</span>`).join('') || '<span class="permission-chip">No permissions</span>'}</div></article>`).join('');
    }
    function render() {
        const roleOptions=state.roles.filter(role=>isAdmin||role.role_key!=='ADMIN').map(role=>`<option value="${esc(role.role_key)}">${esc(role.role_name)}</option>`).join('');
        $('roleFilter').innerHTML='<option value="">All roles</option>'+roleOptions;
        $('settingsUserRole').innerHTML=roleOptions;
        renderUsers();renderRoles();
    }
    async function load() {
        try {
            state=await request('overview');
            render();
            populateModuleSettings();
        }
        catch(error){ document.querySelector('.workspace-content').insertAdjacentHTML('afterbegin',`<div class="notice show">${esc(error.message)}</div>`); }
    }

    function openUser(user=null) {
        $('userForm').reset(); $('settingsUserRole').disabled=false; $('editUserId').value=user?.user_id||''; $('userDialogTitle').textContent=user?'Edit User':'Add User'; $('settingsPasswordConfirm').setCustomValidity('');
        $('settingsFullName').value=user?.full_name||''; $('settingsUsername').value=user?.username||''; $('settingsUserRole').value=user?.role||state.roles.find(r=>r.role_key!=='ADMIN')?.role_key||state.roles[0]?.role_key||''; $('settingsUserActive').checked=user?Number(user.is_active)===1:true; $('settingsPassword').value=''; $('settingsPasswordConfirm').value=''; $('settingsPassword').required=!user; $('settingsPasswordConfirm').required=!user; $('passwordConfirmLabel').hidden=!!user; $('passwordHint').textContent=user?'Leave blank to keep the current password; any new password must be unique across accounts.':'At least 8 characters and unique across accounts.'; $('userFormError').textContent=''; $('userDialog').showModal();
        if (isAdmin && Number(user?.user_id) === Number(state.currentUserId)) $('settingsUserRole').disabled=true;
    }
    function openRole(role=null) {
        $('roleForm').reset(); $('editRoleCode').value=role?.role_key||''; $('roleDialogTitle').textContent=role?'Edit Role':'Add Role'; $('roleName').value=role?.role_name||''; $('roleCode').value=role?.role_key||''; $('roleCode').readOnly=!!role&&Number(role.is_system)===1;
        $('permissionGrid').innerHTML=state.permissions.map(permission=>`<label class="permission-option"><input type="checkbox" value="${esc(permission.permission_key)}" ${(role?.permissions||[]).some(p=>p.permission_key===permission.permission_key)?'checked':''}><span><strong>${esc(permission.permission_name)}</strong><small>${esc(permission.description)}</small></span></label>`).join(''); $('roleFormError').textContent=''; $('roleDialog').showModal();
    }
    function openAuthDelete(id,label) {
        $('authForm').reset(); $('authRecordId').value=id; $('authDialogTitle').textContent='Move Account to Trashbin'; $('authCopy').innerHTML=`Enter your administrator password to move user account <strong>${esc(label)}</strong> to the Trashbin. The account can be restored later.`; $('authSubmit').textContent='Authorize Delete'; $('authSubmit').className='button danger-button'; $('authError').textContent=''; $('authDialog').showModal();
    }

    $('userSearch').addEventListener('input',renderUsers); $('roleFilter').addEventListener('change',renderUsers);
    $('addUserBtn').hidden=!canManageUsers;
    $('addRoleBtn').hidden=!canManageUsers;
    $('addUserBtn').addEventListener('click',()=>openUser()); $('addRoleBtn').addEventListener('click',()=>openRole());
    $('usersBody').addEventListener('click',event=>{const edit=event.target.closest('[data-edit-user]'),del=event.target.closest('[data-delete-user]');if(edit)openUser(state.users.find(u=>String(u.user_id)===edit.dataset.editUser));if(del){const user=state.users.find(u=>String(u.user_id)===del.dataset.deleteUser);openAuthDelete(del.dataset.deleteUser,user?.username||'user account');}});
    $('rolesGrid').addEventListener('click',async event=>{const edit=event.target.closest('[data-edit-role]'),del=event.target.closest('[data-delete-role]');if(edit)openRole(state.roles.find(r=>r.role_key===edit.dataset.editRole));if(del&&await CalixUI.confirm({title:'Delete custom role?',message:'Users assigned to this role may lose access. This action cannot be undone.',confirmLabel:'Delete role',danger:true})){try{await request('delete_role',{method:'POST',body:JSON.stringify({role_key:del.dataset.deleteRole})});await load();CalixUI.notify('Custom role deleted.','success');}catch(error){CalixUI.notify(error.message,'error');}}});

    $('userForm').addEventListener('submit',async event=>{event.preventDefault();if(!event.currentTarget.reportValidity())return;const button=event.currentTarget.querySelector('[type="submit"]');if(button.disabled)return;const password=$('settingsPassword').value,passwordConfirmation=$('settingsPasswordConfirm').value;if(password!==passwordConfirmation){$('userFormError').textContent='Passwords do not match. Re-enter the same password in both fields.';$('settingsPasswordConfirm').setCustomValidity('Passwords do not match.');$('settingsPasswordConfirm').reportValidity();return;}$('settingsPasswordConfirm').setCustomValidity('');button.disabled=true;button.textContent='Saving…';try{await request('save_user',{method:'POST',body:JSON.stringify({user_id:Number($('editUserId').value||0),full_name:$('settingsFullName').value.trim(),username:$('settingsUsername').value.trim(),role:$('settingsUserRole').value,password,password_confirmation:passwordConfirmation,is_active:$('settingsUserActive').checked})});$('userDialog').close();await load();CalixUI.notify('User account saved.','success');}catch(error){$('userFormError').textContent=error.message;}finally{button.disabled=false;button.textContent='Save User';}});
    $('settingsPassword').addEventListener('input',()=>{if($('editUserId').value){$('passwordConfirmLabel').hidden=!$('settingsPassword').value;$('settingsPasswordConfirm').required=!!$('settingsPassword').value;if(!$('settingsPassword').value)$('settingsPasswordConfirm').value='';}});
    $('settingsPasswordConfirm').addEventListener('input',()=>{$('settingsPasswordConfirm').setCustomValidity('');$('userFormError').textContent='';});
    $('roleForm').addEventListener('submit',async event=>{event.preventDefault();if(!event.currentTarget.reportValidity())return;const button=event.currentTarget.querySelector('[type="submit"]');if(button.disabled)return;const permissions=[...$('permissionGrid').querySelectorAll('input:checked')].map(input=>input.value);button.disabled=true;button.textContent='Saving…';try{await request('save_role',{method:'POST',body:JSON.stringify({original_key:$('editRoleCode').value,role_key:$('roleCode').value,role_name:$('roleName').value.trim(),permissions})});$('roleDialog').close();await load();CalixUI.notify('Role permissions saved.','success');}catch(error){$('roleFormError').textContent=error.message;}finally{button.disabled=false;button.textContent='Save Role';}});
    document.querySelectorAll('.module-settings-form').forEach(form=>form.addEventListener('submit',async event=>{
        event.preventDefault();
        const button=form.querySelector('button[type="submit"]'),feedback=form.querySelector('.form-feedback');
        if(button.disabled||!form.reportValidity())return;
        const settings={};
        form.querySelectorAll('[name]').forEach(control=>{
            settings[control.name]=control.type==='checkbox'?(control.checked?'1':'0'):control.value;
        });
        feedback.textContent='Saving settings…';feedback.className='form-feedback';button.disabled=true;
        try{
            const result=await request('save_business',{method:'POST',body:JSON.stringify({settings})});
            Object.assign(state.businessSettings,result.settings||{});
            populateModuleSettings();
            feedback.textContent='Module settings saved.';
        }catch(error){feedback.textContent=error.message;feedback.className='form-feedback error';}
        finally{button.disabled=false;}
    }));
    $('authForm').addEventListener('submit', async event => {event.preventDefault();if(!event.currentTarget.reportValidity())return;const button=event.currentTarget.querySelector('[type="submit"]');if(button.disabled)return;button.disabled=true;button.textContent='Working…';try{await request('delete_record',{method:'POST',body:JSON.stringify({module:'users',record_id:Number($('authRecordId').value),password:$('authPassword').value})});$('authDialog').close();await load();CalixUI.notify('User account moved to the Trashbin.','success');}catch(error){$('authError').textContent=error.message;}finally{button.disabled=false;button.textContent='Authorize Delete';}});

    $('settingsPasswordToggle').addEventListener('click',()=>{const p=$('settingsPassword');p.type=p.type==='password'?'text':'password';$('settingsPasswordToggle').textContent=p.type==='password'?'Show':'Hide';});
    $('authPasswordToggle').addEventListener('click',()=>{const p=$('authPassword');p.type=p.type==='password'?'text':'password';$('authPasswordToggle').textContent=p.type==='password'?'Show':'Hide';});
    document.querySelectorAll('[data-close]').forEach(button=>button.addEventListener('click',()=>$(button.dataset.close).close()));
    window.addEventListener('calix:search',event=>{$('userSearch').value=event.detail?.query||'';renderUsers();});
    load();
}());
