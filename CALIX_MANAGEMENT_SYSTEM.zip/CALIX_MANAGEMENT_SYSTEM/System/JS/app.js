(function () {
  const appScriptUrl = document.currentScript ? document.currentScript.src : "";
  const projectUrl = appScriptUrl
    ? new URL("../../", appScriptUrl)
    : new URL("../../", window.location.href);
  function projectPath(path) {
    return new URL(path.replace(/^\/+/, ""), projectUrl).href;
  }
  const page = document.body.dataset.page || "dashboard";
  let account = null;
  try {
    account = JSON.parse(sessionStorage.getItem("calixAccount") || "null");
  } catch (e) {
    account = null;
  }
  const role = account ? account.role : "";
  const permissions = new Set(
    account && Array.isArray(account.permissions) ? account.permissions : [],
  );
  function can(permission) {
    return role === "ADMIN" || permissions.has(permission);
  }
  const sidebar = document.getElementById("sidebar");
  const topbar = document.getElementById("topbar");

  if (!account || !role) {
    window.location.replace(projectPath("System/HTML/LoginPage.html"));
    return;
  }
  const pagePermission = {
    dashboard: "dashboard.view",
    "quotation-create": "quotations.manage",
    projects: "projects.view",
    quotations: "quotations.view",
    "sales-summary": "sales.view",
    "finance-billing": "billing.view",
    "finance-payments": "payments.view",
    "inventory-create": "inventory.manage",
    "inventory-view": "inventory.view",
    customers: "customers.lookup",
    reports: "reports.operational",
    settings: "settings.manage",
    trashbin: "settings.manage",
  }[page];
  if (pagePermission && !can(pagePermission)) {
    sessionStorage.setItem(
      "calixAccessNotice",
      "You do not have permission to view that page. Contact your administrator if you need access.",
    );
    window.location.replace(projectPath("System/HTML/Dashboard.html"));
    return;
  }
  if (page === "trashbin" && role !== "ADMIN") {
    sessionStorage.setItem(
      "calixAccessNotice",
      "The Trashbin is available to administrators only.",
    );
    window.location.replace(projectPath("System/HTML/Dashboard.html"));
    return;
  }

  const icons = {
    home: '<path d="m3 11 9-8 9 8"></path><path d="M5 10v10h14V10"></path>',
    tasks: '<path d="M8 6h12M8 12h12M8 18h12"></path><path d="m3 6 1.5 1.5L7 5M3 12l1.5 1.5L7 11M3 18l1.5 1.5L7 17"></path>',
    quotation:
      '<path d="M6 3h9l4 4v14H6z"></path><path d="M15 3v5h5M9 13h7M9 17h5"></path>',
    sales: '<path d="M4 5h16v14H4z"></path><path d="M4 10h16M9 5v14"></path>',
    inventory:
      '<path d="M4 8.5 12 4l8 4.5v8L12 21l-8-4.5z"></path><path d="m4 8.5 8 4.5 8-4.5M12 13v8"></path>',
    projects: '<path d="M4 7h6l2 2h8v10H4z"></path>',
    customers:
      '<circle cx="9" cy="8" r="3"></circle><circle cx="17" cy="9" r="2"></circle><path d="M3 20a6 6 0 0 1 12 0M14 15a5 5 0 0 1 7 5"></path>',
    reports:
      '<path d="M6 3h9l4 4v14H6z"></path><path d="M15 3v5h5M9 16v-3M13 16V9M17 16v-5"></path>',
    settings:
      '<circle cx="12" cy="12" r="3"></circle><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.5-2.4 1a8 8 0 0 0-1.7-1L14.5 3h-5L9 6a8 8 0 0 0-1.7 1L5 6 3 9.5 5.1 11a7 7 0 0 0 0 2L3 14.5 5 18l2.3-1a8 8 0 0 0 1.7 1l.5 3h5l.5-3a8 8 0 0 0 1.7-1l2.3 1 2-3.5-2.1-1.5a7 7 0 0 0 .1-1z"></path>',
    deletion:
      '<path d="M4 7h16M10 11v6M14 11v6M5 7l1 14h12l1-14M9 7V4h6v3"></path>',
    logout: '<path d="M10 4H4v16h6M14 8l4 4-4 4M8 12h10"></path>',
  };

  function navIcon(name) {
    return (
      '<svg class="nav-icon" viewBox="0 0 24 24" aria-hidden="true">' +
      icons[name] +
      "</svg>"
    );
  }

  function isActive(name) {
    return page === name ? " active" : "";
  }

  function groupIsActive(name) {
    if (name === "quotation" && page === "projects") {
      return true;
    }
    if (
      name === "finance" &&
      ["finance-billing", "finance-payments", "sales-summary"].includes(page)
    ) {
      return true;
    }
    return page.indexOf(name + "-") === 0;
  }

  function navGroup(name, label, iconName, links) {
    const openClass = groupIsActive(name) ? " open" : "";
    const activeClass = groupIsActive(name) ? " active" : "";
    const expanded = groupIsActive(name) ? "true" : "false";
    let submenu = "";

    links.forEach(function (link) {
      submenu +=
        '<a class="' +
        isActive(link.page).trim() +
        '" href="' +
        link.href +
        '">' +
        link.label +
        "</a>";
    });

    return (
      '<div class="nav-group' +
      openClass +
      '" data-group="' +
      name +
      '">' +
      '<button class="nav-toggle' +
      activeClass +
      '" type="button" aria-expanded="' +
      expanded +
      '">' +
      navIcon(iconName) +
      '<span class="nav-toggle-text">' +
      label +
      '</span><span class="nav-caret" aria-hidden="true"></span></button>' +
      '<div class="nav-submenu">' +
      submenu +
      "</div></div>"
    );
  }

  sidebar.innerHTML =
    '<a class="sidebar-logo-link" href="' +
    projectPath("System/HTML/Dashboard.html") +
    '" aria-label="Go to CALIX dashboard">' +
    '<img class="sidebar-logo" src="' +
    projectPath("Assets/Logo1.png") +
    '" alt="CALIX Glass and Aluminum Fabrication"></a>' +
    '<nav class="nav-list" aria-label="Main navigation">' +
    '<a class="nav-link' +
    isActive("dashboard") +
    '" href="' +
    projectPath("System/HTML/Dashboard.html") +
    '">' +
    navIcon("home") +
    "Dashboard</a>" +
    (can("customers.lookup")
      ? '<a class="nav-link' +
        isActive("customers") +
        '" href="' +
        projectPath("Modules/Customers/HTML/Customers.html") +
        '">' +
        navIcon("customers") +
        "Customers</a>"
      : "") +
    (can("quotations.view") || can("quotations.manage") || can("projects.view")
      ? navGroup("quotation", "Quotation", "quotation", [
          ...(can("quotations.manage")
            ? [
                {
                  page: "quotation-create",
                  href: projectPath(
                    "Modules/Quotation/HTML/CreateQuotation.html",
                  ),
                  label: "Create a Quotation",
                },
              ]
            : []),
          ...(can("projects.view")
            ? [
                {
                  page: "projects",
                  href: projectPath("Modules/Quotation/HTML/Projects.html"),
                  label: "Quotations & Projects",
                },
              ]
            : []),
        ])
      : "") +
    (can("inventory.view") || can("inventory.manage")
      ? navGroup("inventory", "Operations · Inventory", "inventory", [
          ...(can("inventory.manage")
            ? [
                {
                  page: "inventory-create",
                  href: projectPath(
                    "Modules/Inventory/HTML/CreateInventory.html",
                  ),
                  label: "Create Inventory",
                },
              ]
            : []),
          ...(can("inventory.view")
            ? [
                {
                  page: "inventory-view",
                  href: projectPath(
                    "Modules/Inventory/HTML/ViewInventory.html",
                  ),
                  label: "View Inventory",
                },
              ]
            : []),
        ])
      : "") +
    (can("sales.view") || can("billing.view") || can("payments.view")
      ? navGroup("finance", "Finance", "sales", [
          ...(can("sales.view")
            ? [
                {
                  page: "sales-summary",
                  href: projectPath("Modules/Sales/HTML/ViewSales.html"),
                  label: "Sales",
                },
              ]
            : []),
          ...(can("billing.view")
            ? [
                {
                  page: "finance-billing",
                  href: projectPath("Modules/Finance/HTML/Billing.html"),
                  label: "Billing",
                },
              ]
            : []),
          ...(can("payments.view")
            ? [
                {
                  page: "finance-payments",
                  href: projectPath("Modules/Finance/HTML/Payments.html"),
                  label: "Payments",
                },
              ]
            : []),
        ])
      : "") +
    (can("reports.operational")
      ? '<a class="nav-link' +
        isActive("reports") +
        '" href="' +
        projectPath("Modules/Reports/HTML/Reports.html") +
        '">' +
        navIcon("reports") +
        "Reports</a>"
      : "") +
    (can("settings.manage")
      ? '<a id="settingsLink" class="nav-link' +
        isActive("settings") +
        '" href="' +
        projectPath("Modules/Settings/HTML/Settings.html") +
        '">' +
        navIcon("settings") +
        "Settings</a>"
      : "") +
    (role === "ADMIN"
      ? '<a id="trashbinLink" class="nav-link' +
        isActive("trashbin") +
        '" href="' +
        projectPath("Modules/Settings/HTML/Trashbin.html") +
        '">' +
        navIcon("deletion") +
        "Trashbin</a>"
      : "") +
    "</nav>" +
    '<div class="sidebar-footer"><button id="logoutButton" class="logout-button" type="button">' +
    navIcon("logout") +
    "Logout</button></div>";

  topbar.innerHTML =
    '<button id="menuButton" class="menu-button" type="button" aria-label="Open navigation" aria-expanded="false">☰</button>' +
    '<div class="header-search-container">' +
    '<label class="header-search">' +
    '<span class="sr-only">Search this workspace</span>' +
    '<svg class="topbar-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><path d="m20 20-4-4"></path></svg>' +
    '<input id="globalSearch" type="search" placeholder="Search CALIX records…" autocomplete="off" aria-controls="globalSearchResults" aria-expanded="false"></label>' +
    '<div id="globalSearchResults" class="global-search-results" role="listbox" aria-label="Search results" hidden></div></div>' +
    '<div class="topbar-actions"><button id="moduleHelpButton" class="module-help-button" type="button" aria-label="Open this module’s quick guide" title="Open this module’s quick guide"><span aria-hidden="true">?</span><span class="module-help-label">Help</span></button>' +
    '<div class="account"><div class="account-copy"><strong id="userRole"></strong><small>CALIX account</small></div>' +
    '<svg class="account-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"></circle><path d="M4 21a8 8 0 0 1 16 0"></path></svg></div></div>';

  document.getElementById("userRole").textContent =
    account.username + " · " + role;

  document.querySelectorAll("[data-permission]").forEach(function (element) {
    if (!can(element.dataset.permission)) element.remove();
  });

  const menuButton = document.getElementById("menuButton");
  const logoutButton = document.getElementById("logoutButton");
  const overlay = document.getElementById("sidebarOverlay");
  const globalSearch = document.getElementById("globalSearch");
  const globalSearchResults = document.getElementById("globalSearchResults");
  let searchTimer = 0;
  let searchRequest = 0;

  function closeSearchResults() {
    globalSearchResults.hidden = true;
    globalSearch.setAttribute("aria-expanded", "false");
  }

  function showSearchMessage(message) {
    globalSearchResults.replaceChildren();
    const status = document.createElement("div");
    status.className = "global-search-message";
    status.setAttribute("role", "status");
    status.textContent = message;
    globalSearchResults.appendChild(status);
    globalSearchResults.hidden = false;
    globalSearch.setAttribute("aria-expanded", "true");
  }

  function renderSearchResults(results, query) {
    globalSearchResults.replaceChildren();
    if (!results.length) {
      showSearchMessage("No matching records found.");
      return;
    }
    results.forEach(function (result, index) {
      const link = document.createElement("a");
      link.className = "global-search-result";
      link.href = projectPath(result.url);
      link.setAttribute("role", "option");
      link.id = "global-search-result-" + index;
      const label = document.createElement("strong");
      label.textContent = result.label;
      const type = document.createElement("span");
      type.className = "global-search-type";
      type.textContent = result.type;
      const detail = document.createElement("small");
      detail.textContent = result.detail || "";
      link.append(label, type, detail);
      link.addEventListener("click", function () {
        sessionStorage.setItem("calixGlobalSearchQuery", query);
      });
      globalSearchResults.appendChild(link);
    });
    globalSearchResults.hidden = false;
    globalSearch.setAttribute("aria-expanded", "true");
  }

  async function searchWorkspace(query, requestId) {
    try {
      const results = await CalixAPI.get(
        "global-search.php?q=" + encodeURIComponent(query),
      );
      if (requestId !== searchRequest || globalSearch.value.trim() !== query)
        return;
      renderSearchResults(Array.isArray(results) ? results : [], query);
    } catch (error) {
      if (requestId !== searchRequest) return;
      showSearchMessage(error.message || "Search is temporarily unavailable.");
    }
  }

  function closeSidebar() {
    sidebar.classList.remove("open");
    document.body.classList.remove("sidebar-open");
    menuButton.setAttribute("aria-expanded", "false");
    if (overlay) {
      overlay.classList.remove("show");
    }
  }

  function openSidebar() {
    sidebar.classList.add("open");
    document.body.classList.add("sidebar-open");
    menuButton.setAttribute("aria-expanded", "true");
    if (overlay) {
      overlay.classList.add("show");
    }
  }

  menuButton.addEventListener("click", function () {
    if (sidebar.classList.contains("open")) {
      closeSidebar();
    } else {
      openSidebar();
    }
  });

  if (overlay) {
    overlay.addEventListener("click", closeSidebar);
  }

  document.querySelectorAll(".nav-toggle").forEach(function (toggle) {
    toggle.addEventListener("click", function () {
      const group = toggle.closest(".nav-group");
      const willOpen = !group.classList.contains("open");

      document.querySelectorAll(".nav-group").forEach(function (otherGroup) {
        otherGroup.classList.remove("open");
        otherGroup
          .querySelector(".nav-toggle")
          .setAttribute("aria-expanded", "false");
      });

      if (willOpen) {
        group.classList.add("open");
        toggle.setAttribute("aria-expanded", "true");
      }
    });
  });

  document
    .querySelectorAll(".nav-link, .nav-submenu a")
    .forEach(function (link) {
      link.addEventListener("click", closeSidebar);
    });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
      closeSidebar();
    }
  });

  logoutButton.addEventListener("click", async function () {
    let logoutError = "";
    try {
      const result = await CalixAPI.post("auth.php?action=logout", {});
      if (!result || result.loggedOut !== true)
        throw new Error("The server did not confirm logout.");
    } catch (error) {
      console.error("CALIX server logout could not be confirmed.", error);
      logoutError =
        "CALIX could not confirm that your server session ended. Please sign in again; the server session may still be active.";
    }
    sessionStorage.removeItem("calixAccount");
    if (logoutError) sessionStorage.setItem("calixLogoutError", logoutError);
    else sessionStorage.removeItem("calixLogoutError");
    window.location.replace(projectPath("System/HTML/LoginPage.html"));
  });

  globalSearch.addEventListener("input", function () {
    const query = globalSearch.value.trim();
    window.clearTimeout(searchTimer);
    searchRequest += 1;
    window.dispatchEvent(
      new CustomEvent("calix:search", {
        detail: { query: query },
      }),
    );
    if (query.length < 2) {
      closeSearchResults();
      return;
    }
    showSearchMessage("Searching…");
    const requestId = searchRequest;
    searchTimer = window.setTimeout(function () {
      searchWorkspace(query, requestId);
    }, 250);
  });
  globalSearch.addEventListener("keydown", function (event) {
    const links = Array.from(
      globalSearchResults.querySelectorAll(".global-search-result"),
    );
    if (event.key === "ArrowDown" && links.length) {
      event.preventDefault();
      links[0].focus();
    } else if (event.key === "Escape") {
      closeSearchResults();
    } else if (event.key === "Enter" && links.length) {
      event.preventDefault();
      links[0].click();
    }
  });
  globalSearchResults.addEventListener("keydown", function (event) {
    const links = Array.from(
      globalSearchResults.querySelectorAll(".global-search-result"),
    );
    const index = links.indexOf(document.activeElement);
    if (event.key === "ArrowDown" && links.length) {
      event.preventDefault();
      links[(index + 1) % links.length].focus();
    } else if (event.key === "ArrowUp" && links.length) {
      event.preventDefault();
      if (index <= 0) globalSearch.focus();
      else links[index - 1].focus();
    } else if (event.key === "Escape") {
      closeSearchResults();
      globalSearch.focus();
    }
  });
  document.addEventListener("click", function (event) {
    if (!event.target.closest(".header-search-container")) closeSearchResults();
  });
  const carriedSearch = sessionStorage.getItem("calixGlobalSearchQuery");
  if (carriedSearch) {
    sessionStorage.removeItem("calixGlobalSearchQuery");
    globalSearch.value = carriedSearch;
    window.setTimeout(function () {
      window.dispatchEvent(
        new CustomEvent("calix:search", { detail: { query: carriedSearch } }),
      );
    }, 0);
  }

  const moduleTours = {
    dashboard: [
      {
        selector: ".dashboard-primary",
        title: "Operational overview",
        text: "Use these live summaries to move directly to quotations, projects, billing, or inventory.",
      },
      {
        selector: "#attentionPanel",
        title: "Attention required",
        text: "Review operational items that may need follow-up, such as pending work or exceptions.",
      },
      {
        selector: ".activity-panel",
        title: "Recent activity",
        text: "Trace recent records and actions visible to your role.",
      },
      {
        selector: "#quickAccessPanel",
        title: "Quick access",
        text: "Open commonly used customer, reporting, and administration areas.",
      },
      {
        selector: ".task-scope",
        title: "Choose your work",
        text: "Manage personal and shared tasks or notes here on the Dashboard.",
      },
      {
        selector: ".task-filters",
        title: "Find and save views",
        text: "Search and filter your tasks and notes, then save useful views.",
      },
      {
        selector: ".task-view-switch",
        title: "Change the layout",
        text: "Switch between list, board, and calendar layouts without leaving the Dashboard.",
      },
      {
        selector: "#addTaskButton",
        title: "Add task or note",
        text: "Create personal or shared work, assign a teammate, link a customer or project, and fill in custom fields.",
      },
    ],
    customers: [
      {
        selector: "#customerSearch",
        title: "Find a customer",
        text: "Search customer records before creating a new one to avoid duplicates.",
      },
      {
        selector: "#customerSort",
        title: "Organize the list",
        text: "Sort the customer list to find records more quickly.",
      },
      {
        selector: "#addCustomerButton",
        title: "Create a customer",
        text: "Add the customer once; quotations, projects, invoices, and payments can then reuse the same record.",
      },
      {
        selector: ".customer-table",
        title: "Customer records",
        text: "Open a customer’s actions to review or update that customer’s details.",
      },
    ],
    "quotation-create": [
      {
        selector: ".quotation-info-grid",
        title: "Customer and project",
        text: "Select an existing customer, then describe the proposed project and location. The quotation number is assigned by CALIX.",
      },
      {
        selector: "#quoteLines",
        title: "Quotation items",
        text: "Add the glass, aluminum, or services being quoted. Line items feed the quotation totals.",
      },
      {
        selector: ".quotation-totals",
        title: "Review the total",
        text: "Check subtotal, discount, VAT treatment, and grand total before submitting.",
      },
      {
        selector: "#paymentTerms",
        title: "Set expectations",
        text: "Confirm the payment terms and any additional terms that should appear on the quotation.",
      },
      {
        selector: "#quoteForm button[type='submit']",
        title: "Save or submit",
        text: "Save a draft while details are being prepared, then submit it for review when ready.",
      },
    ],
    projects: [
      {
        selector: "#quoteSearch",
        title: "Find a record",
        text: "Search across quotations and projects by customer, quotation number, or project name.",
      },
      {
        selector: "#quoteStatus",
        title: "Review quotations",
        text: "Filter quotations by workflow status. Rejected quotations stay in history and cannot become projects.",
      },
      {
        selector: "#projectFilter",
        title: "Focus on projects",
        text: "Use this filter to review project records and their current progress.",
      },
      {
        selector: ".unified-project-table",
        title: "Trace the workflow",
        text: "The table connects customer quotations to approved work and project status.",
      },
      {
        selector: ".page-actions a[data-permission='quotations.manage']",
        title: "Start a quotation",
        text: "Create a quotation for a customer. Only an approved quotation can be converted into a project.",
      },
    ],
    "inventory-create": [
      {
        selector: "#itemCode",
        title: "Identify the item",
        text: "Enter a unique item code and clear description so staff can recognize the stock.",
      },
      {
        selector: "#category",
        title: "Classify and measure",
        text: "Choose an inventory category and unit of measure that match how the business tracks this material.",
      },
      {
        selector: "#quantity",
        title: "Set stock levels",
        text: "Enter the current quantity and reorder level. Low-stock indicators use the reorder level.",
      },
      {
        selector: "#unitCost",
        title: "Record item values",
        text: "Enter the item's cost and selling price where available; these values inform inventory operations.",
      },
      {
        selector: "#inventoryForm button[type='submit']",
        title: "Save the item",
        text: "Save the inventory record, then use the inventory list to review stock and movements.",
      },
    ],
    "inventory-view": [
      {
        selector: "#inventorySearch",
        title: "Find inventory",
        text: "Search by item details to locate a stock record.",
      },
      {
        selector: "#categoryFilter",
        title: "Filter by category",
        text: "Narrow inventory to a type of material or supply.",
      },
      {
        selector: "#statusFilter",
        title: "Spot stock issues",
        text: "Filter low or out-of-stock items to prioritize replenishment.",
      },
      {
        selector: ".inventory-table",
        title: "Review stock and actions",
        text: "Inspect quantities and use the row actions for permitted inventory updates or stock movements.",
      },
    ],
    "finance-billing": [
      {
        selector: "#newInvoiceButton",
        title: "Create an invoice",
        text: "Invoices are created from approved projects. CALIX checks available contract value before saving.",
      },
      {
        selector: "#invoiceSearch",
        title: "Find an invoice",
        text: "Search invoice, customer, project, or quotation details.",
      },
      {
        selector: "#invoiceStatusFilter",
        title: "Monitor receivables",
        text: "Filter invoices by unpaid, partially paid, paid, or overdue status.",
      },
      {
        selector: "#invoiceRows",
        title: "Track billed amounts",
        text: "Review total, amount collected, remaining balance, and status. Payments update the invoice balance.",
      },
    ],
    "finance-payments": [
      {
        selector: "#newPaymentButton",
        title: "Record a receipt",
        text: "Record money received against an issued invoice; the outstanding balance is calculated automatically.",
      },
      {
        selector: "#paymentSearch",
        title: "Find a payment",
        text: "Search receipts using their reference, invoice, customer, or project.",
      },
      {
        selector: "#paymentRows",
        title: "Review collections",
        text: "Each row traces a received amount to its invoice and customer.",
      },
    ],
    "sales-summary": [
      {
        selector: ".sales-metrics",
        title: "Contract overview",
        text: "These figures summarize approved customer contract values, not invoice balances or cash received.",
      },
      {
        selector: "#salesSearch",
        title: "Find a contract",
        text: "Search sales records by customer, project, or source quotation.",
      },
      {
        selector: "#salesRows",
        title: "Trace sales to their source",
        text: "Each sales record comes from an approved quotation and connected project; billing and payments remain in their own modules.",
      },
    ],
    reports: [
      {
        selector: ".report-filter",
        title: "Choose a reporting period",
        text: "Set a date range and apply it to the available operational and financial summaries.",
      },
      {
        selector: ".report-summary-grid",
        title: "Read the summary",
        text: "Review quotation, project, inventory, and authorized billing indicators for the selected range.",
      },
      {
        selector: ".report-two-column",
        title: "Explore report details",
        text: "Use the detailed report sections to understand performance beyond the summary figures.",
      },
      {
        selector: ".report-print-options",
        title: "Choose what to print",
        text: "Select the report sections to include. All available sections are selected by default, and you can clear or select everything at once.",
      },
      {
        selector: "#printReport",
        title: "Print selected sections",
        text: "Open the print dialog with only your selected report sections and the current reporting period.",
      },
    ],
    settings: [
      {
        selector: "button.settings-tab[data-tab='users']",
        title: "Manage user accounts",
        text: "Add staff accounts and assign appropriate roles from the Users section.",
      },
      {
        selector: "button.settings-tab[data-tab='roles']",
        title: "Control access",
        text: "Review role permissions and grant only the module access each role requires.",
      },
      {
        selector: "button.settings-tab[data-tab='business']",
        title: "Set business defaults",
        text: "Configure defaults for customers, quotations, projects, inventory, billing, payments, and reports. Existing records are not rewritten.",
      },
    ],
    trashbin: [
      {
        selector: "#deletionSearch",
        title: "Find active records",
        text: "Search for a record before choosing an authorized deletion action.",
      },
      {
        selector: "#deletionModule",
        title: "Filter by module",
        text: "Narrow the active records list to a specific module.",
      },
      {
        selector: "#deletionBody",
        title: "Review active records",
        text: "Use the available row action to move an eligible record into deletion history.",
      },
      {
        selector: "#deletionHistory",
        title: "Restore or permanently remove",
        text: "Restore eligible records, or permanently delete a soft-deleted record after administrator confirmation. Permanent deletion cannot be undone.",
      },
      {
        selector: "#historyBody",
        title: "Review deletion history",
        text: "Check who deleted a record and when before restoring or permanently removing it.",
      },
    ],
  };
  const moduleHelpButton = document.getElementById("moduleHelpButton");
  const tourSteps = moduleTours[page];
  if (!tourSteps || !tourSteps.length) {
    moduleHelpButton.hidden = true;
  } else {
    let tourScrim = null;
    let tourCard = null;
    let tourTarget = null;
    let tourIndex = 0;
    let priorFocus = null;

    function visibleTourSteps() {
      return tourSteps.filter(function (step) {
        const target = document.querySelector(step.selector);
        if (!target || !target.getClientRects().length) return false;
        const style = window.getComputedStyle(target);
        return style.display !== "none" && style.visibility !== "hidden";
      });
    }

    function closeModuleTour() {
      if (tourTarget) tourTarget.classList.remove("module-tour-target");
      if (tourScrim) tourScrim.remove();
      if (tourCard) tourCard.remove();
      document.removeEventListener("keydown", handleTourKeys);
      tourTarget = null;
      tourScrim = null;
      tourCard = null;
      if (priorFocus && document.contains(priorFocus)) priorFocus.focus();
      priorFocus = null;
    }

    function positionTourCard(target) {
      const cardRect = tourCard.getBoundingClientRect();
      const targetRect = target.getBoundingClientRect();
      const margin = 16;
      let left = Math.max(
        margin,
        Math.min(targetRect.left, window.innerWidth - cardRect.width - margin),
      );
      let top = targetRect.bottom + 12;
      if (top + cardRect.height > window.innerHeight - margin)
        top = targetRect.top - cardRect.height - 12;
      top = Math.max(
        margin,
        Math.min(top, window.innerHeight - cardRect.height - margin),
      );
      if (window.matchMedia("(max-width: 650px)").matches) {
        left = margin;
        top = Math.max(margin, window.innerHeight - cardRect.height - margin);
      }
      tourCard.style.left = left + "px";
      tourCard.style.top = top + "px";
    }

    function showTourStep() {
      const steps = visibleTourSteps();
      if (!steps.length) {
        closeModuleTour();
        return;
      }
      tourIndex = Math.min(tourIndex, steps.length - 1);
      const step = steps[tourIndex];
      const target = document.querySelector(step.selector);
      if (tourTarget) tourTarget.classList.remove("module-tour-target");
      tourTarget = target;
      target.classList.add("module-tour-target");
      target.scrollIntoView({
        behavior: "auto",
        block: "center",
        inline: "nearest",
      });
      tourCard.replaceChildren();

      const heading = document.createElement("h2");
      heading.id = "moduleTourTitle";
      heading.textContent = step.title;
      const description = document.createElement("p");
      description.textContent = step.text;
      const progress = document.createElement("p");
      progress.className = "module-tour-progress";
      progress.setAttribute("aria-live", "polite");
      progress.textContent = "Step " + (tourIndex + 1) + " of " + steps.length;
      const actions = document.createElement("div");
      actions.className = "module-tour-actions";
      const skip = document.createElement("button");
      skip.type = "button";
      skip.className = "button secondary";
      skip.textContent = "Skip";
      skip.addEventListener("click", closeModuleTour);
      const buttonGroup = document.createElement("div");
      buttonGroup.className = "module-tour-button-group";
      if (tourIndex > 0) {
        const back = document.createElement("button");
        back.type = "button";
        back.className = "button secondary";
        back.textContent = "Back";
        back.addEventListener("click", function () {
          tourIndex -= 1;
          showTourStep();
        });
        buttonGroup.appendChild(back);
      }
      const next = document.createElement("button");
      next.type = "button";
      next.className = "button";
      next.textContent = tourIndex === steps.length - 1 ? "Finish" : "Next";
      next.addEventListener("click", function () {
        if (tourIndex === steps.length - 1) closeModuleTour();
        else {
          tourIndex += 1;
          showTourStep();
        }
      });
      buttonGroup.appendChild(next);
      actions.append(skip, buttonGroup);
      tourCard.append(heading, description, progress, actions);
      tourCard.setAttribute("aria-labelledby", heading.id);
      positionTourCard(target);
      next.focus();
    }

    function handleTourKeys(event) {
      if (event.key === "Escape") {
        event.preventDefault();
        closeModuleTour();
      } else if (event.key === "Tab" && tourCard) {
        const focusable = Array.from(tourCard.querySelectorAll("button"));
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    }

    moduleHelpButton.addEventListener("click", function () {
      if (tourCard) return;
      const steps = visibleTourSteps();
      if (!steps.length) return;
      priorFocus = document.activeElement;
      tourIndex = 0;
      tourScrim = document.createElement("div");
      tourScrim.className = "module-tour-scrim";
      tourScrim.setAttribute("aria-hidden", "true");
      tourCard = document.createElement("section");
      tourCard.className = "module-tour-card";
      tourCard.setAttribute("role", "dialog");
      tourCard.setAttribute("aria-modal", "true");
      document.body.append(tourScrim, tourCard);
      document.addEventListener("keydown", handleTourKeys);
      showTourStep();
    });
    window.addEventListener("resize", function () {
      if (tourCard && tourTarget) positionTourCard(tourTarget);
    });
  }

  const accessNotice = sessionStorage.getItem("calixAccessNotice");
  if (accessNotice && window.CalixUI) {
    sessionStorage.removeItem("calixAccessNotice");
    window.CalixUI.notify(accessNotice, "warning", { duration: 0 });
  }

  window.addEventListener("pageshow", function () {
    if (!sessionStorage.getItem("calixAccount"))
      window.location.replace(projectPath("System/HTML/LoginPage.html"));
  });
})();
