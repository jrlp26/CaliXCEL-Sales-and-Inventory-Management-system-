<?php

function ensureProjectForApprovedQuotation(mysqli $conn, int $quotationId, array $actor): array
{
    $quotation = one(
        $conn,
        "SELECT q.*,c.customer_name FROM quotations q
         JOIN customers c ON c.customer_id=q.customer_id
         WHERE q.quotation_id=? AND q.status='APPROVED' AND q.deleted_at IS NULL",
        'i',
        [$quotationId]
    );
    if (!$quotation) {
        throw new RuntimeException('The approved quotation could not be loaded.');
    }

    $existing = one($conn, 'SELECT project_id,deleted_at,contract_amount FROM projects WHERE quotation_id=? ORDER BY project_id DESC LIMIT 1', 'i', [$quotationId]);
    if ($existing) {
        if (!empty($existing['deleted_at'])) {
            return ['created' => false, 'projectId' => null, 'projectDeleted' => true];
        }
        ensureProjectSalesRecord($conn, (int)$existing['project_id'], $actor);
        ensureProjectPaymentMilestones($conn, (int)$existing['project_id'], (float)$existing['contract_amount']);
        return ['created' => false, 'projectId' => (int)$existing['project_id'], 'projectDeleted' => false];
    }

    $name = trim((string)($quotation['project_name'] ?? ''));
    if ($name === '') {
        $name = 'Project ' . $quotation['quotation_number'];
    }
    $description = 'Created automatically from approved quotation ' . $quotation['quotation_number'];
    $address = trim((string)($quotation['project_address'] ?? ''));
    $customerId = (int)$quotation['customer_id'];
    $amount = (float)$quotation['total_amount'];
    $durationDays = $quotation['estimated_duration_days'] !== null ? (int)$quotation['estimated_duration_days'] : null;
    $status = 'APPROVED';
    $notes = 'Approved quotation converted to project automatically.';

    try {
        $statement = $conn->prepare(
            'INSERT INTO projects(customer_id,quotation_id,project_name,description,project_address,start_date,deadline,contract_amount,estimated_duration_days,status,notes)
             VALUES(?,?,?,?,?,NULL,NULL,?,?,?,?)'
        );
        $statement->bind_param('iisssdiss', $customerId, $quotationId, $name, $description, $address, $amount, $durationDays, $status, $notes);
        $statement->execute();
        $projectId = (int)$statement->insert_id;
        $statement->close();
    } catch (mysqli_sql_exception $error) {
        if ((int)$error->getCode() !== 1062) {
            throw $error;
        }
        throw new RuntimeException('A project was linked to this quotation while it was being activated. Refresh the Projects page.');
    }

    ensureProjectSalesRecord($conn, $projectId, $actor);
    ensureProjectPaymentMilestones($conn, $projectId, $amount);
    auditEvent($conn, $actor, 'created_from_quotation', 'project', $projectId, ['quotation_id' => $quotationId], null, 'APPROVED');
    return ['created' => true, 'projectId' => $projectId, 'projectDeleted' => false];
}
