(function () {
    "use strict";

    const appScript = document.querySelector('script[src$="/app.js"],script[src$="app.js"]');
    const projectUrl = appScript ? new URL("../../", appScript.src) : new URL("../../", window.location.href);
    const url = path => new URL(path, projectUrl).href;
    const account = JSON.parse(sessionStorage.getItem("calixAccount") || "{}");
    const can = permission => account.role === "ADMIN" || (account.permissions || []).includes(permission);
    const $ = id => document.getElementById(id);
    const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
    const money = number => "₱" + Number(number || 0).toLocaleString("en-PH", {minimumFractionDigits:2, maximumFractionDigits:2});

    async function api(action, options = {}) {
        return CalixAPI.request("dashboard.php?action=" + encodeURIComponent(action), options);
    }

    function roleName() {
        const map = {ADMIN:"Administrator", SALES_STAFF:"Sales Clerk", INVENTORY_STAFF:"Inventory Clerk"};
        return map[account.role] || String(account.role || "CALIX User").replaceAll("_", " ");
    }

    function applyWelcome() {
        const role = roleName();
        let intro = "Good day, " + role + ". Here’s an overview of CALIX operations.";
        if (account.role === "SALES_STAFF") intro = "Good day, Sales Clerk. Review quotation, project, sales and customer activity available to your role.";
        if (account.role === "INVENTORY_STAFF") intro = "Good day, Inventory Clerk. Review stock activity, inventory alerts and the records available to your role.";
        $("dashboardIntro").textContent = intro;
        $("dashboardRole").textContent = role;
        $("dashboardDate").textContent = new Date().toLocaleDateString("en-PH", {weekday:"long", month:"long", day:"numeric", year:"numeric"});

        const statusPanel = document.querySelector(".status-panel");
        if (statusPanel && statusPanel.querySelectorAll(".status-section").length === 0) statusPanel.hidden = true;
    }

    let quickActionOptions = [];
    let quickActionDraft = [];

    function renderQuickLinks(actions) {
        const target = $("quickLinks");
        if (!target) return;
        target.innerHTML = actions.length
            ? actions.map(action => '<a href="' + esc(url(action.href)) + '"><strong>' + esc(action.label) +
                '</strong><span>' + esc(action.description) + '</span></a>').join("")
            : '<p class="empty-state">No quick actions yet. Customize this space to add your shortcuts.</p>';
    }

    function renderQuickActionEditor() {
        const target = $("quickActionEditor");
        if (!target) return;
        const usedByOthers = (index) => new Set(quickActionDraft.filter((_, itemIndex) => itemIndex !== index).map(item => item.key));
        target.innerHTML = quickActionDraft.map((item, index) => {
            const used = usedByOthers(index);
            const choices = quickActionOptions.filter(option => option.key === item.key || !used.has(option.key));
            return '<div class="quick-action-editor-row" data-index="' + index + '">' +
                '<label class="sr-only" for="quickActionLabel' + index + '">Button name</label>' +
                '<input id="quickActionLabel' + index + '" class="quick-action-label" maxlength="40" value="' + esc(item.label) + '" placeholder="Button name">' +
                '<label class="sr-only" for="quickActionRoute' + index + '">Open page</label>' +
                '<select id="quickActionRoute' + index + '" class="quick-action-route">' +
                    choices.map(option => '<option value="' + esc(option.key) + '"' + (option.key === item.key ? ' selected' : '') + '>' + esc(option.label) + '</option>').join("") +
                '</select>' +
                '<button type="button" class="button danger quick-action-remove" data-remove-quick-action="' + index + '" aria-label="Remove ' + esc(item.label || 'button') + '">Remove</button>' +
                '</div>';
        }).join("");
        $("addQuickAction").disabled = quickActionDraft.length >= 8 || quickActionDraft.length >= quickActionOptions.length;
    }

    async function loadQuickActions() {
        try {
            const data = await api("quick-actions");
            quickActionOptions = data.options || [];
            renderQuickLinks(data.actions || []);
        } catch (error) {
            $("quickLinks").innerHTML = '<p class="empty-state">' + esc(error.message || "Quick Actions could not be loaded.") + '</p>';
        }
    }

    function openQuickActions() {
        api("quick-actions").then(data => {
            quickActionOptions = data.options || [];
            quickActionDraft = (data.actions || []).map(action => ({key: action.key, label: action.label}));
            $("quickActionsError").textContent = "";
            renderQuickActionEditor();
            $("quickActionsDialog").showModal();
        }).catch(error => {
            $("quickActionsError").textContent = error.message || "Quick Actions could not be loaded.";
            $("quickActionsDialog").showModal();
        });
    }

    $("customizeQuickActions")?.addEventListener("click", openQuickActions);
    $("quickActionsDialog")?.querySelectorAll("[data-close-quick-actions]").forEach(button =>
        button.addEventListener("click", () => $("quickActionsDialog").close()));
    $("quickActionsDialog")?.addEventListener("click", event => {
        if (event.target === $("quickActionsDialog")) $("quickActionsDialog").close();
    });
    $("quickActionEditor")?.addEventListener("input", event => {
        const row = event.target.closest(".quick-action-editor-row");
        if (row && event.target.classList.contains("quick-action-label")) {
            quickActionDraft[Number(row.dataset.index)].label = event.target.value;
        }
    });
    $("quickActionEditor")?.addEventListener("change", event => {
        const row = event.target.closest(".quick-action-editor-row");
        if (!row || !event.target.classList.contains("quick-action-route")) return;
        const item = quickActionDraft[Number(row.dataset.index)];
        const route = quickActionOptions.find(option => option.key === event.target.value);
        item.key = event.target.value;
        if (route) item.label = route.label;
        renderQuickActionEditor();
    });
    $("quickActionEditor")?.addEventListener("click", event => {
        const button = event.target.closest("[data-remove-quick-action]");
        if (!button) return;
        quickActionDraft.splice(Number(button.dataset.removeQuickAction), 1);
        renderQuickActionEditor();
    });
    $("addQuickAction")?.addEventListener("click", () => {
        const used = new Set(quickActionDraft.map(item => item.key));
        const route = quickActionOptions.find(option => !used.has(option.key));
        if (!route || quickActionDraft.length >= 8) return;
        quickActionDraft.push({key: route.key, label: route.label});
        renderQuickActionEditor();
    });
    $("quickActionsForm")?.addEventListener("submit", async event => {
        event.preventDefault();
        const submit = $("saveQuickActions");
        submit.disabled = true;
        $("quickActionsError").textContent = "";
        try {
            await CalixAPI.request("dashboard.php?action=save-quick-actions", {
                method: "POST",
                body: JSON.stringify({actions: quickActionDraft})
            });
            $("quickActionsDialog").close();
            await loadQuickActions();
            if (window.CalixUI?.notify) window.CalixUI.notify("Quick Actions saved for your account.", "success");
        } catch (error) {
            $("quickActionsError").textContent = error.message || "Quick Actions could not be saved.";
        } finally {
            submit.disabled = false;
        }
    });

    function dateTime(value) {
        if (!value) return "—";
        const date = new Date(String(value).replace(" ", "T"));
        if (Number.isNaN(date.getTime())) return String(value);
        return date.toLocaleString("en-PH", {month:"short", day:"numeric", year:"numeric", hour:"numeric", minute:"2-digit"});
    }

    function setCards(data) {
        const cards = data.cards || {};
        const q = cards.quotations;
        if ($("quotePrimary")) {
            $("quotePrimary").textContent = q ? Number(q.total || 0).toLocaleString("en-PH") : "—";
            $("quoteSecondary").textContent = q
                ? Number(q.primary || 0).toLocaleString("en-PH") + " For Review"
                : "Data unavailable";
        }
        const p = cards.projects;
        if ($("projectPrimary")) {
            $("projectPrimary").textContent = p ? Number(p.total || 0).toLocaleString("en-PH") : "—";
            $("projectSecondary").textContent = p
                ? Number((data.projectStatus || {}).IN_PROGRESS || 0).toLocaleString("en-PH") + " In Progress"
                : "Data unavailable";
        }
        const i = cards.inventory;
        if ($("inventoryPrimary")) {
            $("inventoryPrimary").textContent = i ? Number(i.total || 0).toLocaleString("en-PH") : "—";
            $("inventorySecondary").textContent = i
                ? Number(i.primary || 0).toLocaleString("en-PH") + " Low Stock Items"
                : "Data unavailable";
        }
        const b = cards.billing;
        if ($("billingPrimary")) {
            $("billingPrimary").textContent = b ? money(b.primary) : "—";
            $("billingSecondary").innerHTML = b
                ? '<span><span>Billed</span><strong>' + money(b.billed) + '</strong></span>' +
                    '<span><span>Collected</span><strong>' + money(b.collected) + '</strong></span>' +
                    '<span><span>Overdue invoices</span><strong>' + Number(b.overdue || 0).toLocaleString("en-PH") + '</strong></span>'
                : '<span>Data unavailable</span>';
        }
    }

    function renderStatus(targetId, items, labels, classNames) {
        const target = $(targetId);
        if (!target) return;
        const keys = Object.keys(labels);
        const total = keys.reduce((sum, key) => sum + Number(items[key] || 0), 0);
        const breakdown = keys.map(key => {
            const count = Number(items[key] || 0);
            const percent = total ? Math.round((count / total) * 100) : 0;
            const className = classNames[key] || "";
            return {
                count,
                percent,
                className,
                label: labels[key]
            };
        });
        const list = breakdown.map(status =>
            '<div class="status-row">' +
                '<span class="status-swatch ' + esc(status.className) + '" aria-hidden="true"></span>' +
                '<span class="status-label">' + esc(status.label) + '</span>' +
                '<span class="status-count">' + status.count.toLocaleString("en-PH") + '</span>' +
                '<span class="status-percent">' + status.percent + '%</span></div>'
        ).join("");
        const statusColors = {
            draft: "#91a9b3",
            pending: "#e4ad55",
            approved: "#64ae87",
            rejected: "#df7770",
            "needs-scheduling": "#739fca",
            scheduled: "#8d8fd0",
            "in-progress": "#d5a64b",
            installation: "#54aab2",
            completed: "#64ae87",
            closed: "#9aa5aa",
            cancelled: "#df7770"
        };
        let angle = 0;
        const stops = breakdown.filter(status => status.count > 0).map(status => {
            const end = angle + status.count / total * 360;
            const stop = statusColors[status.className];
            const segment = stop + " " + angle + "deg " + end + "deg";
            angle = end;
            return segment;
        });
        const distributionLabel = breakdown
            .filter(status => status.count > 0)
            .map(status => status.label + ": " + status.count)
            .join(", ");
        const chartBackground = total ? "conic-gradient(" + stops.join(", ") + ")" : "#e8ecee";
        target.innerHTML =
            '<div class="status-card-content">' +
                '<div class="status-legend">' +
                    '<div class="status-total">' +
                        '<strong>' + total.toLocaleString("en-PH") + '</strong>' +
                        '<span>' + (total === 1 ? 'record total' : 'records total') + '</span>' +
                    '</div>' +
                    '<div class="status-list">' +
                        (list || '<p class="empty-state">No status data yet.</p>') +
                    '</div>' +
                '</div>' +
                '<div class="status-donut" role="img" aria-label="' +
                    esc(total ? "Status distribution. " + distributionLabel : "No records in any status") +
                    '" style="--status-chart:' + chartBackground + '">' +
                    '<span class="status-donut-total">' + total.toLocaleString("en-PH") + '</span>' +
                    '<span class="status-donut-caption">total</span>' +
                '</div>' +
            '</div>';
    }

    function renderActivity(rows) {
        const target = $("recentActivity");
        if (!target) return;
        target.innerHTML = rows.length ? rows.map(row => {
            const kind = String(row.kind || "activity").toLowerCase();
            return '<tr><td>' + dateTime(row.date) + '</td>' +
                '<td><span class="activity-module ' + esc(kind) + '">' + esc(kind.toUpperCase()) + '</span></td>' +
                '<td>' + esc(row.text) + '</td>' +
                '<td>' + esc(row.user || "—") + '</td>' +
                '<td><a class="view-activity" href="' + url(row.href) + '">View</a></td></tr>';
        }).join("") : '<tr><td colspan="5">No recent activity yet.</td></tr>';
    }

    function renderAttention(rows) {
        const target = $("attentionList");
        if (!target) return;
        if (!rows.length) {
            target.innerHTML = '<p class="empty-state">Nothing currently requires attention.</p>';
            return;
        }
        const symbols = {quotation:"!", inventory:"↓", project:"P", expiry:"!"};
        target.innerHTML = rows.map(row => '<a class="attention-row ' + esc(row.type || "") + '" href="' + url(row.href) + '">' +
            '<span class="attention-icon">' + esc(symbols[row.type] || "!") + '</span>' +
            '<span class="attention-count">' + Number(row.count || 0) + '</span>' +
            '<span class="attention-copy"><strong>' + esc(row.title) + '</strong><small>' + esc(row.detail || "") + '</small></span>' +
            '<span class="attention-arrow">›</span></a>').join("");
    }

    let summaryLoading = false;

    async function loadSummary() {
        if (summaryLoading) return;
        summaryLoading = true;
        const retry = $("dashboardRetry");
        if (retry) {
            retry.disabled = true;
            retry.textContent = "Loading…";
        }
        try {
            const data = await api("summary");
            setCards(data);
            renderStatus("quotationStatus", data.quotationStatus || {}, {DRAFT:"Draft",PENDING:"For Review",APPROVED:"Approved",REJECTED:"Rejected"}, {DRAFT:"draft",PENDING:"pending",APPROVED:"approved",REJECTED:"rejected"});
            renderStatus("projectStatus", data.projectStatus || {}, {APPROVED:"Approved",SCHEDULED:"Scheduled",IN_PROGRESS:"In Progress",FOR_INSTALLATION:"For Installation",COMPLETED:"Completed",CLOSED:"Closed",CANCELLED:"Cancelled"}, {APPROVED:"needs-scheduling",SCHEDULED:"scheduled",IN_PROGRESS:"in-progress",FOR_INSTALLATION:"installation",COMPLETED:"completed",CLOSED:"closed",CANCELLED:"cancelled"});
            renderActivity(data.recentActivity || []);
            renderAttention(data.attention || []);
            $("dashboardSummaryError").hidden = true;
        } catch (error) {
            for (const [primaryId, secondaryId] of [
                ["quotePrimary", "quoteSecondary"],
                ["projectPrimary", "projectSecondary"],
                ["billingPrimary", "billingSecondary"],
                ["inventoryPrimary", "inventorySecondary"]
            ]) {
                if ($(primaryId)) $(primaryId).textContent = "—";
                if ($(secondaryId)) $(secondaryId).textContent = "Unable to load";
            }
            $("dashboardSummaryErrorText").textContent = error.message || "Dashboard summary could not be loaded.";
            $("dashboardSummaryError").hidden = false;
            if ($("recentActivity")) $("recentActivity").innerHTML = '<tr><td colspan="5">' + esc(error.message) + '</td></tr>';
            if ($("attentionList")) $("attentionList").innerHTML = '<p class="empty-state">Dashboard data could not be loaded. Retry to try again.</p>';
        } finally {
            summaryLoading = false;
            if (retry) {
                retry.disabled = false;
                retry.textContent = "Retry";
            }
        }
    }

    applyWelcome();
    loadQuickActions();

    $("dashboardRetry").addEventListener("click", loadSummary);
    loadSummary();
}());
