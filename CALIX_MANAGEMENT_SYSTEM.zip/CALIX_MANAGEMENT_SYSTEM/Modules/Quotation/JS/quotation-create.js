(async () => {
    const $ = (id) => document.getElementById(id);
    const lines = $('quoteLines');
    const form = $('quoteForm');
    const errorBox = $('quoteError');
    const submitButton = form?.querySelector('button[type="submit"]');
    const params = new URLSearchParams(window.location.search);
    const editId = params.get('edit');
    const requestedCustomerId = params.get('customer');

    let customers = [];
    let defaults = {};
    let vatRate = 12;
    let saving = false;
    let dirty = false;
    let nextQuotationNumber = '';
    let nextQuotationYear = '';
    let numberPending = !editId;
    let numberRequestId = 0;
    let activeCustomerOption = -1;
    const drawingPreviews = new Map();

    if (!form || !lines) return;
    setSaving(false);

    function setError(message = '') {
        if (errorBox) errorBox.textContent = message;
    }

    function setSaving(isSaving) {
        saving = isSaving;
        if (!submitButton) return;
        submitButton.disabled = isSaving || numberPending || (!editId && !nextQuotationNumber);
        submitButton.textContent = isSaving
            ? (editId ? 'Updating…' : 'Saving…')
            : (editId ? 'Update Quotation' : 'Save Draft');
    }

    function markDirty() {
        if (!saving) dirty = true;
    }

    function parseDrawings(item = {}) {
        let drawings = [];
        if (Array.isArray(item.drawingImages)) drawings = item.drawingImages;
        else if (Array.isArray(item.drawing_images)) drawings = item.drawing_images;
        else if (typeof item.drawing_images === 'string' && item.drawing_images.trim()) {
            try {
                const parsed = JSON.parse(item.drawing_images);
                if (Array.isArray(parsed)) drawings = parsed;
            } catch (_) {}
        }
        if (!drawings.length && item.drawing_image) drawings = [item.drawing_image];
        return drawings.filter(Boolean).slice(0, 4);
    }

    function drawingUrl(path) {
        if (drawingPreviews.has(path)) return drawingPreviews.get(path);
        const match = String(path || '').match(/(?:^|\/)(drawing_[0-9]{8}_[0-9]{6}_[a-f0-9]{12}\.(?:jpg|png|webp))$/i);
        return match ? CalixAPI.url(`quotation-drawing.php?file=${encodeURIComponent(match[1])}`) : '';
    }

    window.addEventListener('pagehide', () => {
        drawingPreviews.forEach((url) => URL.revokeObjectURL(url));
        drawingPreviews.clear();
    });

    function drawingGridHTML(drawings) {
        const cells = [0, 1, 2, 3].map((index) => {
            const path = drawings[index];
            const src = drawingUrl(path);
            return `<div class="drawing-preview-slot ${src ? 'has-image' : ''}" data-slot="${index}">${src
                ? `<img src="${CalixUI.escape(src)}" alt="Drawing ${index + 1}">`
                : '<span>Empty</span>'}</div>`;
        }).join('');
        return `<div class="drawing-preview-grid">${cells}</div>`;
    }

    function updateDrawingPreview(card, paths) {
        const safePaths = paths.filter(Boolean).slice(0, 4);
        const hidden = card.querySelector('.drawing-paths');
        const grid = card.querySelector('.drawing-preview-grid');
        const clearButton = card.querySelector('.clear-drawings');
        const status = card.querySelector('.drawing-status');
        if (hidden) hidden.value = JSON.stringify(safePaths);
        if (grid) grid.outerHTML = drawingGridHTML(safePaths);
        if (clearButton) clearButton.hidden = safePaths.length === 0;
        if (status) status.textContent = safePaths.length
            ? `${safePaths.length} drawing${safePaths.length === 1 ? '' : 's'} attached.`
            : 'Optional · up to 4 JPG, PNG, or WEBP images · 5 MB each';
    }

    function refreshLineNumbers() {
        lines.querySelectorAll('.quotation-line-card').forEach((card, index) => {
            const title = card.querySelector('.quotation-line-title');
            if (title) title.textContent = `Item ${index + 1}`;
        });
    }

    function addLine(item = {}) {
        const drawings = parseDrawings(item);
        const card = document.createElement('article');
        card.className = 'quotation-line-card';
        card.innerHTML = `
            <div class="quotation-line-head">
                <strong class="quotation-line-title">Item</strong>
                <div class="line-card-actions">
                    <button class="text-button duplicate" type="button">Duplicate</button>
                    <button class="text-button danger remove" type="button">Remove</button>
                </div>
            </div>
            <div class="quotation-line-grid exact-quote-item-grid">
                <div class="form-group">
                    <label>Item Code</label>
                    <input class="item-code" maxlength="30" placeholder="W-01" value="${CalixUI.escape(item.item_code || item.itemCode || '')}">
                </div>
                <div class="form-group">
                    <label>Location</label>
                    <input class="location" maxlength="160" placeholder="GF - under stair" value="${CalixUI.escape(item.location || '')}">
                </div>
                <div class="form-group">
                    <label>Dimensions</label>
                    <input class="dimensions" maxlength="120" placeholder="2400 x 2100" value="${CalixUI.escape(item.dimensions || '')}">
                </div>
                <div class="form-group line-description">
                    <label>Description <span class="required">*</span></label>
                    <input class="desc" required maxlength="255" placeholder="Glass / aluminum work description" value="${CalixUI.escape(item.description || '')}">
                </div>
                <div class="form-group line-specification">
                    <label>Specification</label>
                    <textarea class="spec" rows="5" placeholder="Material, glass thickness, finish, hardware, and other specifications">${CalixUI.escape(item.specification || '')}</textarea>
                </div>
                <div class="form-group line-drawing">
                    <div class="field-label-row">
                        <label>Drawing / Reference Image</label>
                        <button class="quiet-link button-link clear-drawings" type="button" ${drawings.length ? '' : 'hidden'}>Clear</button>
                    </div>
                    <input class="drawing-paths" type="hidden" value='${CalixUI.escape(JSON.stringify(drawings))}'>
                    <div class="quote-drawing-upload multi">
                        <input class="drawing-files" type="file" accept="image/png,image/jpeg,image/webp" multiple>
                        <span class="drawing-status helper-text">${drawings.length
                            ? `${drawings.length} drawing${drawings.length === 1 ? '' : 's'} attached.`
                            : 'Optional · up to 4 JPG, PNG, or WEBP images · 5 MB each'}</span>
                    </div>
                    ${drawingGridHTML(drawings)}
                </div>
                <div class="form-group">
                    <label>Quantity <span class="required">*</span></label>
                    <input class="qty" type="number" min="1" step="1" value="${item.quantity || 1}" required>
                </div>
                <div class="form-group">
                    <label>Unit</label>
                    <input class="unit" maxlength="30" value="${CalixUI.escape(item.unit || 'set')}">
                </div>
                <div class="form-group">
                    <label>Unit Price <span class="required">*</span></label>
                    <input class="price" type="number" min="0" step="0.01" value="${item.unit_price ?? item.unitPrice ?? 0}" required>
                </div>
                <div class="form-group line-amount">
                    <label>Amount</label>
                    <strong class="line-total">₱0.00</strong>
                </div>
            </div>`;
        lines.append(card);
        refreshLineNumbers();
        calculateTotals();
        if (item.__focus !== false) card.querySelector('.desc')?.focus();
    }

    function calculateTotals() {
        let subtotal = 0;
        lines.querySelectorAll('.quotation-line-card').forEach((row) => {
            const quantity = Number(row.querySelector('.qty')?.value || 0);
            const price = Number(row.querySelector('.price')?.value || 0);
            const amount = Math.round((quantity * price + Number.EPSILON) * 100) / 100;
            const amountEl = row.querySelector('.line-total');
            if (amountEl) amountEl.textContent = CalixUI.money(amount);
            subtotal += amount;
        });
        const discount = Math.max(0, Math.min(100, Number($('discountPercent')?.value || 0)));
        const roundedSubtotal = Math.round((subtotal + Number.EPSILON) * 100) / 100;
        const discountAmount = Math.round((roundedSubtotal * discount / 100 + Number.EPSILON) * 100) / 100;
        const taxableAmount = Math.round((roundedSubtotal - discountAmount + Number.EPSILON) * 100) / 100;
        const treatment = $('vatType')?.value || 'VAT EXCLUSIVE';
        const vatAmount = treatment === 'VAT EXCLUSIVE'
            ? Math.round((taxableAmount * vatRate / 100 + Number.EPSILON) * 100) / 100
            : treatment === 'VAT INCLUSIVE'
                ? Math.round((taxableAmount * vatRate / (100 + vatRate) + Number.EPSILON) * 100) / 100
                : 0;
        const total = treatment === 'VAT EXCLUSIVE' ? taxableAmount + vatAmount : taxableAmount;
        $('quoteSubtotal').textContent = CalixUI.money(roundedSubtotal);
        $('quoteDiscount').textContent = CalixUI.money(discountAmount);
        $('quoteVatLabel').textContent = treatment === 'NON-VAT' ? 'VAT' : `VAT${treatment === 'VAT INCLUSIVE' ? ' included' : ''} (${vatRate}%)`;
        $('quoteVat').textContent = CalixUI.money(vatAmount);
        $('quoteTotal').textContent = CalixUI.money(total);
    }

    function customerLabel(customer) {
        return `${customer.customer_name || ''}${customer.company_name ? ' · ' + customer.company_name : ''}`.trim();
    }

    function setCustomerSuggestionsOpen(open) {
        const list = $('customerSuggestions');
        const input = $('quoteCustomerName');
        list.hidden = !open;
        input.setAttribute('aria-expanded', String(open));
        if (!open) {
            activeCustomerOption = -1;
            input.removeAttribute('aria-activedescendant');
        }
    }

    function renderCustomerSuggestions(open = false) {
        const list = $('customerSuggestions');
        const query = $('quoteCustomerName').value.trim().toLocaleLowerCase();
        const matches = customers.filter((customer) =>
            [customer.customer_name, customer.company_name, customer.contact_number, customer.email]
                .some((value) => String(value || '').toLocaleLowerCase().includes(query))
        );
        const shown = matches.slice(0, 50);
        list.innerHTML = shown.length
            ? shown.map((customer, index) => {
                const details = [customer.company_name, customer.contact_number, customer.email].filter(Boolean).join(' · ') || 'Customer';
                const selected = String(customer.customer_id) === $('quoteCustomer').value;
                return `<div id="customer-option-${CalixUI.escape(customer.customer_id)}" class="customer-suggestion${index === activeCustomerOption ? ' active' : ''}" role="option" aria-selected="${selected}" data-customer-option="${CalixUI.escape(customer.customer_id)}"><strong>${CalixUI.escape(customerLabel(customer))}</strong><small>${CalixUI.escape(details)}</small></div>`;
            }).join('')
            : '<div class="customer-suggestions-message">No matching customers. Try another search or add a new customer.</div>';
        if (matches.length > shown.length) {
            list.insertAdjacentHTML('beforeend', `<div class="customer-suggestions-message">Showing the first ${shown.length} results. Type more to narrow your search.</div>`);
        }
        setCustomerSuggestionsOpen(open);
    }

    function activateCustomerOption(index) {
        const list = $('customerSuggestions');
        const options = list.querySelectorAll('[data-customer-option]');
        if (!options.length) return;
        activeCustomerOption = Math.max(0, Math.min(index, options.length - 1));
        options.forEach((option, optionIndex) => option.classList.toggle('active', optionIndex === activeCustomerOption));
        const activeOption = options[activeCustomerOption];
        $('quoteCustomerName').setAttribute('aria-activedescendant', activeOption.id);
        activeOption.scrollIntoView({block: 'nearest'});
    }

    function getSelectedCustomer() {
        const typed = $('quoteCustomerName').value.trim().toLowerCase();
        const id = String($('quoteCustomer').value || '');
        if (id) {
            const byId = customers.find((customer) => String(customer.customer_id) === id);
            if (byId && [String(byId.customer_name || '').trim().toLowerCase(), customerLabel(byId).toLowerCase()].includes(typed)) return byId;
        }
        const exactMatches = customers.filter((customer) => {
            const customerName = String(customer.customer_name || '').trim().toLowerCase();
            return customerName === typed || customerLabel(customer).toLowerCase() === typed;
        });
        return exactMatches.length === 1 ? exactMatches[0] : null;
    }

    function showCustomerMeta(customer) {
        const meta = $('customerMeta');
        if (!meta) return;
        if (!customer) {
            meta.textContent = $('quoteCustomerName').value.trim() ? 'Select an existing customer or add a new one.' : '';
            return;
        }
        const parts = [customer.company_name, customer.contact_number, customer.email].filter(Boolean);
        meta.textContent = parts.join(' · ');
    }

    function selectCustomer(customer, updateAddress = false) {
        if (!customer) return;
        $('quoteCustomer').value = customer.customer_id;
        $('quoteCustomerName').value = customerLabel(customer);
        showCustomerMeta(customer);
        setCustomerSuggestionsOpen(false);
        if (updateAddress) $('quoteProjectAddress').value = customer.address || '';
    }

    function syncCustomer() {
        const match = getSelectedCustomer();
        $('quoteCustomer').value = match ? match.customer_id : '';
        showCustomerMeta(match);
        return match;
    }

    function datePlusDays(dateString, days) {
        const date = dateString ? new Date(`${dateString}T00:00:00`) : new Date();
        date.setDate(date.getDate() + (Number(days) || 0));
        return localDate(date);
    }

    function localDate(date) {
        const pad = value => String(value).padStart(2, '0');
        return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
    }

    async function refreshNextQuotationNumber() {
        if (editId) return;
        const year = ($('quotationDate').value || localDate(new Date())).slice(0, 4);
        const requestId = ++numberRequestId;
        numberPending = true;
        nextQuotationNumber = '';
        $('quotationNumber').value = '';
        setError('');
        setSaving(saving);
        try {
            const result = await CalixAPI.get(`quotations.php?action=next-number&year=${encodeURIComponent(year)}`);
            if (requestId !== numberRequestId) return;
            nextQuotationNumber = result.quotationNumber || '';
            nextQuotationYear = year;
            $('quotationNumber').value = nextQuotationNumber;
            if (!nextQuotationNumber) throw new Error('The next quotation number could not be assigned.');
        } catch (error) {
            if (requestId === numberRequestId) {
                nextQuotationNumber = '';
                nextQuotationYear = '';
                $('quotationNumber').value = '';
                setError(error?.message || 'The next quotation number could not be assigned.');
            }
        } finally {
            if (requestId === numberRequestId) {
                numberPending = false;
                setSaving(saving);
            }
        }
    }

    function itemFromCard(row) {
        let drawingImages = [];
        try { drawingImages = JSON.parse(row.querySelector('.drawing-paths')?.value || '[]'); } catch (_) {}
        return {
            itemCode: row.querySelector('.item-code')?.value.trim() || '',
            location: row.querySelector('.location')?.value.trim() || '',
            dimensions: row.querySelector('.dimensions')?.value.trim() || '',
            description: row.querySelector('.desc')?.value.trim() || '',
            specification: row.querySelector('.spec')?.value.trim() || '',
            drawingImages,
            quantity: Number(row.querySelector('.qty')?.value || 0),
            unit: row.querySelector('.unit')?.value.trim() || 'set',
            unitPrice: Number(row.querySelector('.price')?.value || 0),
            __focus: true
        };
    }

    function collectItems() {
        return [...lines.querySelectorAll('.quotation-line-card')].map(itemFromCard).map(({__focus, ...item}) => item);
    }

    function normalizedItemIdentity(item) {
        return [item.itemCode, item.description, item.dimensions, item.location, item.specification]
            .map(value => String(value || '').trim().replace(/\s+/g, ' ').toLowerCase());
    }

    function validateUniqueItems(items) {
        const seen = new Map();
        const duplicates = [];
        items.forEach((item, index) => {
            if (!String(item.description || '').trim()) return;
            const identity = JSON.stringify(normalizedItemIdentity(item));
            if (seen.has(identity)) duplicates.push([seen.get(identity), index + 1]);
            else seen.set(identity, index + 1);
        });
        const warning = $('quoteItemValidation');
        lines.querySelectorAll('.quotation-line-card').forEach(card => card.classList.remove('duplicate-quotation-item'));
        if (duplicates.length) {
            const indexes = [...new Set(duplicates.flat())];
            indexes.forEach(index => lines.querySelectorAll('.quotation-line-card')[index - 1]?.classList.add('duplicate-quotation-item'));
            warning.textContent = `Duplicate quotation item${duplicates.length > 1 ? 's' : ''} found on lines ${duplicates.map(pair => pair.join(' and ')).join('; ')}. Change the item details or remove the duplicate before saving.`;
            warning.hidden = false;
            return false;
        }
        warning.textContent = '';
        warning.hidden = true;
        if (errorBox?.textContent.startsWith('Duplicate quotation item')) setError('');
        return true;
    }

    function buildPayload() {
        const selectedCustomer = syncCustomer();
        const payload = {
            customerId: Number(selectedCustomer?.customer_id || 0),
            customerName: selectedCustomer?.customer_name || '',
            quotationNumber: $('quotationNumber').value.trim(),
            quotationDate: $('quotationDate').value,
            validUntil: $('validUntil').value,
            estimatedDurationDays: $('projectDurationDays').value || null,
            discountPercent: Number($('discountPercent').value || 0),
            projectName: $('quoteProjectName').value.trim(),
            projectAddress: $('quoteProjectAddress').value.trim(),
            paymentTerms: $('paymentTerms').value.trim(),
            vatType: $('vatType').value,
            fabricationTerms: $('fabricationTerms').value.trim(),
            acceptanceStatement: $('acceptanceStatement').value.trim(),
            authorizedRepresentatives: $('authorizedRepresentatives').value.trim(),
            notes: $('quoteNotes').value.trim(),
            items: collectItems()
        };
        if (editId) payload.quotationId = Number(editId);
        return payload;
    }

    function resetNewQuotation() {
        if (editId) return;
        lines.innerHTML = '';
        $('quoteItemValidation').textContent = '';
        $('quoteItemValidation').hidden = true;
        addLine({__focus: false});
        $('quotationDate').value = localDate(new Date());
        if (nextQuotationYear === $('quotationDate').value.slice(0, 4)) {
            $('quotationNumber').value = nextQuotationNumber;
        } else {
            refreshNextQuotationNumber();
        }
        $('validUntil').value = datePlusDays($('quotationDate').value, defaults.default_validity_days || 7);
        $('projectDurationDays').value = defaults.default_project_duration_days > 0 ? defaults.default_project_duration_days : '';
        $('paymentTerms').value = defaults.default_payment_terms || '';
        $('vatType').value = defaults.default_vat_type || 'VAT EXCLUSIVE';
        $('fabricationTerms').value = defaults.default_fabrication_terms || '';
        $('acceptanceStatement').value = defaults.default_acceptance_statement || '';
        $('authorizedRepresentatives').value = '';
        $('quoteNotes').value = '';
        $('quoteCustomerName').value = '';
        $('quoteCustomer').value = '';
        $('customerMeta').textContent = '';
        $('discountPercent').value = 0;
        $('advancedTerms').open = false;
        dirty = false;
        calculateTotals();
    }

    async function uploadDrawing(file) {
        const data = new FormData();
        data.append('file', file);
        return CalixAPI.upload('quotation-upload.php', data);
    }

    $('addLine').addEventListener('click', () => {
        addLine();
        markDirty();
    });

    lines.addEventListener('input', (event) => {
        if (!event.target.classList.contains('drawing-files')) markDirty();
        calculateTotals();
        validateUniqueItems(collectItems());
    });

    lines.addEventListener('click', (event) => {
        const card = event.target.closest('.quotation-line-card');
        if (!card) return;

        if (event.target.classList.contains('remove')) {
            if (lines.children.length === 1) {
                const fields = card.querySelectorAll('input:not([type="file"]), textarea');
                fields.forEach((field) => {
                    if (field.classList.contains('qty')) field.value = 1;
                    else if (field.classList.contains('unit')) field.value = 'set';
                    else if (field.classList.contains('price')) field.value = 0;
                    else if (!field.classList.contains('drawing-paths')) field.value = '';
                });
                updateDrawingPreview(card, []);
            } else {
                card.remove();
            }
            refreshLineNumbers();
            calculateTotals();
            validateUniqueItems(collectItems());
            markDirty();
            return;
        }

        if (event.target.classList.contains('duplicate')) {
            addLine(itemFromCard(card));
            validateUniqueItems(collectItems());
            markDirty();
            return;
        }

        if (event.target.classList.contains('clear-drawings')) {
            updateDrawingPreview(card, []);
            markDirty();
        }
    });

    lines.addEventListener('change', async (event) => {
        if (!event.target.classList.contains('drawing-files')) return;
        const input = event.target;
        const card = input.closest('.quotation-line-card');
        const status = card?.querySelector('.drawing-status');
        if (!card || !status) return;

        const chosen = [...(input.files || [])];
        if (!chosen.length) return;
        let existing = [];
        try { existing = JSON.parse(card.querySelector('.drawing-paths')?.value || '[]'); } catch (_) {}
        if (existing.length + chosen.length > 4) {
            status.textContent = `You can attach up to 4 drawings. ${existing.length} already attached.`;
            input.value = '';
            return;
        }

        input.disabled = true;
        status.textContent = `Uploading ${chosen.length} image${chosen.length === 1 ? '' : 's'}…`;
        const uploaded = [];
        try {
            for (const file of chosen) {
                const result = await uploadDrawing(file);
                uploaded.push(result.path);
                drawingPreviews.set(result.path, URL.createObjectURL(file));
                // Keep every successful upload visible immediately. If a later file fails,
                // the user does not lose the successfully uploaded references.
                updateDrawingPreview(card, existing.concat(uploaded));
            }
            if (uploaded.length) markDirty();
        } catch (error) {
            if (uploaded.length) markDirty();
            status.textContent = uploaded.length
                ? `${uploaded.length} image${uploaded.length === 1 ? '' : 's'} uploaded. ${error?.message || 'Another image failed to upload.'}`
                : (error?.message || 'Drawing upload failed.');
        } finally {
            input.disabled = false;
            input.value = '';
        }
    });

    $('discountPercent').addEventListener('input', () => {
        calculateTotals();
        markDirty();
    });
    $('quotationDate').addEventListener('change', () => {
        markDirty();
        refreshNextQuotationNumber();
    });
    $('vatType').addEventListener('change', () => {
        calculateTotals();
        markDirty();
    });

    const customerPicker = $('customerPicker');
    const customerInput = $('quoteCustomerName');
    const customerSuggestions = $('customerSuggestions');
    customerInput.addEventListener('focus', () => renderCustomerSuggestions(true));
    customerInput.addEventListener('input', () => {
        $('quoteCustomer').value = '';
        activeCustomerOption = -1;
        syncCustomer();
        renderCustomerSuggestions(true);
        markDirty();
    });
    $('quoteCustomerName').addEventListener('change', () => {
        const customer = syncCustomer();
        if (customer) selectCustomer(customer, true);
    });
    customerInput.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            if (customerSuggestions.hidden) renderCustomerSuggestions(true);
            const options = customerSuggestions.querySelectorAll('[data-customer-option]');
            if (options.length) {
                const next = activeCustomerOption < 0
                    ? (event.key === 'ArrowDown' ? 0 : options.length - 1)
                    : activeCustomerOption + (event.key === 'ArrowDown' ? 1 : -1);
                activateCustomerOption(Math.max(0, Math.min(next, options.length - 1)));
            }
        } else if (event.key === 'Enter' && !customerSuggestions.hidden && activeCustomerOption >= 0) {
            event.preventDefault();
            const option = customerSuggestions.querySelectorAll('[data-customer-option]')[activeCustomerOption];
            const customer = customers.find((item) => String(item.customer_id) === option?.dataset.customerOption);
            if (customer) {
                selectCustomer(customer, true);
                markDirty();
            }
        } else if (event.key === 'Escape' && !customerSuggestions.hidden) {
            event.preventDefault();
            setCustomerSuggestionsOpen(false);
        }
    });
    customerSuggestions.addEventListener('mousedown', (event) => {
        if (event.target.closest('[data-customer-option]')) event.preventDefault();
    });
    customerSuggestions.addEventListener('click', (event) => {
        const option = event.target.closest('[data-customer-option]');
        if (!option) return;
        const customer = customers.find((item) => String(item.customer_id) === option.dataset.customerOption);
        if (customer) {
            selectCustomer(customer, true);
            markDirty();
        }
    });
    document.addEventListener('pointerdown', (event) => {
        if (!customerPicker.contains(event.target)) setCustomerSuggestionsOpen(false);
    });
    customerPicker.addEventListener('focusout', () => {
        setTimeout(() => {
            if (!customerPicker.contains(document.activeElement)) setCustomerSuggestionsOpen(false);
        }, 0);
    });

    form.addEventListener('input', (event) => {
        if (!event.target.classList.contains('drawing-files')) markDirty();
    });

    form.addEventListener('reset', () => {
        setError('');
        setTimeout(resetNewQuotation, 0);
    });

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (saving) return;
        setError('');
        if (!validateUniqueItems(collectItems())) {
            setError($('quoteItemValidation').textContent);
            return;
        }
        if (!form.reportValidity()) return;

        const payload = buildPayload();
        if (!payload.customerId) {
            setError('Select an existing customer or add a new customer before saving.');
            $('quoteCustomerName').focus();
            return;
        }
        if (!payload.items.length) {
            setError('Add at least one quotation item before saving.');
            return;
        }

        try {
            setSaving(true);
            const endpoint = editId ? 'quotations.php?action=update' : 'quotations.php?action=create';
            const saved = await CalixAPI.post(endpoint, payload);
            dirty = false;
            const quotationId = saved?.quotation_id || editId;
            if (quotationId) {
                window.location.href = `Projects.html?quotation=${encodeURIComponent(quotationId)}`;
                return;
            }
            setError(editId ? 'Quotation updated successfully.' : 'Quotation saved successfully.');
        } catch (error) {
            setError(error?.message || 'The quotation could not be saved.');
        } finally {
            setSaving(false);
        }
    });

    const newCustomerButton = $('newCustomerButton');
    const quickCustomerDialog = $('quickCustomerDialog');
    const quickCustomerForm = $('quickCustomerForm');
    if (newCustomerButton && quickCustomerDialog && quickCustomerForm) {
        newCustomerButton.addEventListener('click', () => {
            quickCustomerForm.reset();
            $('quickCustomerError').textContent = '';
            quickCustomerDialog.showModal();
            setTimeout(() => $('quickCustomerName')?.focus(), 0);
        });
        quickCustomerDialog.querySelectorAll('[data-customer-close]').forEach((button) => {
            button.addEventListener('click', () => quickCustomerDialog.close());
        });
        quickCustomerForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const saveButton = quickCustomerForm.querySelector('button[type="submit"]');
            $('quickCustomerError').textContent = '';
            if (!quickCustomerForm.reportValidity()) return;
            const payload = {
                customerName: $('quickCustomerName').value.trim(),
                companyName: $('quickCompanyName').value.trim(),
                contactNumber: $('quickContactNumber').value.trim(),
                email: $('quickEmail').value.trim(),
                address: $('quickAddress').value.trim(),
                notes: $('quickNotes').value.trim()
            };
            try {
                saveButton.disabled = true;
                saveButton.textContent = 'Saving…';
                const customer = await CalixAPI.post('customers.php?action=save', payload);
                customers = await CalixAPI.get('customers.php?action=lookup');
                renderCustomerSuggestions();
                const savedCustomer = customers.find((item) => String(item.customer_id) === String(customer.customer_id)) || customer;
                selectCustomer(savedCustomer, true);
                quickCustomerDialog.close();
                markDirty();
            } catch (error) {
                $('quickCustomerError').textContent = error?.message || 'Customer could not be saved.';
            } finally {
                saveButton.disabled = false;
                saveButton.textContent = 'Save Customer';
            }
        });
    }

    window.addEventListener('beforeunload', (event) => {
        if (!dirty || saving) return;
        event.preventDefault();
        event.returnValue = '';
    });

    async function init() {
        setError('');
        try {
            const currentYear = localDate(new Date()).slice(0, 4);
            const [numberData, customerData, defaultData] = await Promise.all([
                CalixAPI.get(`quotations.php?action=next-number&year=${encodeURIComponent(currentYear)}`),
                CalixAPI.get('customers.php?action=lookup'),
                CalixAPI.get('quotations.php?action=defaults')
            ]);

            customers = customerData || [];
            defaults = defaultData || {};
            vatRate = Number(defaults.default_vat_rate ?? 12);
            nextQuotationNumber = numberData.quotationNumber || '';
            nextQuotationYear = currentYear;
            numberPending = false;
            setSaving(saving);
            renderCustomerSuggestions();

            if (editId) {
                const quotation = await CalixAPI.get(`quotations.php?action=get&id=${encodeURIComponent(editId)}`);
                document.querySelector('h1').textContent = 'Edit Quotation';
                if (submitButton) submitButton.textContent = 'Update Quotation';
                $('quotationNumber').value = quotation.quotation_number || '';
                const selected = customers.find((customer) => String(customer.customer_id) === String(quotation.customer_id));
                if (selected) selectCustomer(selected, false);
                else {
                    $('quoteCustomer').value = quotation.customer_id || '';
                    $('quoteCustomerName').value = quotation.customer_name || '';
                }
                $('quotationDate').value = (quotation.quotation_date || '').slice(0, 10);
                $('validUntil').value = quotation.valid_until || '';
                $('quoteProjectName').value = quotation.project_name || '';
                $('quoteProjectAddress').value = quotation.project_address || '';
                $('projectDurationDays').value = quotation.estimated_duration_days || '';
                $('discountPercent').value = quotation.discount_percent || 0;
                $('paymentTerms').value = quotation.payment_terms || '';
                $('vatType').value = quotation.vat_type || 'VAT EXCLUSIVE';
                vatRate = Number(quotation.vat_rate ?? defaults.default_vat_rate ?? 12);
                $('fabricationTerms').value = quotation.fabrication_terms || '';
                $('acceptanceStatement').value = quotation.acceptance_statement || '';
                $('authorizedRepresentatives').value = quotation.authorized_representatives || '';
                $('quoteNotes').value = quotation.notes || '';
                lines.innerHTML = '';
                (quotation.items || []).forEach((item) => addLine({...item, __focus: false}));
                if (!lines.children.length) addLine({__focus: false});
                calculateTotals();
                dirty = false;
                return;
            }

            resetNewQuotation();
            if (requestedCustomerId) {
                const customer = customers.find((item) => String(item.customer_id) === String(requestedCustomerId));
                if (customer) selectCustomer(customer, true);
            }
            dirty = false;
        } catch (error) {
            setError(error?.message || 'Quotation setup could not be loaded.');
        }
    }

    await init();
})();
