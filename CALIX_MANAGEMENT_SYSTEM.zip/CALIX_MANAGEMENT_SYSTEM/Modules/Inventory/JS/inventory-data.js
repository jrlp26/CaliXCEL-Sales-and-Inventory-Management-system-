(function () {
    "use strict";

    function normalizeItem(item) {
        return {
            id: item.id ? String(item.id) : "",
            itemCode: String(item.itemCode || "").trim().toUpperCase(),
            itemName: String(item.itemName || "").trim(),
            category: String(item.category || "Other").trim(),
            unit: String(item.unit || "Piece").trim(),
            quantity: Number(item.quantity) || 0,
            reorderLevel: Number(item.reorderLevel) || 0,
            unitCost: Number(item.unitCost) || 0,
            sellingPrice: Number(item.sellingPrice) || 0,
            supplier: String(item.supplier || "").trim(),
            location: String(item.location || "").trim(),
            description: String(item.description || "").trim(),
            createdAt: item.createdAt || "",
            updatedAt: item.updatedAt || ""
        };
    }

    async function listItems() {
        const items = await CalixAPI.get("inventory.php?action=list");
        return (items || []).map(normalizeItem);
    }

    async function getItem(id) {
        return normalizeItem(await CalixAPI.get("inventory.php?action=get&id=" + encodeURIComponent(id)));
    }

    async function createItem(data) {
        return normalizeItem(await CalixAPI.post("inventory.php?action=create", normalizeItem(data)));
    }

    async function updateItem(id, changes) {
        return normalizeItem(await CalixAPI.request("inventory.php?action=update&id=" + encodeURIComponent(id), {
            method: "PATCH",
            body: JSON.stringify(changes)
        }));
    }

    async function adjustStock(id, movement) {
        return normalizeItem(await CalixAPI.post("inventory.php?action=movement&id=" + encodeURIComponent(id), movement));
    }

    async function movementHistory(id) {
        return CalixAPI.get("inventory.php?action=history&id=" + encodeURIComponent(id));
    }

    async function projectOptions() {
        return CalixAPI.get("inventory.php?action=project-options");
    }

    async function defaults() {
        return CalixAPI.get("inventory.php?action=defaults");
    }

    function getStatus(item) {
        const quantity = Number(item.quantity);
        const reorderLevel = Number(item.reorderLevel);
        if (quantity <= 0) return "Out of Stock";
        if (quantity <= reorderLevel) return "Low Stock";
        return "In Stock";
    }

    async function getStats() {
        const items = await listItems();
        return items.reduce((stats, item) => {
            const status = getStatus(item);
            if (status === "Low Stock") stats.lowStock += 1;
            if (status === "Out of Stock") stats.outOfStock += 1;
            stats.inventoryValue += Number(item.quantity) * Number(item.unitCost);
            stats.totalItems += 1;
            return stats;
        }, {totalItems:0, lowStock:0, outOfStock:0, inventoryValue:0});
    }

    window.InventoryData = {listItems,getItem,createItem,updateItem,adjustStock,movementHistory,projectOptions,defaults,getStatus,getStats,usesDatabaseApi:true};
}());
