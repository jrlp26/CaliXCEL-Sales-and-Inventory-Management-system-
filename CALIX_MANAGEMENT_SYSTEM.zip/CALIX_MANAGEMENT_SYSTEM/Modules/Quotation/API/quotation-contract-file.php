<?php
require __DIR__ . '/../../../api/common.php';

requirePermission($conn, 'quotations.view');
$quotationId = (int)($_GET['id'] ?? 0);
if ($quotationId <= 0) sendError('Signed contract not found.', 404);
$row = one($conn, 'SELECT signed_contract_file FROM quotations WHERE quotation_id=? AND deleted_at IS NULL', 'i', [$quotationId]);
$file = (string)($row['signed_contract_file'] ?? '');
if (!$row || !preg_match('/^contract_' . $quotationId . '_[a-f0-9]{32}\.(pdf|jpg|png)$/', $file)) {
    sendError('Signed contract not found.', 404);
}

$path = __DIR__ . '/../uploads/signed_contracts/' . $file;
if (!is_file($path) || !is_readable($path)) sendError('Signed contract is unavailable.', 404);
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = $finfo ? (string)finfo_file($finfo, $path) : '';
if ($finfo) finfo_close($finfo);
$allowed = ['pdf'=>'application/pdf','jpg'=>'image/jpeg','png'=>'image/png'];
$extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
if (($allowed[$extension] ?? '') !== $mime) {
    error_log('Stored signed contract failed MIME validation for quotation ' . $quotationId . '.');
    sendError('Signed contract is unavailable.', 404);
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . (string)filesize($path));
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
