﻿<?php
require_once __DIR__ . '/common.php';

$action = $_GET['action'] ?? 'status';
$method = $_SERVER['REQUEST_METHOD'];

if ($action === 'login' && $method === 'POST') {
    $data = body();
    $username = trim((string)($data['username'] ?? ''));
    $password = (string)($data['password'] ?? '');

    if ($username === '' || $password === '') {
        sendError('Enter your username and password.', 422);
    }

    $deletedClause = dbColumnExists($conn, 'users', 'deleted_at') ? ' AND deleted_at IS NULL' : '';
    $user = one(
        $conn,
        'SELECT user_id, username, password, role, COALESCE(is_active, 1) is_active FROM users WHERE LOWER(username)=LOWER(?)' . $deletedClause . ' LIMIT 1',
        's',
        [$username]
    );

    if (!$user || !(int)$user['is_active']) {
        sendError('Incorrect username or password.', 401);
    }

    $stored = (string)$user['password'];
    $info = password_get_info($stored);
    $hashed = !empty($info['algo']);
    $valid = $hashed ? password_verify($password, $stored) : hash_equals($stored, $password);

    if (!$valid) {
        sendError('Incorrect username or password.', 401);
    }

    if (!$hashed || password_needs_rehash($stored, PASSWORD_DEFAULT)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare('UPDATE users SET password=? WHERE user_id=?');
        $stmt->bind_param('si', $hash, $user['user_id']);
        $stmt->execute();
        $stmt->close();
    }

    session_regenerate_id(true);
    $_SESSION['calix_user_id'] = (int)$user['user_id'];

    sendJson([
        'userId' => (int)$user['user_id'],
        'username' => $user['username'],
        'role' => $user['role'],
        'permissions' => userPermissions($conn, $user['role'])
    ]);
}

if ($action === 'logout' && $method === 'POST') {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'] ?? '', $params['secure'] ?? false, true);
    }
    session_destroy();
    sendJson(['loggedOut' => true]);
}

if ($action === 'status' && $method === 'GET') {
    $user = currentUser($conn);
    sendJson([
        'userId' => (int)$user['user_id'],
        'username' => $user['username'],
        'role' => $user['role'],
        'permissions' => userPermissions($conn, $user['role'])
    ]);
}

sendError('Authentication route not found.', 404);
