<?php
require __DIR__ . '/../../../api/common.php';

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];
$user = requirePermission($conn, 'tasks.view');
$userId = (int)$user['user_id'];

function tasksSchemaReady(mysqli $conn): bool {
    foreach (['todo_notes', 'todo_statuses'] as $table) {
        if (!dbTableExists($conn, $table)) return false;
    }
    foreach (['user_id', 'title', 'note_text', 'record_type', 'visibility', 'color', 'assigned_to', 'status_id', 'customer_id', 'project_id', 'priority', 'due_date', 'is_completed', 'deleted_at', 'updated_at'] as $column) {
        if (!dbColumnExists($conn, 'todo_notes', $column)) return false;
    }
    return true;
}

if (!tasksSchemaReady($conn)) {
    sendError('Tasks & Notes needs the current database upgrade. Back up the database, then import Database/calix_existing_database_upgrade.sql.', 503);
}

function taskStatuses(mysqli $conn, bool $includeInactive = false): array {
    $where = $includeInactive ? '' : ' WHERE is_active=1';
    return allRows($conn, "SELECT status_id,status_key,status_name,color,sort_order,is_completed,is_active FROM todo_statuses$where ORDER BY sort_order,status_id");
}

function taskCanEdit(array $task, array $user): bool {
    return (int)$task['user_id'] === (int)($user['user_id'] ?? 0);
}

function taskCanDelete(array $task, array $user): bool {
    if (($user['role'] ?? '') === 'ADMIN') return true;
    return (int)$task['user_id'] === (int)($user['user_id'] ?? 0)
        || ((string)($task['visibility'] ?? '') === 'TEAM' && in_array('tasks.manage', $user['permissions'] ?? [], true));
}

function taskRecord(mysqli $conn, int $id, bool $lock = false): ?array {
    return one(
        $conn,
        'SELECT todo_id,user_id,title,note_text,record_type,visibility,color,assigned_to,status_id,customer_id,project_id,priority,due_date,is_completed
         FROM todo_notes WHERE todo_id=? AND deleted_at IS NULL' . ($lock ? ' FOR UPDATE' : ''),
        'i',
        [$id]
    );
}

function validTaskDate(?string $date): bool {
    if ($date === null || $date === '') return true;
    $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    return $parsed !== false && $parsed->format('Y-m-d') === $date;
}

function validateTaskValues(mysqli $conn, $values): array {
    if (!is_array($values)) sendError('Custom field values must be a list.', 422);
    $fields = allRows($conn, 'SELECT field_id,field_name,field_type,options_json,is_required FROM todo_custom_fields WHERE is_active=1 ORDER BY sort_order,field_id');
    $fieldById = [];
    foreach ($fields as $field) $fieldById[(int)$field['field_id']] = $field;
    $normalized = [];

    foreach ($values as $key => $rawValue) {
        $fieldId = (int)$key;
        if (!isset($fieldById[$fieldId])) sendError('A custom field is no longer available. Reload the task form and try again.', 409);
        $field = $fieldById[$fieldId];
        if (is_array($rawValue) || is_object($rawValue)) sendError('Custom field values must be simple text values.', 422);
        $value = trim((string)$rawValue);
        if ($value === '' && (int)$field['is_required'] === 1) sendFieldError('custom_' . $fieldId, $field['field_name'] . ' is required.');
        if (strlen($value) > 500) sendFieldError('custom_' . $fieldId, $field['field_name'] . ' must be 500 characters or fewer.');

        if ($value !== '') {
            switch ($field['field_type']) {
                case 'NUMBER':
                    if (!is_numeric($value) || !is_finite((float)$value)) sendFieldError('custom_' . $fieldId, 'Enter a valid number for ' . $field['field_name'] . '.');
                    break;
                case 'DATE':
                    if (!validTaskDate($value)) sendFieldError('custom_' . $fieldId, 'Enter a valid date for ' . $field['field_name'] . '.');
                    break;
                case 'CHECKBOX':
                    if (!in_array($value, ['0', '1'], true)) sendFieldError('custom_' . $fieldId, 'Choose a valid value for ' . $field['field_name'] . '.');
                    break;
                case 'SELECT':
                    $options = json_decode((string)$field['options_json'], true);
                    if (!is_array($options) || !in_array($value, $options, true)) sendFieldError('custom_' . $fieldId, 'Choose an available option for ' . $field['field_name'] . '.');
                    break;
                case 'TEXT':
                    break;
                default:
                    sendError('A custom field has an unsupported type. Ask an administrator to review its configuration.', 500);
            }
        }
        if ($value !== '') $normalized[$fieldId] = $value;
    }

    foreach ($fields as $field) {
        $id = (int)$field['field_id'];
        if ((int)$field['is_required'] === 1 && !array_key_exists($id, $normalized)) {
            sendFieldError('custom_' . $id, $field['field_name'] . ' is required.');
        }
    }
    return $normalized;
}

function validateTaskLinks(mysqli $conn, array $user, int $customerId, int $projectId): array {
    $permissions = $user['permissions'] ?? [];
    if ($customerId > 0) {
        if (!in_array('customers.lookup', $permissions, true) && ($user['role'] ?? '') !== 'ADMIN') {
            sendError('You do not have permission to link a customer.', 403);
        }
        $customer = one($conn, 'SELECT customer_id FROM customers WHERE customer_id=? AND deleted_at IS NULL', 'i', [$customerId]);
        if (!$customer) sendFieldError('customer_id', 'Choose an active customer.');
    }
    if ($projectId > 0) {
        if (!in_array('projects.view', $permissions, true) && ($user['role'] ?? '') !== 'ADMIN') {
            sendError('You do not have permission to link a project.', 403);
        }
        $project = one($conn, 'SELECT project_id,customer_id FROM projects WHERE project_id=? AND deleted_at IS NULL', 'i', [$projectId]);
        if (!$project) sendFieldError('project_id', 'Choose an active project.');
        if ($customerId > 0 && (int)$project['customer_id'] !== $customerId) {
            sendFieldError('project_id', 'Choose a project belonging to the selected customer.');
        }
        $customerId = (int)$project['customer_id'];
    }
    return [$customerId ?: null, $projectId ?: null];
}

if ($action === 'options' && $method === 'GET') {
    sendJson(['statuses' => taskStatuses($conn)]);
}

if ($action === 'list' && $method === 'GET') {
    $scope = (string)($_GET['scope'] ?? 'all');
    if (!in_array($scope, ['all', 'personal', 'mine', 'team'], true)) sendError('Choose a valid notes view.', 422);
    $scopeSql = $scope === 'team'
        ? "t.visibility='TEAM'"
        : ($scope === 'personal'
            ? "(t.visibility='PERSONAL' AND t.user_id=?)"
            : ($scope === 'mine' ? '(t.user_id=? OR t.assigned_to=?)' : "(t.visibility='TEAM' OR t.user_id=? OR t.assigned_to=?)"));
    $types = in_array($scope, ['team'], true) ? '' : ($scope === 'personal' ? 'i' : 'ii');
    $params = $scope === 'team' ? [] : ($scope === 'personal' ? [$userId] : [$userId, $userId]);
    $rows = allRows(
        $conn,
        "SELECT t.todo_id,t.user_id,t.title,t.note_text,t.visibility,t.color,t.priority,t.due_date,t.is_completed,t.date_created,t.updated_at,
                COALESCE(NULLIF(owner.full_name,''),owner.username,'Former user') creator_name,
                CASE WHEN t.user_id=? THEN 1 ELSE 0 END is_owner,
                CASE WHEN t.visibility='TEAM' AND ?=1 THEN 1 ELSE 0 END can_manage
         FROM todo_notes t
         LEFT JOIN users owner ON owner.user_id=t.user_id
         WHERE t.deleted_at IS NULL AND t.record_type='NOTE' AND ($scopeSql)
         ORDER BY t.due_date IS NULL,t.due_date,t.updated_at DESC",
        'ii' . $types,
        array_merge([$userId, in_array('tasks.manage', $user['permissions'] ?? [], true) ? 1 : 0], $params)
    );
    sendJson(['notes' => $rows, 'can_manage' => in_array('tasks.manage', $user['permissions'] ?? [], true) || $user['role'] === 'ADMIN']);
}

if ($action === 'save' && $method === 'POST') {
    $editor = requirePermission($conn, 'tasks.manage');
    $body = body();
    $id = (int)($body['id'] ?? 0);
    $title = trim((string)($body['title'] ?? ''));
    $details = trim((string)($body['details'] ?? ''));
    $type = 'NOTE';
    $visibility = strtoupper((string)($body['visibility'] ?? 'PERSONAL'));
    $color = strtolower(trim((string)($body['color'] ?? '#fff2cc')));
    $allowedColors = ['#ffffff', '#fff2cc', '#dff2e1', '#dceeff', '#eee3ff', '#ffe2d6'];
    $priority = !empty($body['important']) ? 'HIGH' : 'NORMAL';
    $dueDate = trim((string)($body['due_date'] ?? ''));
    $isCompleted = !empty($body['completed']) ? 1 : 0;

    if ($title === '') sendFieldError('title', 'Enter a note or reminder title.');
    if (mb_strlen($title) > 180) sendFieldError('title', 'Keep the title under 180 characters.');
    if (mb_strlen($details) > 5000) sendFieldError('details', 'Keep the details under 5,000 characters.');
    if (!in_array($visibility, ['PERSONAL', 'TEAM'], true)) sendFieldError('visibility', 'Choose personal or team visibility.');
    if (!in_array($color, $allowedColors, true)) sendFieldError('color', 'Choose one of the available note colors.');
    if ($id <= 0 && $visibility === 'TEAM' && ($editor['role'] ?? '') !== 'ADMIN') {
        sendError('Only administrators can create team notes or reminders.', 403);
    }
    if (!validTaskDate($dueDate)) sendFieldError('due_date', 'Choose a valid due date.');
    $status = one($conn, 'SELECT status_id FROM todo_statuses WHERE is_active=1 AND is_completed=? ORDER BY sort_order,status_id LIMIT 1', 'i', [$isCompleted]);
    if (!$status) sendError($isCompleted ? 'An active completed status is required. Ask an administrator to check the database setup.' : 'An active reminder status is required. Ask an administrator to check the database setup.', 503);
    $statusId = (int)$status['status_id'];
    $dueDateValue = $dueDate !== '' ? $dueDate : null;
    $ownerId = (int)$editor['user_id'];
    $previous = null;

    $conn->begin_transaction();
    try {
        if ($id > 0) {
            $previous = taskRecord($conn, $id, true);
            if (!$previous || !taskCanEdit($previous, $editor)) {
                $conn->rollback();
                sendError('This task or note is not available for editing.', 404);
            }
            if ($visibility === 'TEAM' && ($editor['role'] ?? '') !== 'ADMIN' && $previous['visibility'] !== 'TEAM') {
                $conn->rollback();
                sendError('Only administrators can share a note with the team.', 403);
            }
            $statement = $conn->prepare(
                'UPDATE todo_notes SET title=?,note_text=?,record_type=?,visibility=?,color=?,assigned_to=NULL,status_id=?,customer_id=NULL,project_id=NULL,priority=?,due_date=?,is_completed=?,updated_at=CURRENT_TIMESTAMP
                 WHERE todo_id=? AND deleted_at IS NULL'
            );
            $statement->bind_param('sssssissii', $title, $details, $type, $visibility, $color, $statusId, $priority, $dueDateValue, $isCompleted, $id);
            $statement->execute();
            $statement->close();
            $todoId = $id;
        } else {
            $statement = $conn->prepare(
                'INSERT INTO todo_notes(user_id,title,note_text,record_type,visibility,color,assigned_to,status_id,customer_id,project_id,priority,due_date,is_completed)
                 VALUES(?,?,?,?,?,?,NULL,?,NULL,NULL,?,?,?)'
            );
            $statement->bind_param('isssssissi', $ownerId, $title, $details, $type, $visibility, $color, $statusId, $priority, $dueDateValue, $isCompleted);
            $statement->execute();
            $todoId = (int)$statement->insert_id;
            $statement->close();
        }

        auditEvent($conn, $editor, $id > 0 ? 'updated' : 'created', 'todo_note', $todoId, ['title' => $title, 'visibility' => $visibility, 'color' => $color], $previous['status_id'] ?? null, (string)$statusId);
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
    sendJson(['todo_id' => $todoId], $id > 0 ? 200 : 201);
}

if ($action === 'delete' && $method === 'POST') {
    $editor = requirePermission($conn, 'tasks.manage');
    $body = body();
    $id = (int)($body['id'] ?? 0);
    if ($id <= 0) sendError('Choose a valid task or note.', 422);
    $conn->begin_transaction();
    try {
        $task = taskRecord($conn, $id, true);
        if (!$task || !taskCanDelete($task, $editor)) {
            $conn->rollback();
            sendError('This task or note is not available for deletion.', 404);
        }
        if (!dbTableExists($conn, 'delete_history')) {
            $conn->rollback();
            sendError('Recoverable task deletion needs the current Trashbin database upgrade.', 503);
        }
        $snapshot = json_encode($task, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($snapshot === false) throw new RuntimeException('Task snapshot could not be encoded.');
        $module = 'todo_notes';
        $label = (string)$task['title'];
        $uid = (int)$editor['user_id'];
        $history = $conn->prepare('INSERT INTO delete_history(module,record_id,record_label,snapshot_json,deleted_by) VALUES(?,?,?,?,?)');
        $history->bind_param('sissi', $module, $id, $label, $snapshot, $uid);
        $history->execute();
        $history->close();
        $delete = $conn->prepare('UPDATE todo_notes SET deleted_at=CURRENT_TIMESTAMP,deleted_by=? WHERE todo_id=? AND deleted_at IS NULL');
        $delete->bind_param('ii', $uid, $id);
        $delete->execute();
        if ($delete->affected_rows < 1) throw new RuntimeException('The task was already deleted.');
        $delete->close();
        auditEvent($conn, $editor, 'deleted', 'todo_note', $id, ['title' => $label], (string)$task['status_id'], 'DELETED');
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
    sendJson(['deleted' => true, 'recoverable' => true]);
}

if ($action === 'save_statuses' && $method === 'POST') {
    $configurer = requirePermission($conn, 'tasks.configure');
    $body = body();
    $items = $body['statuses'] ?? null;
    if (!is_array($items) || count($items) < 2 || count($items) > 20) sendError('Add between 2 and 20 task statuses.', 422);
    $seen = [];
    $activeOpen = 0;
    $activeDone = 0;
    foreach ($items as $item) {
        if (!is_array($item)) sendError('A status entry is invalid.', 422);
        $name = trim((string)($item['name'] ?? ''));
        $color = (string)($item['color'] ?? '');
        $isActive = !empty($item['is_active']);
        $isCompleted = !empty($item['is_completed']);
        $key = mb_strtolower($name);
        if ($name === '' || mb_strlen($name) > 60 || isset($seen[$key])) sendError('Status names must be unique and 1–60 characters long.', 422);
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) sendError('Choose a valid status color.', 422);
        $seen[$key] = true;
        if ($isActive) $isCompleted ? $activeDone++ : $activeOpen++;
    }
    if (!$activeOpen || !$activeDone) sendError('Keep at least one active open status and one active completed status.', 422);

    $conn->begin_transaction();
    try {
        $keepIds = [];
        $order = 0;
        foreach ($items as $item) {
            $id = (int)($item['id'] ?? 0);
            $name = trim((string)$item['name']);
            $color = (string)$item['color'];
            $isCompleted = !empty($item['is_completed']) ? 1 : 0;
            $isActive = !empty($item['is_active']) ? 1 : 0;
            if ($id > 0) {
                $old = one($conn, 'SELECT status_id FROM todo_statuses WHERE status_id=? FOR UPDATE', 'i', [$id]);
                if (!$old) throw new DomainException('A status was removed by another administrator. Reload the page and try again.', 409);
                if (!$isActive) {
                    $usage = one($conn, 'SELECT COUNT(*) c FROM todo_notes WHERE status_id=? AND deleted_at IS NULL', 'i', [$id]);
                    if ((int)($usage['c'] ?? 0) > 0) throw new DomainException('Move tasks away from "' . $name . '" before deactivating it.', 409);
                }
                $update = $conn->prepare('UPDATE todo_statuses SET status_name=?,color=?,sort_order=?,is_completed=?,is_active=? WHERE status_id=?');
                $update->bind_param('ssiiii', $name, $color, $order, $isCompleted, $isActive, $id);
                $update->execute();
                $update->close();
                $keepIds[] = $id;
            } else {
                $insert = $conn->prepare('INSERT INTO todo_statuses(status_name,color,sort_order,is_completed,is_active) VALUES(?,?,?,?,?)');
                $insert->bind_param('ssiii', $name, $color, $order, $isCompleted, $isActive);
                $insert->execute();
                $keepIds[] = (int)$insert->insert_id;
                $insert->close();
            }
            $order++;
        }
        $allStatuses = taskStatuses($conn, true);
        foreach ($allStatuses as $status) {
            $id = (int)$status['status_id'];
            if (in_array($id, $keepIds, true) || (int)$status['is_active'] !== 1) continue;
            $usage = one($conn, 'SELECT COUNT(*) c FROM todo_notes WHERE status_id=? AND deleted_at IS NULL', 'i', [$id]);
            if ((int)($usage['c'] ?? 0) > 0) throw new DomainException('Move tasks away from "' . $status['status_name'] . '" before removing it from the workflow.', 409);
            $deactivate = $conn->prepare('UPDATE todo_statuses SET is_active=0 WHERE status_id=?');
            $deactivate->bind_param('i', $id);
            $deactivate->execute();
            $deactivate->close();
        }
        $syncStatus = $conn->prepare('UPDATE todo_notes n JOIN todo_statuses s ON s.status_id=n.status_id SET n.is_completed=s.is_completed WHERE n.deleted_at IS NULL');
        $syncStatus->execute();
        $syncStatus->close();
        auditEvent($conn, $configurer, 'configured', 'todo_statuses', 0, ['count' => count($items)]);
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        if ($e instanceof DomainException) sendError($e->getMessage(), $e->getCode() ?: 409);
        throw $e;
    }
    sendJson(taskStatuses($conn));
}

if ($action === 'save_fields' && $method === 'POST') {
    $configurer = requirePermission($conn, 'tasks.configure');
    $body = body();
    $items = $body['fields'] ?? null;
    if (!is_array($items) || count($items) > 30) sendError('Add no more than 30 custom fields.', 422);
    $allowedTypes = ['TEXT', 'NUMBER', 'DATE', 'SELECT', 'CHECKBOX'];
    $seen = [];
    foreach ($items as $item) {
        if (!is_array($item)) sendError('A custom field is invalid.', 422);
        $name = trim((string)($item['name'] ?? ''));
        $type = strtoupper((string)($item['type'] ?? ''));
        $key = mb_strtolower($name);
        if ($name === '' || mb_strlen($name) > 80 || isset($seen[$key])) sendError('Custom field names must be unique and 1–80 characters long.', 422);
        if (!in_array($type, $allowedTypes, true)) sendError('Choose a supported custom field type.', 422);
        $seen[$key] = true;
        if ($type === 'SELECT') {
            $options = $item['options'] ?? [];
            if (!is_array($options)) sendFieldError('field_options', 'Add valid choices for the select field.');
            $options = array_values(array_unique(array_filter(array_map(static fn($value) => trim((string)$value), $options))));
            if (count($options) < 2 || count($options) > 30) sendFieldError('field_options', 'A select field needs between 2 and 30 choices.');
        }
    }

    $conn->begin_transaction();
    try {
        $keepIds = [];
        $order = 0;
        foreach ($items as $item) {
            $id = (int)($item['id'] ?? 0);
            $name = trim((string)$item['name']);
            $type = strtoupper((string)$item['type']);
            $required = !empty($item['is_required']) ? 1 : 0;
            $active = !array_key_exists('is_active', $item) || !empty($item['is_active']) ? 1 : 0;
            $options = $type === 'SELECT'
                ? json_encode(array_values(array_unique(array_filter(array_map(static fn($value) => trim((string)$value), $item['options'] ?? [])))), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                : null;
            if ($id > 0) {
                $exists = one($conn, 'SELECT field_id FROM todo_custom_fields WHERE field_id=? FOR UPDATE', 'i', [$id]);
                if (!$exists) throw new DomainException('A custom field was removed by another administrator. Reload and try again.', 409);
                $update = $conn->prepare('UPDATE todo_custom_fields SET field_name=?,field_type=?,options_json=?,is_required=?,is_active=?,sort_order=? WHERE field_id=?');
                $update->bind_param('sssiiii', $name, $type, $options, $required, $active, $order, $id);
                $update->execute();
                $update->close();
                $keepIds[] = $id;
            } else {
                $key = 'field_' . bin2hex(random_bytes(8));
                $createdBy = (int)$configurer['user_id'];
                $insert = $conn->prepare('INSERT INTO todo_custom_fields(field_key,field_name,field_type,options_json,is_required,is_active,sort_order,created_by) VALUES(?,?,?,?,?,?,?,?)');
                $insert->bind_param('ssssiiii', $key, $name, $type, $options, $required, $active, $order, $createdBy);
                $insert->execute();
                $keepIds[] = (int)$insert->insert_id;
                $insert->close();
            }
            $order++;
        }
        foreach (allRows($conn, 'SELECT field_id FROM todo_custom_fields WHERE is_active=1') as $field) {
            $id = (int)$field['field_id'];
            if (in_array($id, $keepIds, true)) continue;
            $deactivate = $conn->prepare('UPDATE todo_custom_fields SET is_active=0 WHERE field_id=?');
            $deactivate->bind_param('i', $id);
            $deactivate->execute();
            $deactivate->close();
        }
        auditEvent($conn, $configurer, 'configured', 'todo_custom_fields', 0, ['count' => count($items)]);
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        if ($e instanceof DomainException) sendError($e->getMessage(), $e->getCode() ?: 409);
        throw $e;
    }
    sendJson(allRows($conn, 'SELECT field_id,field_name,field_type,options_json,is_required,sort_order FROM todo_custom_fields WHERE is_active=1 ORDER BY sort_order,field_id'));
}

if ($action === 'views' && $method === 'GET') {
    $views = allRows($conn, 'SELECT view_id,view_name,view_mode,filters_json FROM todo_saved_views WHERE user_id=? ORDER BY view_name', 'i', [$userId]);
    foreach ($views as &$view) {
        $view['filters'] = json_decode((string)$view['filters_json'], true) ?: [];
        unset($view['filters_json']);
    }
    unset($view);
    sendJson($views);
}

if ($action === 'save_view' && $method === 'POST') {
    $body = body();
    $id = (int)($body['id'] ?? 0);
    $name = trim((string)($body['name'] ?? ''));
    $mode = (string)($body['mode'] ?? 'list');
    $filters = $body['filters'] ?? [];
    if ($name === '' || mb_strlen($name) > 60) sendFieldError('view_name', 'Saved view names must be 1–60 characters long.');
    if (!in_array($mode, ['list', 'board', 'calendar'], true)) sendError('Choose a valid saved view layout.', 422);
    if (!is_array($filters)) sendError('Saved view filters are invalid.', 422);
    foreach (['search', 'scope', 'record_type', 'status_id', 'priority'] as $key) {
        if (isset($filters[$key]) && !is_scalar($filters[$key])) sendError('Saved view filters are invalid.', 422);
    }
    $filtersJson = json_encode($filters, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($filtersJson === false || strlen($filtersJson) > 5000) sendError('Saved view settings are too large.', 422);
    if ($id > 0) {
        $update = $conn->prepare('UPDATE todo_saved_views SET view_name=?,view_mode=?,filters_json=? WHERE view_id=? AND user_id=?');
        $update->bind_param('sssii', $name, $mode, $filtersJson, $id, $userId);
        $update->execute();
        $changed = $update->affected_rows;
        $update->close();
        if (!$changed && !one($conn, 'SELECT view_id FROM todo_saved_views WHERE view_id=? AND user_id=?', 'ii', [$id, $userId])) sendError('Saved view not found.', 404);
    } else {
        $insert = $conn->prepare('INSERT INTO todo_saved_views(user_id,view_name,view_mode,filters_json) VALUES(?,?,?,?)');
        $insert->bind_param('isss', $userId, $name, $mode, $filtersJson);
        $insert->execute();
        $id = (int)$insert->insert_id;
        $insert->close();
    }
    sendJson(['view_id' => $id]);
}

if ($action === 'delete_view' && $method === 'POST') {
    $body = body();
    $id = (int)($body['id'] ?? 0);
    if ($id <= 0) sendError('Choose a saved view to delete.', 422);
    $delete = $conn->prepare('DELETE FROM todo_saved_views WHERE view_id=? AND user_id=?');
    $delete->bind_param('ii', $id, $userId);
    $delete->execute();
    $changed = $delete->affected_rows;
    $delete->close();
    if ($changed < 1) sendError('Saved view not found.', 404);
    sendJson(['deleted' => true]);
}

sendError('Tasks & Notes route not found.', 404);
