<?php
require __DIR__ . '/../../../api/common.php';

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

function projectRow(mysqli $conn, int $id): array
{
    $row = one($conn, "SELECT p.*, c.customer_name, c.company_name, q.quotation_number
        FROM projects p
        JOIN customers c ON c.customer_id=p.customer_id
        JOIN quotations q ON q.quotation_id=p.quotation_id
        WHERE p.project_id=? AND p.deleted_at IS NULL", 'i', [$id]);
    if (!$row) sendError('Project not found.', 404);
    $downPayment=projectMilestoneStatus($conn,$id,'DOWN_PAYMENT');
    $row['down_payment_amount']=(float)($downPayment['amount']??0);
    $row['down_payment_collected']=(float)($downPayment['collected']??0);
    $row['down_payment_paid']=(bool)($downPayment['paid']??false);
    return $row;
}

function projectDate(string $value, string $label): string
{
    $value = trim($value);
    if ($value === '') return '';
    $date = DateTime::createFromFormat('Y-m-d', $value);
    if (!$date || $date->format('Y-m-d') !== $value) sendError("Enter a valid $label.", 422);
    return $value;
}

function validateProjectFields(string $name, string $address, string $description, string $notes, string $start, string $deadline): void
{
    if ($name === '') sendError('Project name is required.', 422);
    if (mb_strlen($name) > 150) sendError('Project name must be 150 characters or fewer.', 422);
    if (mb_strlen($address) > 255) sendError('Project location must be 255 characters or fewer.', 422);
    if (mb_strlen($description) > 5000) sendError('Project description is too long.', 422);
    if (mb_strlen($notes) > 5000) sendError('Project notes are too long.', 422);
    if ($start !== '' && $deadline !== '' && $deadline < $start) sendError('Project deadline cannot be earlier than the start date.', 422);
}

if ($action === 'list' && $method === 'GET') {
    requirePermission($conn, 'projects.view');
    $projects=allRows($conn, "SELECT p.*, c.customer_name, c.company_name, q.quotation_number
        FROM projects p
        JOIN customers c ON c.customer_id=p.customer_id
        JOIN quotations q ON q.quotation_id=p.quotation_id
        WHERE p.deleted_at IS NULL AND q.deleted_at IS NULL AND q.status='APPROVED'
        ORDER BY p.project_id DESC");
    foreach ($projects as &$project) {
        $downPayment=projectMilestoneStatus($conn,(int)$project['project_id'],'DOWN_PAYMENT');
        $project['down_payment_amount']=(float)($downPayment['amount']??0);
        $project['down_payment_collected']=(float)($downPayment['collected']??0);
        $project['down_payment_paid']=(bool)($downPayment['paid']??false);
    }
    unset($project);
    sendJson($projects);
}

if ($action === 'get' && $method === 'GET') {
    requirePermission($conn, 'projects.view');
    sendJson(projectRow($conn, (int)($_GET['id'] ?? 0)));
}

if ($action === 'eligible-quotes' && $method === 'GET') {
    requirePermission($conn, 'projects.manage');
    sendJson(allRows($conn, "SELECT q.quotation_id,q.quotation_number,q.customer_id,q.project_name,q.project_address,q.total_amount,c.customer_name
        FROM quotations q
        JOIN customers c ON c.customer_id=q.customer_id
        LEFT JOIN projects p ON p.quotation_id=q.quotation_id
        WHERE q.status='APPROVED' AND q.deleted_at IS NULL AND c.deleted_at IS NULL AND p.project_id IS NULL
        ORDER BY q.quotation_id DESC"));
}

if ($action === 'create' && $method === 'POST') {
    $user = requirePermission($conn, 'projects.manage');
    if (!dbTableExists($conn, 'project_payment_milestones')) {
        sendError('Project billing milestones are not installed. Back up the database, then apply Database/calix_existing_database_upgrade.sql before creating projects.', 503);
    }
    $body = body();
    $quotationId = (int)($body['quotationId'] ?? 0);
    $quotation = one($conn, "SELECT q.* FROM quotations q
        JOIN customers c ON c.customer_id=q.customer_id
        WHERE q.quotation_id=? AND q.status='APPROVED' AND q.deleted_at IS NULL AND c.deleted_at IS NULL", 'i', [$quotationId]);
    if (!$quotation) sendError('Choose an approved quotation.', 422);

    $existing = one($conn, 'SELECT project_id,deleted_at FROM projects WHERE quotation_id=? ORDER BY project_id DESC LIMIT 1', 'i', [$quotationId]);
    if ($existing) {
        if (!empty($existing['deleted_at'])) sendError('A deleted project already belongs to this quotation. Restore it from the Trashbin.', 409);
        sendError('A project already exists for this quotation.', 409);
    }

    $name = trim((string)($body['projectName'] ?? $quotation['project_name'] ?? ''));
    if ($name === '') $name = 'Project ' . $quotation['quotation_number'];
    $description = trim((string)($body['description'] ?? ''));
    $address = trim((string)($body['projectAddress'] ?? $quotation['project_address'] ?? ''));
    $start = projectDate((string)($body['startDate'] ?? ''), 'start date');
    $deadline = projectDate((string)($body['deadline'] ?? ''), 'deadline');
    $notes = trim((string)($body['notes'] ?? ''));
    validateProjectFields($name, $address, $description, $notes, $start, $deadline);

    $customerId = (int)$quotation['customer_id'];
    $amount = (float)$quotation['total_amount'];
    $durationDays = $quotation['estimated_duration_days'] !== null ? (int)$quotation['estimated_duration_days'] : null;
    $status = 'APPROVED';

    try {
        $conn->begin_transaction();
        $stmt = $conn->prepare("INSERT INTO projects(customer_id,quotation_id,project_name,description,project_address,start_date,deadline,contract_amount,estimated_duration_days,status,notes)
            VALUES(?,?,?,?,?,NULLIF(?,''),NULLIF(?,''),?,?,?,?)");
        $stmt->bind_param('iisssssdiss', $customerId, $quotationId, $name, $description, $address, $start, $deadline, $amount, $durationDays, $status, $notes);
        $stmt->execute();
        $id = (int)$stmt->insert_id;
        $stmt->close();
        ensureProjectSalesRecord($conn, $id, $user);
        ensureProjectPaymentMilestones($conn, $id, $amount);
        auditEvent($conn, $user, 'created', 'project', (int)$id, ['quotation_id' => $quotationId, 'project_name' => $name], null, $status);
        $conn->commit();
        sendJson(projectRow($conn, $id), 201);
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        error_log('Project creation failed: ' . $e->getMessage());
        if ((int)$e->getCode() === 1062) {
            sendError('A project already exists for this quotation. Open the existing project instead.', 409);
        }
        sendError('The project could not be created.', 500);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Project creation failed: ' . $e->getMessage());
        sendError('The project could not be created.', 500);
    }
}

if ($action === 'update' && $method === 'POST') {
    $user = requirePermission($conn, 'projects.manage');
    $body = body();
    $id = (int)($body['projectId'] ?? 0);
    $current = projectRow($conn, $id);

    $name = trim((string)($body['projectName'] ?? $current['project_name']));
    $description = trim((string)($body['description'] ?? $current['description'] ?? ''));
    $address = trim((string)($body['projectAddress'] ?? $current['project_address'] ?? ''));
    $start = projectDate((string)($body['startDate'] ?? $current['start_date'] ?? ''), 'start date');
    $deadline = projectDate((string)($body['deadline'] ?? $current['deadline'] ?? ''), 'deadline');
    $status = strtoupper(trim((string)($body['status'] ?? $current['status'])));
    $notes = trim((string)($body['notes'] ?? $current['notes'] ?? ''));

    if (!in_array($status, ['APPROVED', 'SCHEDULED', 'IN_PROGRESS', 'FOR_INSTALLATION', 'COMPLETED', 'CLOSED', 'CANCELLED'], true)) sendError('Select a valid project status.', 422);
    validateProjectFields($name, $address, $description, $notes, $start, $deadline);

    $conn->begin_transaction();
    try {
        one($conn,'SELECT project_id FROM projects WHERE project_id=? AND deleted_at IS NULL FOR UPDATE','i',[$id]);
        $alreadyPastStart=in_array($current['status'],['IN_PROGRESS','FOR_INSTALLATION','COMPLETED','CLOSED'],true);
        if (!$alreadyPastStart && in_array($status, ['IN_PROGRESS', 'FOR_INSTALLATION', 'COMPLETED', 'CLOSED'], true)
            && !projectDownPaymentSatisfied($conn, $id)) {
            $conn->rollback();
            sendError('The project cannot move to ' . str_replace('_', ' ', $status) . ' until its 50% down-payment milestone is fully paid.', 409);
        }
        $stmt = $conn->prepare("UPDATE projects SET project_name=?,description=?,project_address=?,start_date=NULLIF(?,''),deadline=NULLIF(?,''),status=?,notes=? WHERE project_id=? AND deleted_at IS NULL");
        $stmt->bind_param('sssssssi', $name, $description, $address, $start, $deadline, $status, $notes, $id);
        $stmt->execute();
        $stmt->close();
        auditEvent($conn, $user, 'updated', 'project', $id, ['project_name' => $name], (string)$current['status'], $status);
        $conn->commit();
        sendJson(projectRow($conn, $id));
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        error_log('Project update failed: ' . $e->getMessage());
        sendError('The project could not be updated.', 500);
    } catch (Throwable $e) {
        $conn->rollback();
        error_log('Project update failed: ' . $e->getMessage());
        sendError('The project could not be updated.', 500);
    }
}

if ($action === 'delete' && $method === 'POST') {
    requirePermission($conn, 'settings.manage');
    sendError('Use the Trashbin to authorize deletion.', 403);
}

sendError('Project API route not found.', 404);
